import React, { useEffect } from 'react';
import { ScrollReveal } from '../components/ui/ScrollReveal';
import { Link } from 'react-router-dom';
import { Globe, RefreshCw, Handshake, ArrowLeft } from 'lucide-react';
import { ContactCTA } from '../components/ContactCTA';

export const NRISolutionsDetails: React.FC = () => {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  return (
    <>
      <ScrollReveal>
      <section className="py-20 bg-brand-light relative overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img src="https://images.unsplash.com/photo-1436491865332-7a61a109cc05?w=1600&q=80" alt="Background" className="w-full h-full object-cover opacity-[0.06] mix-blend-multiply" />
        </div>
        <div className="absolute top-0 right-0 w-64 h-64 bg-brand-primary/10 rounded-full blur-3xl"></div>
        <div className="absolute bottom-0 left-0 w-64 h-64 bg-brand-secondary/10 rounded-full blur-3xl"></div>
        
        <div className="container mx-auto px-4 md:px-6 relative z-10 text-center max-w-4xl pt-16">
          
          <Link to="/" className="inline-flex items-center gap-2 px-4 py-2 bg-white/50 hover:bg-white text-brand-primary font-medium rounded-full mb-8 backdrop-blur-sm border border-slate-200/50 hover:border-brand-primary/30 transition-all shadow-sm hover:shadow-md group">
            <ArrowLeft className="w-4 h-4 group-hover:-translate-x-1 transition-transform" /> Back to Home
          </Link>
          <h1 className="text-5xl md:text-6xl font-display font-bold text-brand-dark mb-6">NRI Solutions</h1>
          <p className="text-xl text-slate-600 mb-8 leading-relaxed">
            Specialized investment services for global Indians. We bridge the distance, managing your wealth in India with complete transparency and compliance.
          </p>
        </div>
      </section>
      </ScrollReveal>

      <ScrollReveal>
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4 md:px-6 max-w-4xl">
          <div className="pred pred-lg pred-slate max-w-none text-slate-600 space-y-6">
            <h2 className="text-3xl font-display font-bold text-brand-dark">Why Do You Need Specialized NRI Services?</h2>
            <p>
              For Non-Resident Indians (NRIs), investing in India offers exceptional growth opportunities, but it comes wrapped in complex FEMA regulations, specialized taxation (like TDS), and the logistical challenge of remote management. Our NRI Solutions unravel these complexities, providing a frictionless path to participate in the India growth story.
            </p>
            
            <h3 className="text-2xl font-display font-bold text-brand-dark mt-12 mb-4">Our Approach</h3>
            
            <div className="grid md:grid-cols-3 gap-8 my-8">
              <div className="bg-slate-50 p-6 rounded-2xl border border-slate-100 shadow-sm">
                <Globe className="w-10 h-10 text-brand-primary mb-4" />
                <h4 className="text-lg font-bold text-brand-dark mb-2">Digital Onboarding</h4>
                <p className="text-sm">We provide seamless, paperless KYC and account setup processes, making it easy to commence your investment journey from anywhere in the world.</p>
              </div>
              
              <div className="bg-slate-50 p-6 rounded-2xl border border-slate-100 shadow-sm">
                <RefreshCw className="w-10 h-10 text-brand-primary mb-4" />
                <h4 className="text-lg font-bold text-brand-dark mb-2">NRE/NRO Support</h4>
                <p className="text-sm">Guidance on structuring investments through Repatriable (NRE) or Non-Repatriable (NRO) channels based on your anticipated utilization of funds.</p>
              </div>
              
              <div className="bg-slate-50 p-6 rounded-2xl border border-slate-100 shadow-sm">
                <Handshake className="w-10 h-10 text-brand-primary mb-4" />
                <h4 className="text-lg font-bold text-brand-dark mb-2">Tax & Compliance Hub</h4>
                <p className="text-sm">We navigate the intricacies of DTAA (Double Taxation Avoidance Agreement) and ensure flawless compliance and filing support for your Indian assets.</p>
              </div>
            </div>

            <h3 className="text-2xl font-display font-bold text-brand-dark mt-12 mb-4">The Result</h3>
            <p>
              You maintain strong financial roots in India without the operational headaches. Whether you intend to return one day or simply want to leverage India's high yields, your wealth is managed compliantly, efficiently, and securely by a team you can trust.
            </p>
          </div>
        </div>
      </section>
      </ScrollReveal>
      
      <ContactCTA />
    </>
  );
};
