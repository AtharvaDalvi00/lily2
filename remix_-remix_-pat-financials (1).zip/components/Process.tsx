import React from 'react';
import { Search, BarChart2, Compass, Play, CheckSquare } from 'lucide-react';
import { motion } from 'motion/react';
import { ProcessStep } from '../types';

const steps: ProcessStep[] = [
  { id: 1, title: 'Discovery', description: 'Understanding your goals', icon: Search },
  { id: 2, title: 'Analysis', description: 'Auditing current health', icon: BarChart2 },
  { id: 3, title: 'Strategy', description: 'Designing the roadmap', icon: Compass },
  { id: 4, title: 'Execution', description: 'Implementing the plan', icon: Play },
  { id: 5, title: 'Review', description: 'Monitoring & rebalancing', icon: CheckSquare },
];

export const Process: React.FC = () => {
  return (
    <section id="process" className="py-16 bg-white overflow-hidden">
      <div className="container mx-auto px-4 md:px-6">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-display font-bold text-brand-dark">Our Proven Process</h2>
        </div>

        <div className="relative">
          {/* Animated Connecting Arrow (Desktop) */}
          <div className="hidden md:block absolute top-10 left-[10%] right-[10%] transform -translate-y-1/2 z-0">
            <div className="w-full h-[2px] bg-slate-100 relative">
              <motion.div 
                initial={{ width: "0%" }}
                whileInView={{ width: "100%" }}
                viewport={{ once: false, margin: "-100px" }}
                transition={{ duration: 1.5, ease: "easeInOut" }}
                className="absolute top-0 left-0 h-full bg-brand-primary flex items-center justify-end"
              >
                {/* Arrow head */}
                <div className="w-0 h-0 border-y-[6px] border-y-transparent border-l-[10px] border-l-brand-primary translate-x-full"></div>
              </motion.div>
            </div>
          </div>

          {/* Animated Connecting Arrow (Mobile) */}
          <div className="md:hidden absolute top-[40px] bottom-[40px] left-1/2 transform -translate-x-1/2 z-0">
            <div className="h-full w-[2px] bg-slate-100 relative">
              <motion.div 
                initial={{ height: "0%" }}
                whileInView={{ height: "100%" }}
                viewport={{ once: false, margin: "-100px" }}
                transition={{ duration: 1.5, ease: "easeInOut" }}
                className="absolute top-0 left-0 w-full bg-brand-primary flex flex-col items-center justify-end"
              >
                {/* Arrow head */}
                <div className="w-0 h-0 border-x-[6px] border-x-transparent border-t-[10px] border-t-brand-primary translate-y-full"></div>
              </motion.div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-5 gap-8 relative z-10">
            {steps.map((step, index) => (
              <motion.div 
                key={step.id} 
                initial={{ opacity: 0, y: -60, rotateX: 30 }}
                whileInView={{ opacity: 1, y: 0, rotateX: 0 }}
                viewport={{ once: false, margin: "-50px" }}
                transition={{ 
                  duration: 0.6, 
                  delay: index * 0.1,
                  type: "spring",
                  bounce: 0.4
                }}
                className="relative z-10 flex flex-col items-center text-center group"
              >
                <div className="w-20 h-20 bg-white border-4 border-brand-light rounded-full flex items-center justify-center mb-6 shadow-sm group-hover:border-sky-500 group-hover:scale-110 group-hover:shadow-[0_8px_30px_rgb(16,185,129,0.15)] transition-all duration-300">
                  <step.icon className="w-8 h-8 text-slate-400 group-hover:text-sky-500 transition-colors" />
                </div>
                <div className="relative z-10 bg-white p-1 rounded-full mb-2">
                  <div className="bg-brand-primary/10 text-brand-primary text-xs font-bold px-3 py-1 rounded-full group-hover:bg-sky-100 group-hover:text-sky-700 transition-colors">
                    STEP 0{step.id}
                  </div>
                </div>
                <div className="bg-white relative z-10 p-2 text-center w-full max-w-[200px]">
                  <h3 className="text-lg font-bold text-brand-dark mb-2 group-hover:text-sky-600 transition-colors inline-block">{step.title}</h3>
                  <p className="text-sm text-slate-500 max-w-[150px] mx-auto">{step.description}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};