import React, { useState, useEffect } from 'react';
import { X, Calculator, Download, RefreshCw } from 'lucide-react';
import * as XLSX from 'xlsx';
import { LeadFormModal } from './LeadFormModal';

interface SWPTableRow {
  year: number;
  startAmount: number;
  annualWithdrawal: number;
  monthlyWithdrawal: number;
  balance: number;
  endBalance: number;
}

interface SIPSWPCalculatorProps {
  isOpen: boolean;
  onClose: () => void;
}

export const SIPSWPCalculator: React.FC<SIPSWPCalculatorProps> = ({ isOpen, onClose }) => {
  // SIP Phase State
  const [sipAmount, setSipAmount] = useState(100000);
  const [sipRate, setSipRate] = useState(12);
  const [sipYears, setSipYears] = useState(5);
  
  // SWP Phase State
  const [swpRate, setSwpRate] = useState(12);
  const [swpMonthly, setSwpMonthly] = useState(40000);
  const [swpYears, setSwpYears] = useState(30); // How many years to project
  
  const [sipCorpus, setSipCorpus] = useState(0);
  const [results, setResults] = useState<SWPTableRow[]>([]);
  const [isFormOpened, setIsFormOpened] = useState(false);
  const [isFormModalOpen, setIsFormModalOpen] = useState(false);
  const formURL = "https://task-flow-pro-23-01.vercel.app/#/p/b8241986-9abe-4e33-974b-63f48dfcf893";

  const calculate = () => {
    // 1. Calculate SIP Corpus (Future Value)
    const p = sipAmount;
    const r = sipRate / 100 / 12; // monthly rate
    const n = sipYears * 12; // total months
    
    // FV = P * (((1 + r)^n - 1) / r) * (1 + r)
    // Assuming investment is made at the beginning of the month
    let fv = 0;
    if (r === 0) {
      fv = p * n;
    } else {
      fv = p * ((Math.pow(1 + r, n) - 1) / r) * (1 + r);
    }
    
    const finalCorpus = Math.round(fv);
    setSipCorpus(finalCorpus);

    // 2. Calculate SWP Table based on CSV logic
    // CSV Logic: 
    // Balance = Amount - Annual Withdrawal
    // Interest = Balance * (Rate / 100)
    // End Balance = Balance + Interest
    const newResults: SWPTableRow[] = [];
    let currentAmount = finalCorpus;
    const annualWithdrawal = swpMonthly * 12;

    for (let year = 1; year <= swpYears; year++) {
      let balance = currentAmount - annualWithdrawal;
      
      // If corpus depletes
      if (balance < 0) {
        newResults.push({
          year,
          startAmount: currentAmount > 0 ? Math.round(currentAmount) : 0,
          annualWithdrawal: currentAmount > 0 ? Math.round(currentAmount) : 0,
          monthlyWithdrawal: swpMonthly,
          balance: 0,
          endBalance: 0
        });
        currentAmount = 0;
        continue;
      }

      const interest = balance * (swpRate / 100);
      const endBalance = balance + interest;

      newResults.push({
        year,
        startAmount: Math.round(currentAmount),
        annualWithdrawal: Math.round(annualWithdrawal),
        monthlyWithdrawal: Math.round(swpMonthly),
        balance: Math.round(balance),
        endBalance: Math.round(endBalance)
      });

      currentAmount = endBalance;
    }
    setResults(newResults);
  };

  useEffect(() => {
    if(isOpen) calculate();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [sipAmount, sipRate, sipYears, swpRate, swpMonthly, swpYears, isOpen]);

  const formatNumber = (val: number) => {
    return new Intl.NumberFormat('en-IN', {
      maximumFractionDigits: 2
    }).format(val);
  };

  const downloadCSV = () => {
    const finalValue = results[results.length - 1]?.endBalance || 0;

    const htmlContent = `
<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40">
<head>
<!--[if gte mso 9]>
<xml>
<x:ExcelWorkbook>
<x:ExcelWorksheets>
<x:ExcelWorksheet>
<x:Name>SIP SWP Plan</x:Name>
<x:WorksheetOptions>
<x:DisplayGridlines/>
<x:ProtectContents>True</x:ProtectContents>
</x:WorksheetOptions>
</x:ExcelWorksheet>
</x:ExcelWorksheets>
</x:ExcelWorkbook>
</xml>
<![endif]-->
<meta charset="utf-8">
<style>
  table { border-collapse: collapse; font-family: 'Segoe UI', Arial, sans-serif; }
  th, td { border: 1px solid #CBD5E1; padding: 10px; font-size: 11pt; mso-protection: locked hidden; }
  
  .title-cell { font-size: 16pt; font-weight: bold; color: #FFFFFF; background-color: #1E293B; padding: 15px; border: none; text-align: center; mso-protection: locked hidden; }
  
  .section-header { background-color: #0EA5E9; color: #FFFFFF; font-weight: bold; font-size: 12pt; text-align: left; padding: 10px; mso-protection: locked hidden; }
  .grid-header { background-color: #0F172A; color: #FFFFFF; font-weight: bold; font-size: 11pt; text-align: center; mso-protection: locked hidden; }
  
  .label-cell { color: #334155; font-weight: 500; background-color: #F8FAFC; mso-protection: locked hidden; }
  .value-cell { text-align: right; font-weight: bold; color: #020617; mso-protection: locked hidden; }
  .input-cell { text-align: right; font-weight: bold; color: #020617; background-color: #FFFFD0; mso-protection: unlocked; border: 1px solid #94A3B8; }
  
  .result-label { font-weight: bold; color: #0369A1; background-color: #F0F9FF; border: 1px solid #BAE6FD; mso-protection: locked hidden; }
  .result-value { font-weight: bold; color: #0369A1; background-color: #E0F2FE; text-align: right; border: 1px solid #BAE6FD; mso-protection: locked hidden; }
  
  .schedule-row-even { background-color: #F8FAFC; }
  .schedule-row-odd { background-color: #FFFFFF; }
  
  .currency-cell { text-align: right; mso-protection: locked hidden; }
  .center-cell { text-align: center; mso-protection: locked hidden; }
  .empty-cell { background-color: #FFFFFF; border: none; mso-protection: locked hidden; }
</style>
</head>
<body>
  <table>
    <tr>
      <td class="title-cell" colspan="5">PAT FINANCIALS - SIP &amp; SWP PLANNER REPORT</td>
    </tr>
    <tr><td colspan="5" style="border: none; height: 10px;"></td></tr>

    <tr><td class="section-header" colspan="5">PHASE 1: SIP ACCUMULATION ASSUMPTIONS</td></tr>
    <tr>
      <td class="label-cell">SIP Monthly Amount</td>
      <td class="input-cell">${sipAmount}</td>
      <td class="empty-cell" style="border: none;"></td>
      <td class="label-cell">SIP Expected Return (% p.a.)</td>
      <td class="input-cell">${sipRate}</td>
    </tr>
    <tr>
      <td class="label-cell">SIP Duration (Years)</td>
      <td class="input-cell">${sipYears}</td>
      <td class="empty-cell" style="border: none;"></td>
      <td class="label-cell">SIP Monthly Rate</td>
      <td class="value-cell" style="color: #0284C7;">=E4/12/100</td>
    </tr>

    <tr><td colspan="5" style="border: none; height: 10px;"></td></tr>

    <tr><td class="section-header" colspan="5">PHASE 2: SWP WITHDRAWAL ASSUMPTIONS</td></tr>
    <tr>
      <td class="label-cell">SWP Monthly Withdrawal</td>
      <td class="input-cell">${swpMonthly}</td>
      <td class="empty-cell" style="border: none;"></td>
      <td class="label-cell">SWP Expected Return (% p.a.)</td>
      <td class="input-cell">${swpRate}</td>
    </tr>
    <tr>
      <td class="label-cell">SWP Duration (Years)</td>
      <td class="input-cell">${swpYears}</td>
      <td class="empty-cell" style="border: none;" colspan="2"></td>
    </tr>

    <tr><td colspan="5" style="border: none; height: 15px;"></td></tr>

    <tr><td class="section-header" colspan="5">PLAN SUMMARY OUTCOMES (LIVE FORMULAS)</td></tr>
    <tr>
      <td class="result-label" colspan="3">Accumulated SIP Corpus (Future Value)</td>
      <td class="result-value" colspan="2">=IF(E4=0, B4*B5*12, B4*(((1+E5)^(B5*12)-1)/E5)*(1+E5))</td>
    </tr>
    <tr>
      <td class="result-label" colspan="3">Final Balance (End of SWP Phase)</td>
      <td class="result-value" colspan="2">=E${16 + results.length}</td>
    </tr>

    <tr><td colspan="5" style="border: none; height: 15px;"></td></tr>

    <tr><td class="section-header" colspan="5">YEARLY SWP PHASE SCHEDULE</td></tr>
    <tr>
      <td class="grid-header">YEAR</td>
      <td class="grid-header">OPENING BALANCE</td>
      <td class="grid-header">ANNUAL WITHDRAWAL (SWP)</td>
      <td class="grid-header">BALANCE AFTER WITHDRAWAL</td>
      <td class="grid-header">CLOSING BALANCE (END OF YEAR)</td>
    </tr>
    ${results.map((row, idx) => {
      const rowClass = idx % 2 === 0 ? 'schedule-row-even' : 'schedule-row-odd';
      const r = 17 + idx; // Excel row index
      const opBalFormula = idx === 0 ? '=D12' : `=E${r - 1}`;
      return `
      <tr class="${rowClass}">
        <td class="center-cell" style="font-weight: bold;">Year ${row.year}</td>
        <td class="currency-cell">${opBalFormula}</td>
        <td class="currency-cell" style="color: #2563EB;">=MIN(B${r}, $B$8*12)</td>
        <td class="currency-cell">=MAX(0, B${r}-C${r})</td>
        <td class="currency-cell" style="font-weight: bold; color: #0EA5E9;">=IF(D${r}>0, ROUND(D${r}*(1+$E$8/100), 0), 0)</td>
      </tr>
      `;
    }).join('')}
  </table>
</body>
</html>
`;

    const blob = new Blob([htmlContent], { type: 'application/vnd.ms-excel;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `sip_swp_report_${new Date().toISOString().split('T')[0]}.xls`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  if (!isOpen) return null;

  const formatCurrency = (val: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0
    }).format(Math.abs(val));
    // added Math.abs in case we show negative
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 sm:p-6">
      <div 
        className="absolute inset-0 bg-slate-900/40 pointer-events-auto" 
        onClick={onClose} 
        style={{ backdropFilter: 'blur(16px)', WebkitBackdropFilter: 'blur(16px)' }}
      />
      
      <div 
        className="relative bg-white/75 backdrop-blur-xl w-full max-w-6xl rounded-2xl shadow-2xl border border-white/50 max-h-full sm:max-h-[90vh] flex flex-col overflow-hidden"
        style={{ backdropFilter: 'blur(30px)', WebkitBackdropFilter: 'blur(30px)' }}
      >
        {/* Header */}
        <div className="flex flex-wrap items-center justify-between p-6 bg-brand-primary text-white border-b border-white/20 gap-4 shrink-0">
          <div className="flex items-center gap-3">
            <div className="bg-white/20 p-2.5 rounded-xl">
              <Calculator className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-xl font-bold tracking-tight">Goal Planner (Freedom Calculator)</h2>
              <p className="text-xs text-blue-100">Plan your SIP corpus and generate regular SWP income</p>
            </div>
          </div>
          <div className="flex items-center gap-3 ml-auto">
            <button
              onClick={() => {
                if (!isFormOpened) {
                  setIsFormModalOpen(true);
                } else {
                  downloadCSV();
                }
              }}
              className={`flex items-center gap-2 ${isFormOpened ? 'bg-sky-600 hover:bg-sky-700' : 'bg-[#3B82F6] hover:bg-[#1D4ED8]'} text-white px-4 py-2 rounded-xl transition-colors font-semibold text-sm shadow-sm`}
            >
              <Download className="w-4 h-4" />
              {isFormOpened ? 'Download Excel Sheet' : 'Fill Form & Download'}
            </button>
            <LeadFormModal
              isOpen={isFormModalOpen}
              onClose={() => setIsFormModalOpen(false)}
              onSubmitAndDownload={() => {
                setIsFormOpened(true);
                setIsFormModalOpen(false);
                downloadCSV();
              }}
            />
            <button onClick={onClose} className="p-2.5 bg-white/10 hover:bg-white/20 rounded-xl transition-colors text-white">
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>
        <div className="flex flex-col lg:flex-row flex-1 overflow-hidden min-h-0">
        {/* Inputs Panel */}
           <div 
             data-lenis-prevent="true" 
             className="w-full lg:w-1/3 p-6 bg-slate-50/50 border-r border-slate-200/50 overflow-y-auto"
             style={{ backdropFilter: 'blur(10px)', WebkitBackdropFilter: 'blur(10px)' }}
           >
              <div className="space-y-8">
                 {/* SIP Phase */}
                 <div>
                   <h4 className="font-bold text-brand-dark border-b border-slate-200 pb-2 mb-4 text-base uppercase tracking-wider text-brand-primary">1. SIP Phase (Wealth Creation)</h4>
                   
                   <div className="space-y-4">
                     <div>
                        <label className="block text-sm font-semibold text-slate-700 mb-2">Monthly SIP Amount (₹)</label>
                        <input 
                          type="number" 
                          value={sipAmount || ''} 
                          onChange={(e) => setSipAmount(Number(e.target.value))}
                          className="w-full p-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-brand-primary focus:border-transparent"
                        />
                        <input type="range" min="1000" max="500000" step="1000" value={sipAmount} onChange={(e)=>setSipAmount(Number(e.target.value))} className="w-full mt-2 accent-brand-primary"/>
                     </div>

                     <div>
                        <label className="block text-sm font-semibold text-slate-700 mb-2">Expected Return (% p.a)</label>
                        <input 
                          type="number" 
                          value={sipRate || ''} 
                          onChange={(e) => setSipRate(Number(e.target.value))}
                          className="w-full p-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-brand-primary focus:border-transparent"
                        />
                        <input type="range" min="1" max="30" step="0.5" value={sipRate} onChange={(e)=>setSipRate(Number(e.target.value))} className="w-full mt-2 accent-brand-primary"/>
                     </div>

                     <div>
                        <label className="block text-sm font-semibold text-slate-700 mb-2">Duration (Years)</label>
                        <input 
                          type="number" 
                          value={sipYears || ''} 
                          onChange={(e) => setSipYears(Number(e.target.value))}
                          className="w-full p-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-brand-primary focus:border-transparent"
                        />
                        <input type="range" min="1" max="40" step="1" value={sipYears} onChange={(e)=>setSipYears(Number(e.target.value))} className="w-full mt-2 accent-brand-primary"/>
                     </div>
                   </div>
                   
                   <div className="mt-4 p-4 bg-brand-primary/10 rounded-xl border border-brand-primary/20">
                     <p className="text-sm font-semibold text-brand-dark mb-1">Generated Corpus (Future Value)</p>
                     <p className="text-2xl font-bold text-brand-primary">{formatCurrency(sipCorpus)}</p>
                   </div>
                 </div>

                 {/* SWP Phase */}
                 <div>
                   <h4 className="font-bold text-brand-dark border-b border-slate-200 pb-2 mb-4 text-base uppercase tracking-wider text-sky-600">2. SWP Phase (Income Generation)</h4>
                   
                   <div className="space-y-4">
                     <div>
                        <label className="block text-sm font-semibold text-slate-700 mb-2">Monthly Withdrawal (₹)</label>
                        <input 
                          type="number" 
                          value={swpMonthly || ''} 
                          onChange={(e) => setSwpMonthly(Number(e.target.value))}
                          className="w-full p-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-sky-500 focus:border-transparent"
                        />
                        <input type="range" min="5000" max="1000000" step="5000" value={swpMonthly} onChange={(e)=>setSwpMonthly(Number(e.target.value))} className="w-full mt-2 accent-sky-600"/>
                     </div>

                     <div>
                        <label className="block text-sm font-semibold text-slate-700 mb-2">Expected Return (% p.a)</label>
                        <input 
                          type="number" 
                          value={swpRate || ''} 
                          onChange={(e) => setSwpRate(Number(e.target.value))}
                          className="w-full p-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-sky-500 focus:border-transparent"
                        />
                        <input type="range" min="1" max="30" step="0.5" value={swpRate} onChange={(e)=>setSwpRate(Number(e.target.value))} className="w-full mt-2 accent-sky-600"/>
                     </div>
                   </div>
                 </div>
              </div>
           </div>

           {/* Results Panel */}
           <div className="w-full lg:w-2/3 flex flex-col bg-white/40 backdrop-blur-md" style={{ backdropFilter: 'blur(20px)', WebkitBackdropFilter: 'blur(20px)' }}>
              <div className="p-6 bg-brand-light/30 border-b border-slate-100/50 flex flex-col sm:flex-row justify-between items-center gap-4 animate-fade-in" style={{ backdropFilter: 'blur(10px)', WebkitBackdropFilter: 'blur(10px)' }}>
                 <div>
                    <h3 className="text-lg font-bold text-brand-dark leading-tight">SWP Projection</h3>
                    <p className="text-sm text-slate-500">Based on a starting corpus of {formatCurrency(sipCorpus)}</p>
                 </div>
                 <div className="bg-white/80 p-3 rounded-xl border border-slate-200/50 shadow-sm backdrop-blur-sm">
                   <p className="text-xs text-slate-500 font-semibold uppercase">Corpus Lasts For</p>
                   {results.some(r => r.balance === 0) ? (
                     <p className="text-lg font-bold text-blue-500">
                       {results.findIndex(r => r.balance === 0)} Years
                     </p>
                   ) : (
                     <p className="text-lg font-bold text-sky-600">
                       {swpYears}+ Years
                     </p>
                   )}
                 </div>
              </div>

              <div data-lenis-prevent="true" className="flex-1 overflow-auto relative bg-white/10">
                 <table className="w-full text-left border-collapse">
                    <thead className="bg-slate-100/60 sticky top-0 z-10 shadow-sm backdrop-blur-sm" style={{ backdropFilter: 'blur(8px)', WebkitBackdropFilter: 'blur(8px)' }}>
                       <tr>
                          <th className="p-3 text-xs font-bold text-slate-600 uppercase tracking-wider">Year</th>
                          <th className="p-3 text-xs font-bold text-slate-600 uppercase tracking-wider text-right">Start Amount</th>
                          <th className="p-3 text-xs font-bold text-slate-600 uppercase tracking-wider text-right">Withdrawal<br/><span className="text-[10px] font-normal">(Annual)</span></th>
                          <th className="p-3 text-xs font-bold text-slate-600 uppercase tracking-wider text-right">Balance</th>
                          <th className="p-3 text-xs font-bold text-slate-600 uppercase tracking-wider text-right">Balance + Interest<br/><span className="text-[10px] font-normal">(End of Year)</span></th>
                       </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                       {results.map((row) => (
                          <tr key={row.year} className={`transition-all duration-200 ${row.startAmount === 0 ? 'bg-blue-50/20 opacity-60' : 'hover:bg-slate-50/40'}`}>
                             <td className="p-3 text-sm font-bold text-slate-800">{row.year}</td>
                             <td className="p-3 text-sm text-slate-600 text-right">{formatCurrency(row.startAmount)}</td>
                             <td className="p-3 text-sm text-blue-500 font-medium text-right font-mono">-{formatCurrency(row.annualWithdrawal)}</td>
                             <td className="p-3 text-sm text-slate-500 text-right">{formatCurrency(row.balance)}</td>
                             <td className={`p-3 text-sm font-bold text-right ${row.endBalance > row.startAmount ? 'text-sky-600' : (row.endBalance === 0 ? 'text-blue-500' : 'text-slate-800')}`}>
                               {formatCurrency(row.endBalance)}
                             </td>
                          </tr>
                       ))}
                                         </tbody>
                  </table>
               </div>
               <div className="p-4 border-t border-slate-100/60 flex justify-end gap-3 bg-white/40 backdrop-blur-md mt-auto" style={{ backdropFilter: 'blur(10px)', WebkitBackdropFilter: 'blur(10px)' }}>
                 <button 
                    onClick={() => {
                       if (!isFormOpened) {
                         setIsFormModalOpen(true);
                       } else {
                         downloadCSV();
                       }
                    }}
                    className={`flex items-center gap-2 px-4 py-2 ${isFormOpened ? 'bg-sky-600' : 'bg-brand-dark'} text-white text-sm font-semibold rounded-lg hover:bg-slate-800 transition-colors`}
                 >
                    <Download className="w-4 h-4" /> {isFormOpened ? 'Download Excel Sheet' : 'Fill Form & Download'}
                 </button>
                 <LeadFormModal 
                    isOpen={isFormModalOpen}
                    onClose={() => setIsFormModalOpen(false)}
                    onSubmitAndDownload={() => {
                       setIsFormOpened(true);
                       setIsFormModalOpen(false);
                       downloadCSV();
                    }}
                 />
              </div>
            </div>
         </div>
      </div>
    </div>
  );
};