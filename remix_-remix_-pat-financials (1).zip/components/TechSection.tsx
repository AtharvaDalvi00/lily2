import React from 'react';
import { Smartphone, Check, Bell, Lock } from 'lucide-react';

export const TechSection: React.FC = () => {
  return (
    <section className="py-16 bg-brand-dark text-white overflow-hidden relative">
      <div className="absolute inset-0 bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-20 mix-blend-soft-light pointer-events-none"></div>
      <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-brand-primary/20 rounded-full blur-[120px] pointer-events-none"></div>
      
      <div className="container mx-auto px-4 md:px-6 relative z-10">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <div className="order-2 lg:order-1">
            <h2 className="text-4xl lg:text-5xl font-display font-bold mb-6">Invest Easy. <br/><span className="text-brand-secondary">Track Smart.</span></h2>
            <p className="text-slate-400 text-lg mb-8 leading-relaxed">
              Experience the power of real-time portfolio tracking. Access your investments, download reports, and track your progress towards goals anytime, anywhere.
            </p>
            
            <ul className="space-y-4 mb-8">
              {[
                'Real-time Dashboard & Alerts',
                'Seamless SIP Management',
                'Family Portfolio View',
                'Bank-Grade Security (256-bit Encryption)'
              ].map((item, idx) => (
                <li key={idx} className="flex items-center gap-3">
                  <div className="w-6 h-6 rounded-full bg-brand-secondary/20 flex items-center justify-center text-brand-secondary">
                    <Check className="w-4 h-4" />
                  </div>
                  <span className="font-medium text-slate-200">{item}</span>
                </li>
              ))}
            </ul>

            <button className="px-8 py-4 bg-brand-primary text-white font-semibold rounded-full hover:bg-brand-primary/90 transition-all flex items-center gap-2">
              <Smartphone className="w-5 h-5" />
              Download App
            </button>
          </div>

          <div className="order-1 lg:order-2 flex justify-center lg:justify-end relative">
             {/* Phone Mockup */}
             <div className="relative w-[300px] h-[600px] bg-slate-900 rounded-[40px] border-8 border-slate-800 shadow-2xl overflow-hidden z-10">
                {/* Notch */}
                <div className="absolute top-0 left-1/2 -translate-x-1/2 w-32 h-6 bg-slate-800 rounded-b-2xl z-20"></div>
                
                {/* Screen Content */}
                <div className="w-full h-full bg-slate-950 pt-10 px-4 overflow-hidden relative">
                   <div className="flex justify-between items-center mb-6">
                      <div className="text-xs text-slate-400">Good Morning, <br/><span className="text-white text-lg font-bold">Prathamesh</span></div>
                      <Bell className="text-slate-400 w-5 h-5" />
                   </div>

                   {/* Balance Card */}
                   <div className="bg-gradient-to-br from-brand-primary to-blue-800 p-5 rounded-2xl mb-6 text-white shadow-glow">
                      <p className="text-xs text-blue-200 mb-1">Total Portfolio Value</p>
                      <h3 className="text-3xl font-bold mb-4">₹ 2.45 Cr</h3>
                      <div className="flex gap-2 text-xs">
                         <span className="bg-white/20 px-2 py-1 rounded">+12.4%</span>
                         <span className="px-2 py-1">All time</span>
                      </div>
                   </div>

                   {/* Chart Placeholder */}
                   <div className="mb-6">
                      <div className="flex justify-between text-xs text-slate-400 mb-2">
                        <span>Performance</span>
                        <span>6M</span>
                      </div>
                      <div className="h-32 flex items-end justify-between gap-2">
                        {[40, 60, 45, 70, 55, 80, 65].map((h, i) => (
                           <div key={i} className="bg-brand-secondary w-full rounded-t-sm" style={{height: `${h}%`, opacity: (i+3)/10}}></div>
                        ))}
                      </div>
                   </div>

                   {/* List Items */}
                   <div className="space-y-3">
                      <div className="flex items-center justify-between p-3 bg-white/5 rounded-xl border border-white/5">
                         <div className="flex items-center gap-3">
                            <div className="w-8 h-8 rounded-full bg-blue-500/20 flex items-center justify-center text-blue-500">S</div>
                            <div>
                               <p className="text-sm font-bold text-white">Monthly SIP</p>
                               <p className="text-xs text-slate-500">Due in 2 days</p>
                            </div>
                         </div>
                         <p className="text-white font-medium">₹ 50,000</p>
                      </div>
                      <div className="flex items-center justify-center p-3">
                          <Lock className="w-4 h-4 text-slate-600 mr-2"/> <span className="text-xs text-slate-600">Secure Environment</span>
                      </div>
                   </div>
                </div>
             </div>
             {/* Decorative blob behind phone */}
             <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[350px] h-[600px] bg-brand-primary/20 rounded-full blur-3xl -z-10"></div>
          </div>
        </div>
      </div>
    </section>
  );
};