export class SimpleAI {
  documents: { text: string; category: string }[] = [];
  vocabulary: Set<string> = new Set();
  categoryCounts: Record<string, number> = {};
  wordCounts: Record<string, Record<string, number>> = {};
  totalDocs = 0;

  tokenize(text: string): string[] {
    const stopWords = new Set(['what', 'is', 'an', 'how', 'does', 'work', 'tell', 'me', 'about', 'to', 'in', 'i', 'want', 'a', 'do', 'my', 'are', 'for', 'of', 'on', 'the']);
    return text.toLowerCase().replace(/[^\w\s]/g, '').split(/\s+/).filter(w => w.length > 0 && !stopWords.has(w));
  }

  addDocument(text: string, category: string) {
    this.documents.push({ text, category });
    this.categoryCounts[category] = (this.categoryCounts[category] || 0) + 1;
    this.wordCounts[category] = this.wordCounts[category] || {};
    this.totalDocs++;

    const words = this.tokenize(text);
    for (const word of words) {
      this.vocabulary.add(word);
      this.wordCounts[category][word] = (this.wordCounts[category][word] || 0) + 1;
    }
  }

  train() {
    console.log(`AI Trained with ${this.totalDocs} documents across ${Object.keys(this.categoryCounts).length} categories.`);
  }

  classify(text: string): string {
    const words = this.tokenize(text);
    let bestCategory = 'unknown';
    let maxScore = -Infinity;

    for (const category in this.categoryCounts) {
      let score = Math.log(this.categoryCounts[category] / this.totalDocs);
      const totalWordsInCategory = Object.values(this.wordCounts[category]).reduce((a, b) => a + b, 0);

      for (const word of words) {
        // Laplace smoothing
        const wordCount = this.wordCounts[category][word] || 0;
        const prob = (wordCount + 1) / (totalWordsInCategory + this.vocabulary.size);
        score += Math.log(prob);
      }

      if (score > maxScore) {
        maxScore = score;
        bestCategory = category;
      }
    }
    return bestCategory;
  }
}

export const myAI = new SimpleAI();

// Training Data
myAI.addDocument('hello hi hey good morning greetings', 'greeting');
myAI.addDocument('what is an sip how does systematic investment plan work', 'sip');
myAI.addDocument('tell me about mutual funds how to invest in mf', 'mutual_funds');
myAI.addDocument('i want to book a consultation meet an advisor schedule a meeting', 'consultation');
myAI.addDocument('how does taxation work on capital gains ltcg stcg income tax', 'tax');
myAI.addDocument('tell me about step up sip increasing sip amount', 'step_up_sip');
myAI.addDocument('yes sure okay please do that definitely yeah absolutely yup', 'affirmative');
myAI.addDocument('what is inflation how does cost of living affect investment purchasing power', 'inflation');
myAI.addDocument('inflation erodes savings reduce purchasing power impact', 'inflation');
myAI.addDocument('how do i diversify my portfolio what is asset allocation risk management', 'diversification');
myAI.addDocument('risk reward balance asset classes allocation portfolio', 'diversification');
myAI.addDocument('what are retirement plans how to plan for retirement corpus', 'retirement');
myAI.addDocument('systematic withdrawal plan swp regular income', 'swp');
myAI.addDocument('pat financials wealth distributor firm', 'patfinancials');
myAI.addDocument('pradnya tamhane founder advisor', 'pradnya_tamhane');
myAI.addDocument('kyc know your customer identity verification', 'kyc');
myAI.addDocument('stocks ownership shares equity market', 'stocks');
myAI.addDocument('investment wealth creation grow money', 'investment');
myAI.addDocument('rate of return ror percentage gain loss', 'rate_of_return');
myAI.addDocument('emi equated monthly installment loan repayment', 'emi');
myAI.addDocument('loans borrowing debt interest', 'loans');
myAI.addDocument('insurance financial protection premium cover', 'insurance');

myAI.train();


export function generateCustomAIResponse(history: any[]) {
    const lastUserMessage = [...history].reverse().find(m => m.role === 'user');
    const input = lastUserMessage?.content || '';
    
    // Short circuit for empty
    if (!input.trim()) {
        return { text: "I didn't quite catch that. How can I help you regarding our financial services?" };
    }

    const intent = myAI.classify(input);
    
    const hasPhone = /\d{8,14}/.test(input);
    const hasEmail = /\S+@\S+\.\S+/.test(input);
    
    const recentHistory = history.slice(-3).map(m => m.content?.toLowerCase() || '').join(' ');
    const wasAskingForDetails = recentHistory.includes('phone number') || recentHistory.includes('availability') || recentHistory.includes('income');

    if (wasAskingForDetails && (hasPhone || hasEmail || input.length > 8)) {
        return {
            text: "Excellent. I have recorded your details and requirement. One of our financial advisors will review this and be in touch with you shortly! Is there anything else you'd like to know?",
            taskData: {
                clientName: "Extracted from chat",
                phoneNumber: hasPhone ? input.match(/\d{8,14}/)?.[0] || 'Unknown' : 'Not provided',
                availability: "From chat input",
                income: "From chat input",
                requirement: `User input: ${input}`,
                category: "Investment"
            }
        };
    }

    switch(intent) {
        case 'greeting':
            return { text: "Hello! I am your 100% custom-built local PAT Financials AI instance (Gemini is no longer connected). I can tell you about SIPs, Mutual Funds, Taxes, or help you book a consultation. How can I assist you today?" };
        case 'sip':
            return { text: "A Systematic Investment Plan (SIP) involves investing a fixed sum of money at regular intervals in a mutual fund. It helps in Rupee Cost Averaging and instills financial discipline. At PAT Financials, we curate optimal SIP portfolios that map exactly to your life goals and continuously monitor them for consistent performance.\n\nSee additional information of this and related terms." };
        case 'mutual_funds':
            return { text: "Mutual funds pool money from many investors to purchase a diversified portfolio of stocks, bonds, or other securities. They are managed by professionals. PAT Financials helps you navigate thousands of funds to select the right schemes that align top performance with your risk appetite.\n\nSee additional information of this and related terms." };
        case 'tax':
            return { text: "Taxation on investments depends on the holding period and asset class. Equity funds have Short Term Capital Gains (STCG) and Long Term Capital Gains (LTCG) tax. PAT Financials structures your portfolio to be tax-efficient, minimizing your liabilities through smart tax harvesting.\n\nSee additional information of this and related terms." };
        case 'step_up_sip':
            return { text: "A Step-up SIP automatically increases your investment amount periodically, mirroring your rising income and beating inflation. PAT Financials models your future cash flows to calculate the exact step-up rate needed to achieve your goals much earlier.\n\nSee additional information of this and related terms." };
        case 'consultation':
            return { text: "I'd be glad to arrange a consultation for you! To get started, could you please tell me your name, phone number, when you're free to meet, and roughly what your income bracket is?" };
        case 'affirmative':
            return { text: "Great! Could you please provide your name, phone number, when you're free to meet, and your income bracket so our advisors can set things up?" };
        case 'inflation':
            return { text: "Inflation gradually reduces the purchasing power of your money. At PAT Financials, we combat inflation by crafting portfolios with the potential to outperform it over the long term, ensuring your real wealth continues to grow.\n\nSee additional information of this and related terms." };
        case 'diversification':
            return { text: "Asset allocation and diversification are key to managing risk. PAT Financials balances your portfolio across different asset classes, geographies, and sectors to protect your wealth while optimizing returns against market volatility.\n\nSee additional information of this and related terms." };
        case 'retirement':
            return { text: "Developing a retirement roadmap is crucial for long-term security. PAT Financials helps you build a robust corpus through disciplined investing, ensuring you maintain your lifestyle. We map out your future needs and build a dedicated retirement roadmap.\n\nSee additional information of this and related terms." };
        case 'swp':
            return { text: "A Systematic Withdrawal Plan (SWP) allows you to withdraw a fixed amount regularly from your mutual fund investments. PAT Financials optimizes your SWP strategy to provide a steady income stream while ensuring your core capital continues to grow.\n\nSee additional information of this and related terms." };
        case 'patfinancials':
            return { text: "PAT Financials is a premier wealth distributor firm dedicated to securing your financial future. We offer personalized, unbiased advice, structuring an investment framework that evolves with you to build sustainable wealth over time.\n\nSee additional information of this and related terms." };
        case 'pradnya_tamhane':
            return { text: "Pradnya Tamhane is the visionary founder leading PAT Financials. With deep expertise in financial structuring, she focuses on personalized wealth distribution, bridging the gap between individuals' dreams and effective, actionable investment strategies.\n\nSee additional information of this and related terms." };
        case 'kyc':
            return { text: "Know Your Customer (KYC) is a mandatory regulatory process to verify your identity and address before investing. PAT Financials assists you with a seamless, digital KYC process, making onboarding quick, secure, and hassle-free.\n\nSee additional information of this and related terms." };
        case 'stocks':
            return { text: "Stocks represent ownership shares in a company. Investing in stocks offers high growth potential but comes with higher market risk. PAT Financials provides expert equity advisory, identifying high-quality businesses for long-term wealth creation.\n\nSee additional information of this and related terms." };
        case 'investment':
            return { text: "Investment is the act of allocating resources to generate income or profit. At PAT Financials, investing is a disciplined, guided process. We align your investments with your specific life goals rather than chasing short-term market trends.\n\nSee additional information of this and related terms." };
        case 'rate_of_return':
            return { text: "Rate of Return (RoR) is the net gain or loss of an investment over a specified period. PAT Financials goes beyond standard absolute returns, focusing on risk-adjusted and inflation-beating returns to measure your true portfolio performance.\n\nSee additional information of this and related terms." };
        case 'emi':
            return { text: "Equated Monthly Installments (EMI) are fixed payments to repay a loan. PAT Financials helps you evaluate debt alongside your investments, advising on prepayment strategies and ensuring EMIs don't derail your long-term wealth creation goals.\n\nSee additional information of this and related terms." };
        case 'loans':
            return { text: "Loans are financial tools for borrowing money. While borrowing can be useful, PAT Financials provides debt advisory to ensure you leverage loans sensibly, preventing debt traps and protecting your investment capital.\n\nSee additional information of this and related terms." };
        case 'insurance':
            return { text: "Insurance is a financial arrangement for protection against specified risks. PAT Financials views insurance purely as risk management (not an investment). We help you secure adequate life and health cover to protect your family's financial plan from unforeseen events.\n\nSee additional information of this and related terms." };
        default:
            return { text: "That's an interesting question! At PAT Financials, we handle financial queries by providing expert, personalised guidance tailored to your specific financial profile, goals, and risk appetite. To get the best answer for your situation, would you like to schedule a consultation with one of our advisors?" };
    }
}
