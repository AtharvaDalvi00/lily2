import React, { useState, useRef, useEffect } from 'react';
import { MessageSquare, X, Send, Bot } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import Markdown from 'react-markdown';
import { generateCustomAIResponse } from '../src/lib/customAI';

type ChatStep = {
  id: string;
  type: 'bot' | 'form';
  text: string;
  quickReplies?: string[];
  fields?: { label: string; key: string; ph: string }[];
};

const STEPS: ChatStep[] = [
  {
    id: 'welcome',
    type: 'bot',
    text: "Hello! 👋 Welcome to **PAT Financials**. I'm here to help you book a consultation with our wealth distributor team.\n\nI'll guide you through a short financial questionnaire so our advisor can prepare a personalised plan for you. It takes about 2–3 minutes.",
    quickReplies: ["Let's begin", "What we do in PAT Financials", "Collection after your information", "Contact & Address"]
  },
  {
    id: 'contact_details',
    type: 'form',
    text: "Let's start with your Contact & Location details.",
    fields: [
      { label: "Your Full Name (Lead Name)", key: "contact_name", ph: "e.g. Rahul Sharma" },
      { label: "Contact (Phone number or Email)", key: "contact_info", ph: "e.g. +91 98765 43210 or rahul@email.com" },
      { label: "City", key: "contact_city", ph: "e.g. Mumbai" }
    ]
  },
  {
    id: 'additional_details',
    type: 'form',
    text: "### Additional Details\nPlease share some onboarding parameters so we can map your record correctly.",
    fields: [
      { label: "Income", key: "income", ph: "e.g. Below 5 Lakhs, 5-10L, 10-25L, Above 25L" }
    ]
  },
  {
    id: 'about_client',
    type: 'form',
    text: "### Requirements\nFinally, describe what financial guidance or solutions you are looking for.",
    fields: [
      { label: "About Client (My requirements/notes)", key: "about_client", ph: "e.g. Mutual Funds, retirement roadmap, portfolio rebalancing..." }
    ]
  },
  {
    id: 'done',
    type: 'bot',
    text: "✅ **Thank you! Your information has been successfully collected.**\n\nOur advisor at PAT Financials will review your client profile and reach out within **24 hours** to confirm your onboarding call.\n\n📞 If urgent, call us at **+91 99207 55871**\n📧 Or email **www.patfinancials.com@gmail.com**",
    quickReplies: ["Submit another query", "Visit patfinancials.in"]
  }
];

interface ChatMessage {
  id: string;
  type: 'bot' | 'user' | 'form' | 'typing';
  text?: string;
  quickReplies?: string[];
  fields?: { label: string; key: string; ph: string }[];
  stepId?: string;
  hideQuickReplies?: boolean;
}

export const Chatbot: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [currentStepIndex, setCurrentStepIndex] = useState(0);
  const [collectedData, setCollectedData] = useState<Record<string, string>>({});
  const [isTyping, setIsTyping] = useState(false);
  const [inputValue, setInputValue] = useState('');
  const [isHovered, setIsHovered] = useState(false);
  
  const chatContainerRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    if (isOpen && isHovered) {
      const originalStyle = window.getComputedStyle(document.body).overflow;
      document.body.style.overflow = 'hidden';
      return () => {
        document.body.style.overflow = originalStyle === 'hidden' ? '' : originalStyle;
      };
    }
  }, [isOpen, isHovered]);

  const scrollToBottom = () => {
    if (chatContainerRef.current) {
      chatContainerRef.current.scrollTop = chatContainerRef.current.scrollHeight;
    }
    setTimeout(() => {
      if (chatContainerRef.current) {
        chatContainerRef.current.scrollTop = chatContainerRef.current.scrollHeight;
      }
    }, 50);
    setTimeout(() => {
      if (chatContainerRef.current) {
        chatContainerRef.current.scrollTop = chatContainerRef.current.scrollHeight;
      }
    }, 200);
    setTimeout(() => {
      if (chatContainerRef.current) {
        chatContainerRef.current.scrollTop = chatContainerRef.current.scrollHeight;
      }
    }, 450);
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isTyping, isOpen]);

  useEffect(() => {
    if (isOpen && messages.length === 0) {
      // Start the flow
      renderStep(0);
    }
  }, [isOpen]);

  const renderStep = (index: number) => {
    const step = STEPS[index];
    if (!step) return;
    
    setIsTyping(true);
    setTimeout(() => {
      setIsTyping(false);
      setMessages((prev) => [
        ...prev,
        {
          id: Date.now().toString(),
          type: step.type,
          text: step.text,
          quickReplies: step.quickReplies || (step.type === 'bot' && step.id !== 'done' ? ["Let's begin", "What we do in PAT Financials", "Collection after your information", "Contact & Address"] : undefined),
          fields: step.fields,
          stepId: step.id
        }
      ]);
    }, 700);
  };

  const handleQuickReply = (reply: string, msgId: string) => {
    // Hide quick replies for the message that was clicked
    setMessages((prev) => 
      prev.map(msg => msg.id === msgId ? { ...msg, hideQuickReplies: true } : msg)
    );

    // Add user message
    setMessages((prev) => [
      ...prev,
      {
        id: Date.now().toString(),
        type: 'user',
        text: reply
      }
    ]);

    // Process logic
    if (reply === "Let's begin") {
      setCurrentStepIndex(1);
      renderStep(1);
    } else if (reply === "What we do in PAT Financials") {
      setIsTyping(true);
      setTimeout(() => {
        setIsTyping(false);
        setMessages((prev) => [
          ...prev,
          {
            id: Date.now().toString(),
            type: 'bot',
            text: "**PAT Financials** provides meticulous, structured, and customized wealth planning solutions:\n\n" +
                  "We don't just sell standard products; we design financial models adapted to your unique **financial DNA**:\n\n" +
                  "*   **Comprehensive Asset Allocation**: Balancing Equities, Debt, Commodities, and Real Estate for bulletproof portfolios.\n" +
                  "*   **Product Selection**: Broad expertise across Mutual Funds, Fixed Deposits, Bonds, Stocks, NPS, PMS, AIF, and life/health Insurance.\n" +
                  "*   **Goal-Centric Structuring**: Precision-engineered plans for retirement, children's education, and contingency funds managed and reviewed systematically.",
            quickReplies: ["Let's begin", "Collection after your information", "Contact & Address"]
          }
        ]);
      }, 700);
    } else if (reply === "Collection after your information") {
      setIsTyping(true);
      setTimeout(() => {
        setIsTyping(false);
        setMessages((prev) => [
          ...prev,
          {
            id: Date.now().toString(),
            type: 'bot',
            text: "**Meticulous Wealth Advisory Workflow** \n\n" +
                  "Once you complete data collection, we follow a rigorous and personalized process client-by-client:\n\n" +
                  "1.  **Comprehensive Analysis**: We analyze your risk tolerance, current asset allocation, surplus cash flow, and financial goals.\n" +
                  "2.  **Strategic Modelling**: Using our proprietary wealth framework, we construct custom models balancing safety with target CAGR.\n" +
                  "3.  **Discovery & Consult Meeting**: We hold a detailed presentation meeting to share detailed gaps and asset choices.\n" +
                  "4.  **Zero-Stress Execution**: We facilitate full electronic setup and allocation tracking across mutual funds, NPS, bonds, or insurance.\n" +
                  "5.  **Rebalancing & Audits**: We continuously review macroeconomics and rebalance assets systematically.",
            quickReplies: ["Let's begin", "What we do in PAT Financials", "Contact & Address"]
          }
        ]);
      }, 700);
    } else if (reply === "Contact & Address") {
      setIsTyping(true);
      setTimeout(() => {
        setIsTyping(false);
        setMessages((prev) => [
          ...prev,
          {
            id: Date.now().toString(),
            type: 'bot',
            text: "**PAT Financials Contact Details** 📍\n\n" +
                  "You can reach us or visit our head office using the details below:\n\n" +
                  "*   **Address**: 407, MINT IndiaBulls, near Hiranandani Meadows, next to Hyde Park, Manpada, Thane West, Thane, Maharashtra 400610 (Ghodbunder Road, 400607)\n" +
                  "*   **Call Us**: +91 99204 02965 / +91 88286 87650\n" +
                  "*   **Email**: www.patfinancials.com@gmail.com\n" +
                  "*   **Business Hours**: Mon–Fri, 10:00 AM – 7:00 PM\n\n" +
                  "Would you like to book a comprehensive financial assessment call with our advisors?",
            quickReplies: ["Let's begin", "What we do in PAT Financials", "Collection after your information"]
          }
        ]);
      }, 700);
    } else if (reply === "Visit patfinancials.in") {
      window.open('https://www.patfinancials.in', '_blank');
    } else if (reply === "Submit another query") {
      setMessages([]);
      setCollectedData({});
      setCurrentStepIndex(0);
      renderStep(0);
    }
  };

  const handleFormSubmit = async (stepId: string, formData: Record<string, string>, msgId: string) => {
    // Save to collected data
    const newData = { ...collectedData, ...formData };
    setCollectedData(newData);
    
    // Disable form in UI
    setMessages((prev) =>
      prev.map((msg) => (msg.id === msgId ? { ...msg, fields: [] } : msg)) // Hacky way to disable form, or just mark it submitted
    );

    if (stepId === 'about_client') {
      setIsTyping(true);
      await sendToTaskFlow(newData);
      
      setTimeout(() => {
        setIsTyping(false);
        setCurrentStepIndex(STEPS.length - 1);
        renderStep(STEPS.length - 1);
      }, 1200);
    } else {
      const nextIndex = currentStepIndex + 1;
      setCurrentStepIndex(nextIndex);
      renderStep(nextIndex);
    }
  };

  const sendToTaskFlow = async (data: Record<string, string>) => {
    // Collect the text for each question based on the CRM Onboarding Form
    const q1 = `Lead Name: ${data.contact_name || 'N/A'}`;
    const q2 = `Contact: ${data.contact_info || 'N/A'}`;
    const q3 = `City: ${data.contact_city || 'N/A'}`;
    const q4 = `Contacted Through: ${data.contacted_through || 'N/A'}\nSource: ${data.source || 'N/A'}`;
    const q5 = `Income: ${data.income || 'N/A'}\nReferenced By: ${data.referenced_by || 'N/A'}`;
    const q6 = `About Client / Requirements: ${data.about_client || 'N/A'}`;
    const q7 = `Submission Type: Chatbot Client Onboarding Form Match`;

    try {
      const formId = 'ce4bae25-decf-4944-9ad6-882966fbbda7';
      const supabaseUrl = 'https://shhilcjxcqtkifhikuvs.supabase.co/rest/v1';
      const apikey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InNoaGlsY2p4Y3F0a2lmaGlrdXZzIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjQxMzk3MjAsImV4cCI6MjA3OTcxNTcyMH0.tJyUQyOxlMyuGv7XbG4R2Ue7lSX_5xLrpTkIno_CjbE';

      // 1. Create a submission
      const subRes = await fetch(`${supabaseUrl}/form_submissions`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Prefer': 'return=representation',
          'apikey': apikey,
          'Authorization': `Bearer ${apikey}`
        },
        body: JSON.stringify({ form_id: formId, status: 'New' })
      });
      
      const subData = await subRes.json();
      if (!subData || subData.length === 0) throw new Error("Could not create submission");
      const submissionId = subData[0].id;

      // 2. Insert answers
      const answersPayload = [
        { submission_id: submissionId, question_id: '431e77e9-ac8c-49e2-b07b-bae6f6f46a09', answer_text: q1 },
        { submission_id: submissionId, question_id: 'de173ab3-b713-4dc5-be82-acf8f99efa1d', answer_text: q2 },
        { submission_id: submissionId, question_id: '671fdae6-5de0-44a3-bf61-4ec6b7150dbd', answer_text: q3 },
        { submission_id: submissionId, question_id: '09775d74-1ed9-462e-93a2-0ab1efb13f31', answer_text: q4 },
        { submission_id: submissionId, question_id: '36c3a7ba-8324-4026-8e5a-d8ca457ad9dc', answer_text: q5 },
        { submission_id: submissionId, question_id: 'fcc96573-8f92-4504-bc31-59e0875d9fce', answer_text: q6 },
        { submission_id: submissionId, question_id: '58f60984-1546-46ef-9cfa-2b07cce3b016', answer_text: q7 },
      ];

      await fetch(`${supabaseUrl}/form_answers`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Prefer': 'return=representation',
          'apikey': apikey,
          'Authorization': `Bearer ${apikey}`
        },
        body: JSON.stringify(answersPayload)
      });

      console.log('Successfully submitted to TaskFlow Pro via DB integration.');
    } catch (err) {
      console.error('Error sending to TaskFlow', err);
    }
  };

  const handleUserInput = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputValue.trim()) return;

    const userText = inputValue.trim();
    // Add user message
    setMessages((prev) => [
      ...prev,
      {
        id: Date.now().toString(),
        type: 'user',
        text: userText
      }
    ]);
    setInputValue('');

    // Bot response to arbitrary text
    setIsTyping(true);
    setTimeout(() => {
      setIsTyping(false);
      
      const aiResponse = generateCustomAIResponse([{role: 'user', content: userText}]);
      
      setMessages((prev) => [
        ...prev,
        {
          id: Date.now().toString(),
          type: 'bot',
          text: aiResponse.text,
          quickReplies: ["Let's begin", "About Founders", "What we do in PAT Financials", "Collection after your information", "Contact & Address"]
        }
      ]);
    }, 1000);
  };

  const progressPercentage = Math.round((currentStepIndex / STEPS.length) * 100);

  return (
    <>
      {/* Floating Button */}
      <div className="fixed bottom-6 right-6 z-[9990]">
        <button
          onClick={() => setIsOpen(true)}
          className={`w-16 h-16 bg-brand-primary text-white rounded-full shadow-2xl shadow-brand-primary/30 flex items-center justify-center hover:bg-brand-primary/90 transition-transform duration-300 transform hover:scale-110 ${isOpen ? 'scale-0 opacity-0' : 'scale-100 opacity-100'}`}
          aria-label="Open Chatbot"
        >
          <MessageSquare className="w-8 h-8" />
        </button>
      </div>

      {/* Chat Window */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.95 }}
            transition={{ duration: 0.2 }}
            onMouseEnter={() => setIsHovered(true)}
            onMouseLeave={() => setIsHovered(false)}
            data-lenis-prevent="true"
            className="fixed bottom-0 right-0 sm:bottom-6 sm:right-6 z-[9999] w-full sm:w-[420px] h-[100dvh] sm:h-[620px] sm:max-h-[85vh] bg-white sm:rounded-[20px] shadow-2xl border border-slate-200 flex flex-col overflow-hidden overscroll-contain"
            style={{ overscrollBehavior: 'contain' }}
          >
            {/* Header */}
            <div className="bg-brand-primary px-4 py-3 flex items-center justify-between text-white shrink-0">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-brand-secondary flex items-center justify-center">
                  <Bot className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h3 className="font-semibold text-[15px] leading-tight text-white">PAT Financials</h3>
                  <p className="text-[12px] text-white/75 leading-tight">Wealth Distributor Assistant</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <span className="bg-brand-secondary text-white text-[11px] px-2.5 py-1 rounded-full flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-white animate-pulse"></span> Online
                </span>
                <button
                  onClick={() => setIsOpen(false)}
                  className="text-white/70 hover:text-white transition-colors"
                  aria-label="Close Chatbot"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>
            
            {/* Progress Bar */}
            <div className="h-[3px] bg-slate-200 shrink-0 w-full">
               <div className="h-full bg-[#1D9E75] transition-all duration-500 ease-out" style={{ width: `${progressPercentage}%` }}></div>
            </div>

            {/* Messages */}
            <div ref={chatContainerRef} data-lenis-prevent="true" className="flex flex-col flex-1 min-h-0 overflow-y-auto p-4 bg-slate-50 space-y-4 overscroll-contain" style={{ WebkitOverflowScrolling: 'touch', overscrollBehavior: 'contain' }}>
              {messages.map((message) => (
                <div
                  key={message.id}
                  className={`flex flex-col ${message.type === 'user' ? 'items-end' : 'items-start'}`}
                >
                  {message.type === 'bot' || message.type === 'user' ? (
                    <div
                      className={`max-w-[85%] rounded-2xl p-3 text-[14px] leading-relaxed ${
                        message.type === 'user'
                          ? 'bg-brand-primary text-white rounded-tr-sm'
                          : 'bg-slate-100 text-slate-800 rounded-tl-sm shadow-sm'
                      }`}
                    >
                      <div className={`pred pred-sm max-w-none pred-p:leading-relaxed pred-strong:font-semibold ${message.type === 'user' ? 'text-white' : 'text-slate-900'}`}>
                         <Markdown>{message.text || ''}</Markdown>
                      </div>
                    </div>
                  ) : message.type === 'form' ? (
                     <div className="w-full max-w-[90%] bg-white border border-slate-200 shadow-sm rounded-2xl rounded-tl-sm p-4">
                        <div className="pred pred-sm max-w-none pred-p:leading-relaxed pred-strong:font-semibold mb-4 text-[14px] text-slate-800">
                           <Markdown>{message.text || ''}</Markdown>
                        </div>
                        {message.fields && message.fields.length > 0 ? (
                           <form 
                             className="flex flex-col gap-3"
                             onSubmit={(e) => {
                               e.preventDefault();
                               const fd = new FormData(e.currentTarget);
                               const data: Record<string, string> = {};
                               message.fields?.forEach(f => {
                                 data[f.key] = (fd.get(f.key) as string) || '';
                               });
                               handleFormSubmit(message.stepId!, data, message.id);
                             }}
                           >
                             {message.fields.map((field) => (
                               <div key={field.key} className="flex flex-col gap-1">
                                 <label className="text-[12px] font-medium text-slate-500">{field.label}</label>
                                 {field.label.toLowerCase().includes('concern') || field.label.toLowerCase().includes('note') ? (
                                    <textarea 
                                      name={field.key}
                                      placeholder={field.ph}
                                      defaultValue={collectedData[field.key] || ''}
                                      className="px-3 py-2 border border-slate-200 rounded-lg text-[13px] bg-slate-50 text-slate-800 focus:outline-none focus:border-[#0F4C35] focus:ring-1 focus:ring-[#0F4C35] resize-none"
                                      rows={2}
                                    />
                                 ) : (
                                    <input 
                                      name={field.key}
                                      placeholder={field.ph}
                                      defaultValue={collectedData[field.key] || ''}
                                      className="px-3 py-2 border border-slate-200 rounded-lg text-[13px] bg-slate-50 text-slate-800 focus:outline-none focus:border-brand-primary focus:ring-1 focus:ring-brand-primary"
                                    />
                                 )}
                               </div>
                             ))}
                             <button type="submit" className="mt-2 bg-brand-primary hover:bg-brand-primary/90 text-white py-2.5 rounded-lg text-[13px] font-medium transition-colors">
                               {message.stepId === 'slot' ? '📅 Submit Consultation Request' : 'Continue →'}
                             </button>
                           </form>
                        ) : (
                           <div className="bg-[#EAF3DE] border border-[#97C459] text-[#3B6D11] px-3 py-2 rounded-lg text-[13px] font-medium flex items-center gap-2">
                              ✓ Saved successfully
                           </div>
                        )}
                     </div>
                  ) : null}

                  {/* Message Time and Quick Replies */}
                  {message.type !== 'form' && (
                    <span className="text-[11px] text-slate-400 mt-1 px-1">
                      {new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </span>
                  )}
                  
                  {message.quickReplies && message.quickReplies.length > 0 && !message.hideQuickReplies && (
                    <div className="flex flex-wrap gap-2 mt-3 mb-2">
                       {message.quickReplies.map((reply, idx) => (
                         <button 
                           key={idx}
                           onClick={() => handleQuickReply(reply, message.id)}
                           className="text-[13px] px-3.5 py-1.5 border border-[#0F4C35] text-[#0F4C35] rounded-full hover:bg-[#0F4C35] hover:text-white transition-colors bg-transparent"
                         >
                           {reply}
                         </button>
                       ))}
                    </div>
                  )}
                </div>
              ))}
              
              {isTyping && (
                <div className="flex justify-start">
                  <div className="bg-white border border-slate-200 shadow-sm rounded-2xl rounded-tl-sm px-4 py-3 flex items-center gap-1.5">
                    <span className="w-1.5 h-1.5 bg-slate-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }}></span>
                    <span className="w-1.5 h-1.5 bg-slate-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }}></span>
                    <span className="w-1.5 h-1.5 bg-slate-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }}></span>
                  </div>
                </div>
              )}
            </div>

          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
};

