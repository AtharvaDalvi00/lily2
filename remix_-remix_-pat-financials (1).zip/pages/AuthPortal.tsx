import React, { useEffect } from 'react';
import { Link } from 'react-router-dom';
import { ArrowLeft, User, KeyRound, Phone, Mail } from 'lucide-react';
import { motion } from 'motion/react';

export const AuthPortal: React.FC = () => {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  return (
    <div className="pt-28 pb-12 md:pb-16 flex flex-col items-center relative isolation overflow-hidden">
      {/* Background Image & Overlay */}
      <div 
        className="absolute inset-0 -z-20 w-full h-full bg-cover bg-center opacity-40 mix-blend-multiply"
        style={{ backgroundImage: 'url("https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?q=80&w=2564&auto=format&fit=crop")' }}
      ></div>
      <div className="absolute inset-0 -z-10 w-full h-full bg-gradient-to-b from-white/80 via-white/70 to-slate-50/90 backdrop-blur-[2px]"></div>

      <motion.div 
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
        className="container mx-auto px-4 md:px-6 w-full flex flex-col justify-start max-w-6xl"
      >
        
        <div className="mb-10 w-full max-w-5xl mx-auto flex flex-col md:flex-row justify-between items-start md:items-center gap-4 relative z-10">
          <Link to="/" className="inline-flex items-center gap-2 px-4 py-2 bg-white/50 hover:bg-slate-50 text-slate-600 font-medium rounded-full border border-slate-200 transition-all shadow-sm hover:shadow-md group">
            <ArrowLeft className="w-4 h-4 group-hover:-translate-x-1 transition-transform" /> Back
          </Link>

          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3 sm:gap-6 bg-slate-50/80 px-4 sm:px-5 py-2.5 sm:py-2 rounded-2xl sm:rounded-full border border-slate-200 backdrop-blur-sm shadow-sm w-full md:w-auto">
            <span className="text-sm font-bold text-slate-700 hidden md:inline-block">Facing issues? Connect with us:</span>
            <a href="tel:+919920402965" className="text-slate-700 hover:text-brand-primary transition-colors text-sm font-semibold flex items-center gap-2">
              <div className="bg-brand-primary/10 p-1.5 rounded-full"><Phone className="w-3.5 h-3.5 text-brand-primary" /></div>
              +91 99204 02965
            </a>
            <span className="text-slate-300 hidden sm:inline-block">|</span>
            <a href="mailto:www.patfinancials.com@gmail.com" className="text-slate-700 hover:text-brand-secondary transition-colors text-sm font-semibold flex items-center gap-2">
              <div className="bg-brand-secondary/10 p-1.5 rounded-full"><Mail className="w-3.5 h-3.5 text-brand-secondary" /></div>
              www.patfinancials.com@gmail.com
            </a>
          </div>
        </div>

        <div className="flex flex-col md:flex-row items-center justify-center gap-4 md:gap-6 lg:gap-8 max-w-5xl mx-auto w-full">
          {/* Option 1: FUNDZBAZAR - Already Registered */}
          <a href="https://www.fundzbazar.com/signin" target="_blank" rel="noopener noreferrer" className="group relative w-56 h-56 md:w-64 md:h-64 rounded-full shadow-2xl hover:-translate-y-2 transition-transform duration-300 flex flex-col items-center justify-center bg-transparent border border-slate-100"
             style={{
               boxShadow: '0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04)'
             }}>
             <img src="https://pradnyatamhane.com/media/images/login/reg.png" alt="Already Registered" className="w-full h-full object-contain scale-100 group-hover:scale-105 transition-transform duration-500" />
          </a>

          {/* Option 2: FUNDZBAZAR - Not Yet Registered */}
          <a href="https://fundzbazar.com/Link/IItViMjRcaE" target="_blank" rel="noopener noreferrer" className="group relative w-56 h-56 md:w-64 md:h-64 rounded-full shadow-2xl hover:-translate-y-2 transition-transform duration-300 flex flex-col items-center justify-center bg-transparent border border-slate-100"
             style={{
               boxShadow: '0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04)'
             }}>
             <img src="https://pradnyatamhane.com/media/images/login/non-reg.png" alt="Not Yet Registered" className="w-full h-full object-contain scale-100 group-hover:scale-105 transition-transform duration-500" />
          </a>

          {/* Option 3: Client Login */}
          <a href="https://www.prudentcorporate.com/domaincdesk/(S(gh1zdpyqtc4z4ou4h0npwmay))/index.aspx?hmuTWVbf2WhMPOClgTTh5w==" target="_blank" rel="noopener noreferrer" className="group relative w-56 h-56 md:w-64 md:h-64 rounded-full shadow-2xl hover:-translate-y-2 transition-transform duration-300 flex flex-col items-center justify-center bg-transparent border border-slate-100"
             style={{
               boxShadow: '0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04)'
             }}>
             <img src="https://pradnyatamhane.com/media/images/login/2.png" alt="Client Login" className="w-full h-full object-contain scale-100 group-hover:scale-105 transition-transform duration-500" />
          </a>

        </div>
      </motion.div>
    </div>
  );
};
