import React, { useEffect } from 'react';
import { ScrollReveal } from '../components/ui/ScrollReveal';
import { Link } from 'react-router-dom';
import { Scroll, Users, ShieldCheck, ArrowLeft } from 'lucide-react';
import { ContactCTA } from '../components/ContactCTA';

export const EstateLegacyDetails: React.FC = () => {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  return (
    <>
      <ScrollReveal>
      <section className="py-20 bg-brand-light relative overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img src="https://images.unsplash.com/photo-1521791136064-7986c2920216?w=1600&q=80" alt="Background" className="w-full h-full object-cover opacity-[0.06] mix-blend-multiply" />
        </div>
        <div className="absolute top-0 right-0 w-64 h-64 bg-brand-primary/10 rounded-full blur-3xl"></div>
        <div className="absolute bottom-0 left-0 w-64 h-64 bg-brand-secondary/10 rounded-full blur-3xl"></div>
        
        <div className="container mx-auto px-4 md:px-6 relative z-10 text-center max-w-4xl pt-16">
          
          <Link to="/" className="inline-flex items-center gap-2 px-4 py-2 bg-white/50 hover:bg-white text-brand-primary font-medium rounded-full mb-8 backdrop-blur-sm border border-slate-200/50 hover:border-brand-primary/30 transition-all shadow-sm hover:shadow-md group">
            <ArrowLeft className="w-4 h-4 group-hover:-translate-x-1 transition-transform" /> Back to Home
          </Link>
          <h1 className="text-5xl md:text-6xl font-display font-bold text-brand-dark mb-6">Estate & Legacy</h1>
          <p className="text-xl text-slate-600 mb-8 leading-relaxed">
            Passing on your wealth smoothly to the next generation. We ensure your life's work benefits the people and causes you love, without legal friction.
          </p>
        </div>
      </section>
      </ScrollReveal>

      <ScrollReveal>
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4 md:px-6 max-w-4xl">
          <div className="pred pred-lg pred-slate max-w-none text-slate-600 space-y-6">
            <h2 className="text-3xl font-display font-bold text-brand-dark">Why Do You Need Estate Planning?</h2>
            <p>
              Wealth creation takes a lifetime; ensuring it reaches the right hands requires deliberate planning today. Without a structured estate plan, your family could face lengthy probate processes, familial disputes, and unintended tax liabilities. Estate and Legacy planning secures seamless inter-generational wealth transfer, protecting your heirs while preserving family harmony.
            </p>
            
            <h3 className="text-2xl font-display font-bold text-brand-dark mt-12 mb-4">Our Approach</h3>
            
            <div className="grid md:grid-cols-3 gap-8 my-8">
              <div className="bg-slate-50 p-6 rounded-2xl border border-slate-100 shadow-sm">
                <Scroll className="w-10 h-10 text-brand-primary mb-4" />
                <h4 className="text-lg font-bold text-brand-dark mb-2">Wills & Trusts</h4>
                <p className="text-sm">We assist in the meticulous drafting of wills and the creation of private family trusts to dictate exactly how and when your assets are distributed.</p>
              </div>
              
              <div className="bg-slate-50 p-6 rounded-2xl border border-slate-100 shadow-sm">
                <Users className="w-10 h-10 text-brand-primary mb-4" />
                <h4 className="text-lg font-bold text-brand-dark mb-2">Nomination Checks</h4>
                <p className="text-sm">A thorough audit of your entire financial portfolio to verify that nominations and joint-holdings align perfectly with your ultimate intentions.</p>
              </div>
              
              <div className="bg-slate-50 p-6 rounded-2xl border border-slate-100 shadow-sm">
                <ShieldCheck className="w-10 h-10 text-brand-primary mb-4" />
                <h4 className="text-lg font-bold text-brand-dark mb-2">Legal Coordination</h4>
                <p className="text-sm">We collaborate with specialized legal and tax professionals to ensure your estate plan is legally sound, tax-efficient, and indisputable.</p>
              </div>
            </div>

            <h3 className="text-2xl font-display font-bold text-brand-dark mt-12 mb-4">The Result</h3>
            <p>
              A formalized, legally binding structure that reflects your deepest values. Your legacy continues exactly as you envisioned it, providing enduring security and prosperity for the generations that follow.
            </p>
          </div>
        </div>
      </section>
      </ScrollReveal>
      
      <ContactCTA />
    </>
  );
};
