import React from 'react';
import { Play, Instagram, Youtube } from 'lucide-react';

const videos = [
  {
    id: 'RLXn_KH0Yb0',
    title: 'The Right Investment Strategy for Every Age | Pradnya Tamhane',
    thumbnail: 'https://img.youtube.com/vi/RLXn_KH0Yb0/maxresdefault.jpg',
    link: 'https://www.youtube.com/watch?v=RLXn_KH0Yb0'
  },
  {
    id: 'A7w19T1eoBM',
    title: 'The Mutual Fund Playbook',
    thumbnail: 'https://img.youtube.com/vi/A7w19T1eoBM/maxresdefault.jpg',
    link: 'https://www.youtube.com/watch?v=A7w19T1eoBM'
  },
  {
    id: 'wWK6zszmfuo',
    title: 'How to Manage Your Monthly Salary?',
    thumbnail: 'https://img.youtube.com/vi/wWK6zszmfuo/maxresdefault.jpg',
    link: 'https://www.youtube.com/watch?v=wWK6zszmfuo'
  },
  {
    id: 'nEDvvyhSLJo',
    title: 'The Zero-Cost Home Strategy',
    thumbnail: 'https://img.youtube.com/vi/nEDvvyhSLJo/maxresdefault.jpg',
    link: 'https://www.youtube.com/watch?v=nEDvvyhSLJo'
  }
];

export const Videos: React.FC = () => {
  return (
    <section className="py-16 bg-slate-50">
      <div className="container mx-auto px-4 md:px-6">
        <div className="flex flex-col md:flex-row justify-between items-end mb-12">
           <div>
              <h2 className="text-4xl font-display font-bold text-brand-dark mb-4">Your Weekly Dose of Smart Money Moves.</h2>
              <p className="text-slate-600 text-lg">Weekly updates, educational series, and deep dives into the economy.</p>
           </div>
           <div className="flex gap-4 mt-4 md:mt-0">
             <a href="https://www.youtube.com/@cfppradnya." target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-full text-sm font-bold hover:bg-blue-700 transition-colors">
               <Youtube className="w-4 h-4" /> Subscribe
             </a>
             <a href="https://www.instagram.com/cfppradnya_pat?igsh=MTdsN2JldzVtY3h4cg==" target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 px-4 py-2 bg-sky-600 text-white rounded-full text-sm font-bold hover:bg-sky-700 transition-colors">
               <Instagram className="w-4 h-4" /> Follow
             </a>
           </div>
        </div>

        {/* Main Youtube Section */}
        <div className="grid lg:grid-cols-3 gap-8 mb-12">
           <a 
             href="https://www.youtube.com/watch?v=1i3yAX032CI" 
             target="_blank" 
             rel="noopener noreferrer"
             className="lg:col-span-2 relative group cursor-pointer rounded-2xl overflow-hidden shadow-lg block w-full h-[300px] md:h-[400px] bg-slate-900"
           >
              {/* Blurred background for irregular aspect ratios */}
              <div className="absolute inset-0 z-0">
                <img src="https://img.youtube.com/vi/1i3yAX032CI/maxresdefault.jpg" alt="Background" className="w-full h-full object-cover blur-xl opacity-60 scale-110" />
              </div>
              
              <img src="https://img.youtube.com/vi/1i3yAX032CI/maxresdefault.jpg" alt="Main Video" className="relative z-10 w-full h-full object-cover transition-transform duration-700 group-hover:scale-105" />
              
              <div className="absolute inset-0 z-20 bg-black/30 group-hover:bg-black/40 transition-colors flex items-center justify-center">
                 <div className="w-20 h-20 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center group-hover:scale-110 transition-transform">
                    <div className="w-16 h-16 bg-white rounded-full flex items-center justify-center shadow-xl">
                       <Play className="w-6 h-6 text-brand-primary fill-brand-primary ml-1" />
                    </div>
                 </div>
              </div>
              <div className="absolute z-30 bottom-0 left-0 right-0 p-6 bg-gradient-to-t from-black/80 to-transparent">
                 <h3 className="text-2xl font-bold text-white">Financial Clarity: Conversations That Change the Way You Handle Money</h3>
              </div>
           </a>
           
           <div className="flex flex-col gap-4 h-[400px] overflow-y-auto pr-2 custom-scrollbar">
              {videos.map((video) => (
                <a 
                  key={video.id} 
                  href={video.link}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex gap-4 bg-white p-3 rounded-xl shadow-sm hover:shadow-md transition-all cursor-pointer group"
                >
                   <div className="relative w-32 h-20 flex-shrink-0 rounded-lg overflow-hidden">
                      <img src={video.thumbnail} alt={video.title} className="w-full h-full object-cover" />
                      <div className="absolute inset-0 flex items-center justify-center bg-black/20 group-hover:bg-black/10">
                         <Play className="w-6 h-6 text-white" />
                      </div>
                   </div>
                   <div>
                      <h4 className="font-bold text-slate-800 text-sm leading-tight mb-1 group-hover:text-brand-primary transition-colors line-clamp-2">{video.title}</h4>
                      <p className="text-xs text-slate-500 flex items-center gap-1"><Youtube className="w-3 h-3" /> Watch Now</p>
                   </div>
                </a>
              ))}
           </div>
        </div>
      </div>
    </section>
  );
};