import React from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'motion/react';
import { 
  Briefcase, TrendingUp, LineChart, Shield, Landmark, 
  Coins, Plane, FileHeart, PieChart, ArrowRight
} from 'lucide-react';
import { ServiceItem } from '../types';
import { ComprehensivePortfolio } from './ComprehensivePortfolio';

const ManRestingIcon = (props: React.SVGProps<SVGSVGElement>) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width="24"
    height="24"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
    {...props}
  >
    {/* Rocker Base */}
    <path d="M 4 16 A 12 12 0 0 0 20 16" />
    {/* Chair Seat/Back */}
    <path d="M 5 6.5 L 7.5 11.5 A 2.5 2.5 0 0 0 10 14 L 15 10.5" />
    {/* Rear Leg */}
    <path d="M 7.5 11.5 L 6 17" />
    {/* Front Leg */}
    <path d="M 11.5 13 L 14.5 18" />
    {/* Person Head */}
    <circle cx="8" cy="4.5" r="1.5" />
    {/* Person Body */}
    <path d="M 8 7.5 L 10 11.5 L 14 8.5 L 17 13" />
  </svg>
);

const services: ServiceItem[] = [
  { title: 'Financial Structuring', description: 'Comprehensive roadmaps aligned with your life goals.', icon: Briefcase, path: '/financial-planning' },
  { title: 'Wealth Distributor', description: 'Holistic management of your assets for long-term growth.', icon: TrendingUp, path: '/wealth-management' },
  { title: 'Investment Portfolio', description: 'Diversified baskets of equity, debt, and gold.', icon: PieChart, path: '/investment-portfolio' },
  { title: 'Mutual Funds', description: 'Expert selection of top-performing funds.', icon: LineChart, path: '/mutual-funds' },
  { title: 'Insurance Planning', description: 'Protecting your family and assets against uncertainties.', icon: Shield, path: '/insurance-planning' },
  { title: 'Amortisation Schedule', description: 'Understand your investment growth and withdrawal impact.', icon: Landmark, path: '/amortisation-schedule' },
  { title: 'Retirement Roadmap', description: 'Secure your golden years with stress-free corpus building.', icon: ManRestingIcon as any, path: '/retirement-planning' },
  { title: 'NRI Solutions', description: 'Specialized investment services for global Indians.', icon: Plane, path: '/nri-solutions' },
  { title: 'Risk Profiling', description: 'Understanding your appetite to tailor the perfect plan.', icon: Coins, path: '/risk-profiling' },
  { title: 'Estate & Legacy', description: 'Passing on your wealth smoothly to the next generation.', icon: FileHeart, path: '/estate-legacy' },
];

export const Services: React.FC = () => {
  const navigate = useNavigate();

  return (
    <section id="services" className="py-16 bg-slate-50">
      <div className="container mx-auto px-4 md:px-6">
        <div className="text-center max-w-3xl mx-auto mb-12">
          <h2 className="text-4xl font-display font-bold text-brand-dark mb-4">Comprehensive Wealth Solutions</h2>
          <p className="text-slate-600 text-lg">We don't just sell products; we design solutions that fit your unique financial DNA.</p>
        </div>

        <ComprehensivePortfolio />

        <div className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {services.map((service, index) => (
            <motion.div 
              key={index} 
              initial={{ opacity: 0, y: -60, rotateX: 30 }}
              whileInView={{ opacity: 1, y: 0, rotateX: 0 }}
              viewport={{ once: false, margin: "-50px" }}
              transition={{ 
                duration: 0.6, 
                delay: index * 0.1,
                type: "spring",
                bounce: 0.4
              }}
              onClick={() => {
                if (service.path) {
                  navigate(service.path);
                }
              }}
              className={`group relative bg-white hover:bg-sky-50 p-8 rounded-3xl shadow-sm hover:shadow-2xl transition-all duration-500 hover:-translate-y-2 border border-slate-100 overflow-hidden ${service.path ? 'cursor-pointer' : ''}`}
            >
              {/* Creative Decorative Two Circles */}
              <div className="absolute -top-12 -right-12 w-32 h-32 rounded-full bg-gradient-to-br from-brand-primary/10 to-transparent transition-all duration-700 ease-in-out group-hover:scale-[2.5] opacity-0 group-hover:opacity-100"></div>
              <div className="absolute top-8 -right-4 w-16 h-16 rounded-full border-2 border-brand-primary/20 transition-all duration-500 delay-100 ease-out group-hover:-translate-x-6 group-hover:translate-y-2 group-hover:scale-150 opacity-0 group-hover:opacity-100"></div>
              
              <div className="relative z-10 flex flex-col h-full">
                <div className="w-14 h-14 bg-brand-light rounded-xl flex items-center justify-center mb-6 group-hover:bg-brand-primary group-hover:scale-110 group-hover:rotate-3 transition-all duration-300 shadow-sm group-hover:shadow-brand-primary/30">
                  <service.icon className="w-7 h-7 text-brand-primary group-hover:text-white transition-colors duration-300" />
                </div>
                
                <h3 className="text-xl font-bold text-brand-dark mb-3 group-hover:text-brand-primary transition-colors duration-300">{service.title}</h3>
                
                <p className="text-slate-600 leading-relaxed text-sm mb-6 flex-grow">{service.description}</p>
                
                {service.path && (
                  <div className="flex items-center text-brand-primary font-semibold text-sm opacity-0 -translate-x-4 group-hover:opacity-100 group-hover:translate-x-0 transition-all duration-300 mt-auto">
                    Learn more <ArrowRight className="w-4 h-4 ml-1 group-hover:translate-x-1 transition-transform" />
                  </div>
                )}
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};