import React, { useEffect } from 'react';
import { ScrollReveal } from '../components/ui/ScrollReveal';
import { Link } from 'react-router-dom';
import { Sunset, Leaf, Wallet, ArrowLeft } from 'lucide-react';
import { ContactCTA } from '../components/ContactCTA';

export const RetirementPlanningDetails: React.FC = () => {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  return (
    <>
      <ScrollReveal>
      <section className="py-20 bg-brand-light relative overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img src="https://images.unsplash.com/photo-1473186578172-c141e6798cf4?w=1600&q=80" alt="Background" className="w-full h-full object-cover opacity-[0.06] mix-blend-multiply" />
        </div>
        <div className="absolute top-0 right-0 w-64 h-64 bg-brand-primary/10 rounded-full blur-3xl"></div>
        <div className="absolute bottom-0 left-0 w-64 h-64 bg-brand-secondary/10 rounded-full blur-3xl"></div>
        
        <div className="container mx-auto px-4 md:px-6 relative z-10 text-center max-w-4xl pt-16">
          
          <Link to="/" className="inline-flex items-center gap-2 px-4 py-2 bg-white/50 hover:bg-white text-brand-primary font-medium rounded-full mb-8 backdrop-blur-sm border border-slate-200/50 hover:border-brand-primary/30 transition-all shadow-sm hover:shadow-md group">
            <ArrowLeft className="w-4 h-4 group-hover:-translate-x-1 transition-transform" /> Back to Home
          </Link>
          <h1 className="text-5xl md:text-6xl font-display font-bold text-brand-dark mb-6">Retirement Roadmap</h1>
          <p className="text-xl text-slate-600 mb-8 leading-relaxed">
            Secure your golden years with stress-free corpus building. Designing a life where working is an option, not a necessity.
          </p>
        </div>
      </section>
      </ScrollReveal>

      <ScrollReveal>
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4 md:px-6 max-w-4xl">
          <div className="pred pred-lg pred-slate max-w-none text-slate-600 space-y-6">
            <h2 className="text-3xl font-display font-bold text-brand-dark">Why Do You Need a Retirement Roadmap?</h2>
            <p>
              With increasing life expectancies and the absence of traditional pension nets, self-funding a retirement journey that could last 30 years or more is crucial. Inflation silently halves your purchasing power every decade. A retirement roadmap ensures you accumulate a corpus substantial enough to maintain your lifestyle, without fear of outliving your money.
            </p>
            
            <h3 className="text-2xl font-display font-bold text-brand-dark mt-12 mb-4">Our Approach</h3>
            
            <div className="grid md:grid-cols-3 gap-8 my-8">
              <div className="bg-slate-50 p-6 rounded-2xl border border-slate-100 shadow-sm">
                <Sunset className="w-10 h-10 text-brand-primary mb-4" />
                <h4 className="text-lg font-bold text-brand-dark mb-2">Corpus Calculation</h4>
                <p className="text-sm">We accurately estimate the future cost of your lifestyle, accounting for inflation and healthcare expenses, to determine your target retirement number.</p>
              </div>
              
              <div className="bg-slate-50 p-6 rounded-2xl border border-slate-100 shadow-sm">
                <Leaf className="w-10 h-10 text-brand-primary mb-4" />
                <h4 className="text-lg font-bold text-brand-dark mb-2">Accumulation Strategy</h4>
                <p className="text-sm">During your earning years, we deploy growth-oriented assets like equity mutual funds to aggressively build your corpus.</p>
              </div>
              
              <div className="bg-slate-50 p-6 rounded-2xl border border-slate-100 shadow-sm">
                <Wallet className="w-10 h-10 text-brand-primary mb-4" />
                <h4 className="text-lg font-bold text-brand-dark mb-2">Income Generation</h4>
                <p className="text-sm">Post-retirement, we transition the portfolio from aggressive growth to a "bucket strategy" that provides safe, tax-efficient, and regular cash flow.</p>
              </div>
            </div>

            <h3 className="text-2xl font-display font-bold text-brand-dark mt-12 mb-4">The Result</h3>
            <p>
              Financial independence on your terms. You step into your retirement with complete confidence, knowing you have a self-sustaining financial ecosystem that supports your dreams, travel, and healthcare needs without relying on anyone else.
            </p>
          </div>
        </div>
      </section>
      </ScrollReveal>
      
      <ContactCTA />
    </>
  );
};
