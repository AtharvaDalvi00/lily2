import React from 'react';
import { ArrowRight, TrendingUp, ShieldCheck, BarChart3 } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export const Hero: React.FC = () => {
  return (
    <section id="home" className="relative pt-24 pb-16 overflow-hidden bg-white">
      {/* Background Elements */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-20 left-10 w-64 h-64 bg-brand-primary/10 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-20 right-10 w-96 h-96 bg-brand-secondary/10 rounded-full blur-3xl animate-pulse delay-1000"></div>
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 text-[400px] font-bold text-slate-900/5 select-none pointer-events-none z-0">
          ₹
        </div>
      </div>

      <div className="container mx-auto px-4 md:px-6 relative z-10 grid lg:grid-cols-2 gap-12 items-center mb-16">
        {/* Text Content */}
        <motion.div 
          initial="hidden"
          animate="visible"
          variants={{
            hidden: { opacity: 0 },
            visible: { 
              opacity: 1,
              transition: { staggerChildren: 0.15, delayChildren: 0.1 }
            }
          }}
          className="space-y-8 text-center lg:text-left"
        >
          <motion.div 
            variants={{
              hidden: { opacity: 0, y: 40 },
              visible: { opacity: 1, y: 0, transition: { duration: 1, ease: [0.16, 1, 0.3, 1] } }
            }}
            className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-brand-primary/10 text-brand-primary text-sm font-semibold border border-brand-primary/20"
          >
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-brand-primary opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-brand-primary"></span>
            </span>
            Wealth Distributor Redefined
          </motion.div>

          <motion.h1 
            variants={{
              hidden: { opacity: 0, y: 40 },
              visible: { opacity: 1, y: 0, transition: { duration: 1, ease: [0.16, 1, 0.3, 1] } }
            }}
            className="text-5xl lg:text-7xl font-display font-bold text-brand-dark leading-[1.1]"
          >
            Shape Your Financial Future With <span className="text-transparent bg-clip-text bg-gradient-to-r from-brand-primary to-brand-secondary">Confidence</span>
          </motion.h1>

          <motion.p 
            variants={{
              hidden: { opacity: 0, y: 40 },
              visible: { opacity: 1, y: 0, transition: { duration: 1, ease: [0.16, 1, 0.3, 1] } }
            }}
            className="text-lg text-slate-600 max-w-xl mx-auto lg:mx-0 leading-relaxed"
          >
            Expert guidance for your financial journey. We blend human expertise with smart technology to build, manage, and grow your wealth over generations.
          </motion.p>

          <motion.div 
            variants={{
              hidden: { opacity: 0, y: 40 },
              visible: { opacity: 1, y: 0, transition: { duration: 1, ease: [0.16, 1, 0.3, 1] } }
            }}
            className="flex flex-col sm:flex-row items-center gap-4 justify-center lg:justify-start"
          >
            <a 
              href="https://task-flow-pro-23-01.vercel.app/#/p/810e568d-1824-48cf-bbc8-6809d003ae08"
              target="_blank"
              rel="noopener noreferrer"
              className="w-full sm:w-auto px-8 py-4 bg-brand-primary text-white font-semibold rounded-full hover:bg-blue-700 transition-all shadow-lg hover:shadow-brand-primary/30 flex items-center justify-center gap-2 group"
            >
              Book free consultation
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </a>
          </motion.div>
        </motion.div>

        {/* Visuals */}
        <motion.div 
          initial={{ opacity: 0, scale: 0.95, y: 40 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          transition={{ duration: 1.2, delay: 0.3, ease: [0.16, 1, 0.3, 1] }}
          className="relative h-[500px] w-full hidden lg:block"
        >
          <div className="absolute inset-0 bg-brand-primary/5 rounded-[40px] rotate-3"></div>
          
          <div className="absolute inset-0 w-full h-full rounded-[40px] shadow-2xl overflow-hidden grayscale-[20%] hover:grayscale-0 transition-all duration-700">
            { (() => {
              const [index, setIndex] = React.useState(0);
              const images = [
                "https://lh3.googleusercontent.com/pw/AP1GczOtYnBbiLK34LWMI0vPW6fCTBlQaqGaJBd_Udxse3uThPgHg5n1-A7wxP__74JnkfQiyxHH0JtnAWHIRDMSr8jQMyuD1r76suVdLLsAvGfb9ru9XtueQf2ZWew2clQZZRIW89zWhIh0zaatg9Cu1ELH=w1216-h913-s-no-gm?authuser=0",
                "https://lh3.googleusercontent.com/pw/AP1GczPbKbhPHBBGasDJKJILAe0F4B0Ofb_wrBJ4J8Pw8QGOha_mjb4gkQ0-gH5kmm1CPqfRKw0o_BkDqWeNTaQRRHl8-7ZyWbPxj1IwKq5jeMtiTc2UfIhJclz0JnoTbtMWkR6z0tnHtUZ1xH8QKDJI3y8P=w913-h913-s-no-gm?authuser=0"
              ];
              
              React.useEffect(() => {
                const timer = setInterval(() => {
                  setIndex((prev) => (prev + 1) % images.length);
                }, 5000);
                return () => clearInterval(timer);
              }, [images.length]);

              return (
                <AnimatePresence mode='wait'>
                  <motion.img 
                    key={index}
                    src={images[index]}
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    transition={{ duration: 1 }}
                    alt="Financial Growth Slider" 
                    className="absolute inset-0 w-full h-full object-cover"
                  />
                </AnimatePresence>
              );
            })()}
          </div>
          

        </motion.div>
      </div>
    </section>
  );
};