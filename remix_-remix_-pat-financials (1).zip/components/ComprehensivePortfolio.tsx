import React, { useState, useRef } from 'react';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip, Legend, Sector } from 'recharts';
import { motion, useInView } from 'motion/react';
import { ScrollReveal } from './ui/ScrollReveal';

const assetAllocationData = [
  { name: 'Equity', value: 70, color: '#0284C7' },
  { name: 'Debt', value: 10, color: '#3B82F6' },
  { name: 'Commodity', value: 5, color: '#0EA5E9' },
  { name: 'Real Estate', value: 15, color: '#60A5FA' },
];

const fundCategoryData = [
  { name: 'Large & Mid Cap', value: 22.89, color: '#0284C7' },
  { name: 'FOF', value: 3.41, color: '#1D4ED8' },
  { name: 'Liquid/Overnight', value: 1.10, color: '#38BDF8' },
  { name: 'Small cap', value: 22.64, color: '#1E3A8A' },
  { name: 'Short Duration', value: 13.33, color: '#7DD3FC' },
  { name: 'Thematic', value: 20.83, color: '#2563EB' },
  { name: 'Flexi Cap', value: 15.80, color: '#94A3B8' },
];

const productAllocationData = [
  { name: 'Mutual Funds', value: 35, color: '#0284C7' },
  { name: 'Stocks', value: 20, color: '#0EA5E9' },
  { name: 'FD', value: 10, color: '#3B82F6' },
  { name: 'Bonds', value: 10, color: '#1E3A8A' },
  { name: 'Insurance', value: 8, color: '#2563EB' },
  { name: 'NPS', value: 7, color: '#1D4ED8' },
  { name: 'PMF', value: 5, color: '#60A5FA' },
  { name: 'AIF', value: 3, color: '#94A3B8' },
  { name: 'SIF', value: 2, color: '#7DD3FC' },
];

const renderActiveShape = (props: any) => {
  const { cx, cy, innerRadius, outerRadius, startAngle, endAngle, fill } = props;

  return (
    <g>
      <Sector
        cx={cx}
        cy={cy}
        innerRadius={innerRadius - 4}
        outerRadius={outerRadius + 12}
        startAngle={startAngle}
        endAngle={endAngle}
        fill={fill}
        className="transition-all duration-300 cursor-pointer"
        filter="url(#3d-pie-active)"
      />
    </g>
  );
};

const CustomTooltip = ({ active, payload }: any) => {
  if (active && payload && payload.length) {
    return (
      <div className="bg-white p-3 border border-slate-200 shadow-xl rounded-lg text-sm">
        <p className="font-bold text-slate-800">{payload[0].name}</p>
        <p className="text-brand-primary font-semibold">{`${payload[0].value.toFixed(2)}%`}</p>
      </div>
    );
  }
  return null;
};

const renderCustomizedLabel = (props: any) => {
  const RADIAN = Math.PI / 180;
  const { cx, cy, midAngle, outerRadius, fill, payload, value } = props;
  const sin = Math.sin(-RADIAN * midAngle);
  const cos = Math.cos(-RADIAN * midAngle);
  
  // Start right at the outer edge or slightly inside
  const sx = cx + (outerRadius - 2) * cos;
  const sy = cy + (outerRadius - 2) * sin;
  
  // Extend slightly out
  const mx = cx + (outerRadius + 12) * cos;
  const my = cy + (outerRadius + 12) * sin;
  
  // Add a smaller elbow
  const ex = mx + (cos >= 0 ? 1 : -1) * 10;
  const ey = my;
  const textAnchor = cos >= 0 ? 'start' : 'end';

  return (
    <g className="transition-opacity duration-200 ease-in-out">
      <path d={`M${sx},${sy}L${mx},${my}L${ex},${ey}`} stroke={fill} fill="none" strokeWidth={1.5} opacity={0.6} className="transition-all duration-200" />
      <circle cx={ex} cy={ey} r={2} fill={fill} stroke="none" className="transition-all duration-200" />
      <text x={ex + (cos >= 0 ? 1 : -1) * 8} y={ey - 4} textAnchor={textAnchor} fill="#1e293b" className="font-bold text-[11px] md:text-sm transition-opacity duration-200" dy={0}>
        {payload.name}
      </text>
      <text x={ex + (cos >= 0 ? 1 : -1) * 8} y={ey + 12} textAnchor={textAnchor} fill="#475569" className="font-medium text-[10px] md:text-xs transition-opacity duration-200" dy={0}>
        {`(${value.toFixed(2)}%)`}
      </text>
    </g>
  );
};

const renderFilters = () => (
  <defs>
    <filter id="3d-pie" x="-20%" y="-20%" width="140%" height="140%">
      <feDropShadow dx="2" dy="8" stdDeviation="6" floodOpacity="0.25" floodColor="#001C3D" result="shadow" />
      
      <feOffset dx="-2" dy="-2" in="SourceAlpha" result="offsetBlur" />
      <feComposite in="SourceAlpha" in2="offsetBlur" operator="out" result="inverse" />
      <feFlood floodColor="white" floodOpacity="0.5" result="color" />
      <feComposite in="color" in2="inverse" operator="in" result="highlight" />

      <feOffset dx="4" dy="4" in="SourceAlpha" result="offsetBlur2" />
      <feComposite in="SourceAlpha" in2="offsetBlur2" operator="out" result="inverse2" />
      <feFlood floodColor="black" floodOpacity="0.3" result="color2" />
      <feComposite in="color2" in2="inverse2" operator="in" result="shadow2" />

      <feMerge>
        <feMergeNode in="shadow" />
        <feMergeNode in="SourceGraphic" />
        <feMergeNode in="highlight" />
        <feMergeNode in="shadow2" />
      </feMerge>
    </filter>

    <filter id="3d-pie-active" x="-20%" y="-20%" width="140%" height="140%">
      <feDropShadow dx="0" dy="12" stdDeviation="15" floodOpacity="0.4" floodColor="#001C3D" result="shadow" />
      
      <feOffset dx="-2" dy="-2" in="SourceAlpha" result="offsetBlur" />
      <feComposite in="SourceAlpha" in2="offsetBlur" operator="out" result="inverse" />
      <feFlood floodColor="white" floodOpacity="0.7" result="color" />
      <feComposite in="color" in2="inverse" operator="in" result="highlight" />

      <feOffset dx="4" dy="4" in="SourceAlpha" result="offsetBlur2" />
      <feComposite in="SourceAlpha" in2="offsetBlur2" operator="out" result="inverse2" />
      <feFlood floodColor="black" floodOpacity="0.4" result="color2" />
      <feComposite in="color2" in2="inverse2" operator="in" result="shadow2" />

      <feMerge>
        <feMergeNode in="shadow" />
        <feMergeNode in="SourceGraphic" />
        <feMergeNode in="highlight" />
        <feMergeNode in="shadow2" />
      </feMerge>
    </filter>
  </defs>
);

export const ComprehensivePortfolio: React.FC = () => {
  const [activeAssetIndex, setActiveAssetIndex] = useState<number | undefined>(undefined);
  const [activeFundIndex, setActiveFundIndex] = useState<number | undefined>(undefined);
  const [activeProductIndex, setActiveProductIndex] = useState<number | undefined>(undefined);
  
  const containerRef = useRef<HTMLDivElement>(null);
  const isInView = useInView(containerRef, { margin: "-20%" });

  const onPieEnterAsset = (_: any, index: number) => {
    setActiveAssetIndex(index);
  };
  const onPieLeaveAsset = () => {
    setActiveAssetIndex(undefined);
  };

  const onPieEnterFund = (_: any, index: number) => {
    setActiveFundIndex(index);
  };
  const onPieLeaveFund = () => {
    setActiveFundIndex(undefined);
  };

  const onPieEnterProduct = (_: any, index: number) => {
    setActiveProductIndex(index);
  };
  const onPieLeaveProduct = () => {
    setActiveProductIndex(undefined);
  };

  return (
    <div ref={containerRef} className="w-full max-w-7xl mx-auto mb-16 px-4 md:px-0">
      <div className="grid lg:grid-cols-3 md:grid-cols-2 gap-12 gap-y-16 justify-center">
        <motion.div
          initial={{ opacity: 0, rotate: -45, scale: 0.5 }}
          whileInView={{ opacity: 1, rotate: 0, scale: 1 }}
          viewport={{ once: false, margin: '-100px' }}
          transition={{ duration: 1, ease: 'backOut' }}
          className="w-full md:max-w-[400px] lg:max-w-none justify-self-center"
        >
          <h4 className="text-xl font-bold text-brand-dark mb-8 text-center" style={{ fontFamily: 'var(--font-display)' }}>Asset Allocation</h4>
          <div className="h-[350px] md:h-[400px]">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                {renderFilters()}
                <Pie
                  key={`asset-pie-${isInView}`}
                  activeIndex={activeAssetIndex}
                  activeShape={renderActiveShape}
                  data={assetAllocationData}
                  cx="50%"
                  cy="50%"
                  innerRadius="35%"
                  outerRadius="50%"
                  fill="#8884d8"
                  dataKey="value"
                  label={renderCustomizedLabel}
                  labelLine={false}
                  onMouseEnter={onPieEnterAsset}
                  onMouseLeave={onPieLeaveAsset}
                  isAnimationActive={true}
                  animationBegin={400}
                  animationDuration={1500}
                  animationEasing="ease-out"
                >
                  {assetAllocationData.map((entry, index) => (
                    <Cell 
                      key={`cell-${index}`} 
                      fill={entry.color} 
                      className="outline-none transition-all duration-300 cursor-pointer hover:brightness-110"
                      fillOpacity={activeAssetIndex === undefined || activeAssetIndex === index ? 1 : 0.4} 
                      filter={activeAssetIndex === undefined || activeAssetIndex === index ? "url(#3d-pie)" : "none"}
                    />
                  ))}
                </Pie>
                <Tooltip content={<CustomTooltip />} />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </motion.div>
        
        <motion.div
          initial={{ opacity: 0, rotate: 45, scale: 0.5 }}
          whileInView={{ opacity: 1, rotate: 0, scale: 1 }}
          viewport={{ once: false, margin: '-100px' }}
          transition={{ duration: 1, delay: 0.2, ease: 'backOut' }}
          className="w-full md:max-w-[400px] lg:max-w-none justify-self-center"
        >
          <h4 className="text-xl font-bold text-brand-dark mb-8 text-center" style={{ fontFamily: 'var(--font-display)' }}>Fund Category</h4>
          <div className="h-[350px] md:h-[400px]">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                {renderFilters()}
                <Pie
                  key={`fund-pie-${isInView}`}
                  activeIndex={activeFundIndex}
                  activeShape={renderActiveShape}
                  data={fundCategoryData}
                  cx="50%"
                  cy="50%"
                  innerRadius="35%"
                  outerRadius="50%"
                  fill="#8884d8"
                  dataKey="value"
                  label={renderCustomizedLabel}
                  labelLine={false}
                  onMouseEnter={onPieEnterFund}
                  onMouseLeave={onPieLeaveFund}
                  isAnimationActive={true}
                  animationBegin={800}
                  animationDuration={1500}
                  animationEasing="ease-out"
                >
                  {fundCategoryData.map((entry, index) => (
                    <Cell 
                      key={`cell-${index}`} 
                      fill={entry.color} 
                      className="outline-none transition-all duration-300 cursor-pointer hover:brightness-110" 
                      fillOpacity={activeFundIndex === undefined || activeFundIndex === index ? 1 : 0.4}
                      filter={activeFundIndex === undefined || activeFundIndex === index ? "url(#3d-pie)" : "none"}
                    />
                  ))}
                </Pie>
                <Tooltip content={<CustomTooltip />} />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </motion.div>
 
        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: false, margin: '-100px' }}
          transition={{ duration: 1, delay: 0.4, ease: 'backOut' }}
          className="w-full md:col-span-2 md:justify-self-center md:max-w-[400px] lg:col-span-1 lg:max-w-none"
        >
          <h4 className="text-xl font-bold text-brand-dark mb-8 text-center" style={{ fontFamily: 'var(--font-display)' }}>Product Allocation</h4>
          <div className="h-[350px] md:h-[400px]">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                {renderFilters()}
                <Pie
                  key={`product-pie-${isInView}`}
                  activeIndex={activeProductIndex}
                  activeShape={renderActiveShape}
                  data={productAllocationData}
                  cx="50%"
                  cy="50%"
                  innerRadius="35%"
                  outerRadius="50%"
                  fill="#8884d8"
                  dataKey="value"
                  label={renderCustomizedLabel}
                  labelLine={false}
                  onMouseEnter={onPieEnterProduct}
                  onMouseLeave={onPieLeaveProduct}
                  isAnimationActive={true}
                  animationBegin={1200}
                  animationDuration={1500}
                  animationEasing="ease-out"
                >
                  {productAllocationData.map((entry, index) => (
                    <Cell 
                      key={`cell-${index}`} 
                      fill={entry.color} 
                      className="outline-none transition-all duration-300 cursor-pointer hover:brightness-110" 
                      fillOpacity={activeProductIndex === undefined || activeProductIndex === index ? 1 : 0.4}
                      filter={activeProductIndex === undefined || activeProductIndex === index ? "url(#3d-pie)" : "none"}
                    />
                  ))}
                </Pie>
                <Tooltip content={<CustomTooltip />} />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </motion.div>
      </div>
      
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.6, delay: 0.4 }}
        className="mt-12 text-center max-w-3xl mx-auto"
      >
        <p className="text-lg md:text-xl text-slate-600 font-medium leading-relaxed">
          At <span className="text-brand-primary font-bold">PAT Financials</span>, this is how we meticulously plan and structure your wealth to ensure long-term growth and stability.
        </p>
      </motion.div>
    </div>
  );
};

