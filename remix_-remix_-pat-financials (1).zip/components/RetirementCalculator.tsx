import React, { useState, useEffect } from 'react';
import { X, Calculator, Download } from 'lucide-react';
import * as XLSX from 'xlsx';
import { LeadFormModal } from './LeadFormModal';

interface RetirementCalculatorProps {
  isOpen: boolean;
  onClose: () => void;
}

export const RetirementCalculator: React.FC<RetirementCalculatorProps> = ({ isOpen, onClose }) => {
  const [currentAge, setCurrentAge] = useState<number>(40);
  const [retirementAge, setRetirementAge] = useState<number>(60);
  const [lifeExpectancy, setLifeExpectancy] = useState<number>(85);
  const [currentExpenses, setCurrentExpenses] = useState<number>(50000);
  const [inflation, setInflation] = useState<number>(7);
  const [returnBeforeRetirement, setReturnBeforeRetirement] = useState<number>(12);
  const [returnAfterRetirement, setReturnAfterRetirement] = useState<number>(10);
  const [currentInvestment, setCurrentInvestment] = useState<number>(0);
  const [returnOnInvestment, setReturnOnInvestment] = useState<number>(10);

  // Outputs
  const [monthlyExpensesRetirement, setMonthlyExpensesRetirement] = useState<number>(0);
  const [requiredCorpus, setRequiredCorpus] = useState<number>(0);
  const [requiredLumpsum, setRequiredLumpsum] = useState<number>(0);
  const [requiredSip, setRequiredSip] = useState<number>(0);
  const [requiredStepUpSip, setRequiredStepUpSip] = useState<number>(0);
  const [schedule, setSchedule] = useState<any[]>([]);

  const formURL = "https://task-flow-pro-23-01.vercel.app/#/p/b8241986-9abe-4e33-974b-63f48dfcf893";
  const [isFormOpened, setIsFormOpened] = useState(false);
  const [isFormModalOpen, setIsFormModalOpen] = useState(false);

  useEffect(() => {
    const yearsToRetirement = Math.max(0, retirementAge - currentAge);
    const yearsInRetirement = Math.max(0, lifeExpectancy - retirementAge);

    if (yearsToRetirement <= 0 || yearsInRetirement <= 0) {
      setSchedule([]);
      return;
    }

    // Calculations
    const inflationRate = inflation / 100;
    const returnBefore = returnBeforeRetirement / 100;
    const returnAfter = returnAfterRetirement / 100;
    const returnInv = returnOnInvestment / 100;

    const monthlyExpAtRet = currentExpenses * Math.pow(1 + inflationRate, yearsToRetirement);
    const annualExpAtRet = monthlyExpAtRet * 12;
    
    // Calculate Required Retirement Corpus (PV of growing annuity with withdrawals at START of year)
    let corpus = 0;
    if (returnAfter === inflationRate) {
      corpus = yearsInRetirement * annualExpAtRet;
    } else {
      const k = (1 + inflationRate) / (1 + returnAfter);
      corpus = annualExpAtRet * (1 - Math.pow(k, yearsInRetirement)) / (1 - k);
    }

    // Current investment future value
    const investmentFV = currentInvestment * Math.pow(1 + returnInv, yearsToRetirement);
    const shortfall = Math.max(0, corpus - investmentFV);

    // Required Lumpsum today (disocunted at returnbefore)
    const reqLumpsum = shortfall / Math.pow(1 + returnBefore, yearsToRetirement);

    // Required Fixed SIP
    const rm = Math.pow(1 + returnBefore, 1 / 12) - 1;
    const months = yearsToRetirement * 12;
    let reqSip = 0;
    if (months > 0 && rm > 0) {
      reqSip = shortfall / (((Math.pow(1 + rm, months) - 1) / rm) * (1 + rm));
    } else if (months > 0) {
      reqSip = shortfall / months;
    }

    // Required 10% Step up SIP
    let fvMultiplier = 0;
    let currentMult = 1;
    const stepUpRate = 0.10; // 10%
    for (let i = 1; i <= yearsToRetirement; i++) {
      for (let m = 1; m <= 12; m++) {
        const monthsRemaining = yearsToRetirement * 12 - ((i - 1) * 12 + m);
        fvMultiplier += currentMult * Math.pow(1 + rm, monthsRemaining) * (1 + rm);
      }
      currentMult *= (1 + stepUpRate);
    }
    const reqStepUp = fvMultiplier > 0 ? shortfall / fvMultiplier : 0;

    setMonthlyExpensesRetirement(monthlyExpAtRet);
    setRequiredCorpus(corpus);
    setRequiredLumpsum(reqLumpsum);
    setRequiredSip(reqSip);
    setRequiredStepUpSip(reqStepUp);

    // Generate Schedule
    let currentBalance = corpus;
    let currentAnnualWithdrawal = annualExpAtRet;
    const tableData = [];

    for (let i = 1; i <= yearsInRetirement; i++) {
      const age = retirementAge + i;
      const startBalance = currentBalance;
      const annualW = currentAnnualWithdrawal;
      const monthlyW = annualW / 12;
      const remaining = startBalance - annualW;
      const endBalance = remaining > 0 ? remaining * (1 + returnAfter) : 0;

      tableData.push({
        year: i,
        age: age,
        startBalance: startBalance,
        annualWithdrawal: annualW,
        monthlyWithdrawal: monthlyW,
        remainingBalance: remaining,
        endBalance: endBalance
      });

      currentBalance = endBalance;
      currentAnnualWithdrawal = annualW * (1 + inflationRate);
    }

    setSchedule(tableData);

  }, [currentAge, retirementAge, lifeExpectancy, currentExpenses, inflation, returnBeforeRetirement, returnAfterRetirement, currentInvestment, returnOnInvestment]);

  if (!isOpen) return null;

  const formatCurrency = (val: number) => {
    if (isNaN(val) || !isFinite(val)) return '0';
    return new Intl.NumberFormat('en-IN', {
      maximumFractionDigits: 0
    }).format(Math.round(val));
  };

  const exportToExcel = () => {
    if (schedule.length === 0) return;
    
    const htmlContent = `
<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40">
<head>
<!--[if gte mso 9]>
<xml>
<x:ExcelWorkbook>
<x:ExcelWorksheets>
<x:ExcelWorksheet>
<x:Name>Retirement Plan</x:Name>
<x:WorksheetOptions>
<x:DisplayGridlines/>
<x:ProtectContents>True</x:ProtectContents>
</x:WorksheetOptions>
</x:ExcelWorksheet>
</x:ExcelWorksheets>
</x:ExcelWorkbook>
</xml>
<![endif]-->
<meta charset="utf-8">
<style>
  table { border-collapse: collapse; font-family: 'Segoe UI', Arial, sans-serif; }
  th, td { border: 1px solid #CBD5E1; padding: 10px; font-size: 11pt; mso-protection: locked hidden; }
  
  .title-cell { font-size: 16pt; font-weight: bold; color: #FFFFFF; background-color: #1D4ED8; padding: 15px; border: none; text-align: center; mso-protection: locked hidden; }
  
  .section-header { background-color: #3B82F6; color: #FFFFFF; font-weight: bold; font-size: 12pt; text-align: left; padding: 10px; mso-protection: locked hidden; }
  .grid-header { background-color: #1E293B; color: #FFFFFF; font-weight: bold; font-size: 11pt; text-align: center; mso-protection: locked hidden; }
  
  .label-cell { color: #334155; font-weight: 500; background-color: #F8FAFC; mso-protection: locked hidden; }
  .value-cell { text-align: right; font-weight: bold; color: #020617; mso-protection: locked hidden; }
  .input-cell { text-align: right; font-weight: bold; color: #020617; background-color: #FFFFD0; mso-protection: unlocked; border: 1px solid #94A3B8; }
  
  .result-label { font-weight: bold; color: #1D4ED8; background-color: #EFF6FF; border: 1px solid #BFDBFE; mso-protection: locked hidden; }
  .result-value { font-weight: bold; color: #1D4ED8; background-color: #DBEAFE; text-align: right; border: 1px solid #BFDBFE; mso-protection: locked hidden; }
  
  .schedule-row-even { background-color: #F8FAFC; }
  .schedule-row-odd { background-color: #FFFFFF; }
  
  .currency-cell { text-align: right; mso-protection: locked hidden; }
  .center-cell { text-align: center; mso-protection: locked hidden; }
  .empty-cell { background-color: #FFFFFF; border: none; mso-protection: locked hidden; }
</style>
</head>
<body>
  <table>
    <tr>
      <td class="title-cell" colspan="7">PAT FINANCIALS - RETIREMENT PLANNING REPORT</td>
    </tr>
    <tr><td colspan="7" style="border: none; height: 10px;"></td></tr>

    <tr><td class="section-header" colspan="7">INPUTS &amp; KEY ASSUMPTIONS</td></tr>
    <tr>
      <td class="label-cell" colspan="2">Current Age</td>
      <td class="input-cell" colspan="1">${currentAge}</td>
      <td class="empty-cell" style="border: none;"></td>
      <td class="label-cell" colspan="2">Assumed Inflation</td>
      <td class="input-cell" colspan="1">${inflation}</td>
    </tr>
    <tr>
      <td class="label-cell" colspan="2">Retirement Age</td>
      <td class="input-cell" colspan="1">${retirementAge}</td>
      <td class="empty-cell" style="border: none;"></td>
      <td class="label-cell" colspan="2">Assumed Return Before Retirement</td>
      <td class="input-cell" colspan="1">${returnBeforeRetirement}</td>
    </tr>
    <tr>
      <td class="label-cell" colspan="2">Life Expectancy</td>
      <td class="input-cell" colspan="1">${lifeExpectancy}</td>
      <td class="empty-cell" style="border: none;"></td>
      <td class="label-cell" colspan="2">Assumed Return After Retirement</td>
      <td class="input-cell" colspan="1">${returnAfterRetirement}</td>
    </tr>
    <tr>
      <td class="label-cell" colspan="2">Current Value of Linked Investment</td>
      <td class="input-cell" colspan="1">${currentInvestment}</td>
      <td class="empty-cell" style="border: none;"></td>
      <td class="label-cell" colspan="2">Assumed Return from Linked Investment</td>
      <td class="input-cell" colspan="1">${returnOnInvestment}</td>
    </tr>
    <tr>
      <td class="label-cell" colspan="2">Current Monthly Expenses</td>
      <td class="input-cell" colspan="1">${currentExpenses}</td>
      <td class="empty-cell" style="border: none;"></td>
      <td class="label-cell" colspan="2">Monthly Inflation Rate</td>
      <td class="value-cell" style="color: #1D4ED8;">=(1+G4/100)^(1/12)-1</td>
    </tr>
    <tr>
      <td class="label-cell" colspan="2">Monthly Return Rate Before</td>
      <td class="value-cell" colspan="1" style="color: #1D4ED8;">=(1+G5/100)^(1/12)-1</td>
      <td class="empty-cell" style="border: none;"></td>
      <td class="label-cell" colspan="2">Monthly Return Rate After</td>
      <td class="value-cell" style="color: #1D4ED8;">=(1+G6/100)^(1/12)-1</td>
    </tr>

    <tr><td colspan="7" style="border: none; height: 15px;"></td></tr>

    <tr><td class="section-header" colspan="7">RETIREMENT PLAN RESULTS (LIVE FORMULAS)</td></tr>
    <tr>
      <td class="result-label" colspan="4">Monthly Expenses @ Retirement (Inflation Adjusted)</td>
      <td class="result-value" colspan="3">=C8*(1+G4/100)^(C5-C4)</td>
    </tr>
    <tr>
      <td class="result-label" colspan="4">REQUIRED RETIREMENT CORPUS</td>
      <td class="result-value" colspan="3">=ROUND(IF(G6=G4, (C6-C5)*E12*12, E12*12*(1 - ((1 + G4/100) / (1 + G6/100))^(C6-C5)) / (1 - (1 + G4/100) / (1 + G6/100))), 0)</td>
    </tr>
    <tr>
      <td class="result-label" colspan="4">Required Lumpsum Investment (Today)</td>
      <td class="result-value" colspan="3">=ROUND(MAX(0, E13/(1+G5/100)^(C5-C4) - C7*(1+G7/100)^(C5-C4)), 0)</td>
    </tr>
    <tr>
      <td class="result-label" colspan="4">Required Fixed Monthly SIP</td>
      <td class="result-value" colspan="3">=ROUND(MAX(0, (E13 - C7*(1+G7/100)^(C5-C4)) / ((( (1 + C9)^((C5-C4)*12) - 1 ) / C9) * (1 + C9))), 0)</td>
    </tr>
    <tr>
      <td class="result-label" colspan="4">Required 10% Step-up Monthly SIP (1st Year)</td>
      <td class="result-value" colspan="3">${Math.round(requiredStepUpSip)}</td>
    </tr>

    <tr><td colspan="7" style="border: none; height: 15px;"></td></tr>

    <tr><td class="section-header" colspan="7">RETIREMENT PHASE WITHDRAWAL SCHEDULE (YEARS \${retirementAge + 1} TO \${lifeExpectancy})</td></tr>
    <tr>
      <td class="grid-header">YEAR</td>
      <td class="grid-header">AGE</td>
      <td class="grid-header">START OF YEAR BALANCE</td>
      <td class="grid-header">ANNUAL WITHDRAWAL</td>
      <td class="grid-header">MONTHLY WITHDRAWAL</td>
      <td class="grid-header">REMAINING BALANCE</td>
      <td class="grid-header">END OF YEAR BALANCE</td>
    </tr>
    ${schedule.map((row, idx) => {
      const rowClass = idx % 2 === 0 ? 'schedule-row-even' : 'schedule-row-odd';
      const r = 20 + idx; // Excel row index
      const startBalFormula = idx === 0 ? '=$E$13' : `=G${r - 1}`;
      const annualWFormula = idx === 0 ? '=$E$12*12' : `=D${r - 1}*(1+$G$4/100)`;
      return `
      <tr class="${rowClass}">
        <td class="center-cell">${row.year}</td>
        <td class="center-cell" style="font-weight: bold;">=$C$5+A${r}</td>
        <td class="currency-cell">${startBalFormula}</td>
        <td class="currency-cell" style="color: #1D4ED8; font-weight: 500;">${annualWFormula}</td>
        <td class="currency-cell">=D${r}/12</td>
        <td class="currency-cell">=MAX(0, C${r}-D${r})</td>
        <td class="currency-cell" style="font-weight: bold; color: #1E293B;">=ROUND(F${r}*(1+$G$6/100), 0)</td>
      </tr>
      `;
    }).join('')}
  </table>
</body>
</html>
`;

    const blob = new Blob([htmlContent], { type: 'application/vnd.ms-excel;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `retirement_plan_${new Date().toISOString().split('T')[0]}.xls`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 sm:p-6">
      <div className="absolute inset-0 bg-brand-dark/80 backdrop-blur-sm pointer-events-auto" onClick={onClose} />
      
      <div className="relative bg-[#FAFAFA] w-full max-w-7xl max-h-full sm:max-h-[95vh] rounded-2xl sm:rounded-[2rem] shadow-2xl flex flex-col overflow-hidden border border-slate-200">
        {/* Header */}
        <div className="flex flex-wrap items-center justify-between p-6 bg-brand-primary text-white border-b border-white/20 gap-4 shrink-0">
          <div className="flex items-center gap-3">
            <div className="bg-white/20 p-2.5 rounded-xl">
              <Calculator className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-xl font-bold tracking-tight">Retirement Calculator</h2>
              <p className="text-xs text-blue-100">Plan your retirement corpus and required investments</p>
            </div>
          </div>
          <div className="flex items-center gap-3 ml-auto">
            <button
              onClick={() => {
                if (!isFormOpened) {
                  setIsFormModalOpen(true);
                } else {
                  exportToExcel();
                }
              }}
              className={`flex items-center gap-2 ${isFormOpened ? 'bg-sky-600 hover:bg-sky-700' : 'bg-[#3B82F6] hover:bg-[#1D4ED8]'} text-white px-4 py-2 rounded-xl transition-colors font-semibold text-sm shadow-sm`}
            >
              <Download className="w-4 h-4" />
              {isFormOpened ? 'Download Excel Sheet' : 'Fill Form & Download'}
            </button>
            <LeadFormModal
              isOpen={isFormModalOpen}
              onClose={() => setIsFormModalOpen(false)}
              onSubmitAndDownload={() => {
                setIsFormOpened(true);
                setIsFormModalOpen(false);
                exportToExcel();
              }}
            />
            <button onClick={onClose} className="p-2.5 bg-white/10 hover:bg-white/20 rounded-xl transition-colors text-white">
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>
        <div className="flex flex-col lg:flex-row flex-1 overflow-hidden min-h-0">
        {/* Inputs Panel */}
           <div data-lenis-prevent="true" className="w-full lg:w-1/3 p-6 sm:p-8 bg-white border-r border-slate-200 overflow-y-auto shrink-0">
              <div className="space-y-6">
                 <div>
                    <label className="block text-sm font-semibold text-slate-700 mb-2">Current age</label>
                    <input 
                      type="number" 
                      value={currentAge || ''} 
                      onChange={(e) => setCurrentAge(Number(e.target.value))}
                      className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all font-medium text-slate-800"
                    />
                 </div>
                 <div>
                    <label className="block text-sm font-semibold text-slate-700 mb-2">Retirement age</label>
                    <input 
                      type="number" 
                      value={retirementAge || ''} 
                      onChange={(e) => setRetirementAge(Number(e.target.value))}
                      className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all font-medium text-slate-800"
                    />
                 </div>
                 <div>
                    <label className="block text-sm font-semibold text-slate-700 mb-2">Life expectancy age</label>
                    <input 
                      type="number" 
                      value={lifeExpectancy || ''} 
                      onChange={(e) => setLifeExpectancy(Number(e.target.value))}
                      className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all font-medium text-slate-800"
                    />
                 </div>
                 <div>
                    <label className="block text-sm font-semibold text-slate-700 mb-2">Current monthly expenses (₹)</label>
                    <input 
                      type="number" 
                      value={currentExpenses || ''} 
                      onChange={(e) => setCurrentExpenses(Number(e.target.value))}
                      className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all font-medium text-slate-800"
                    />
                 </div>
                 <div>
                    <label className="block text-sm font-semibold text-slate-700 mb-2">Assumed inflation (%)</label>
                    <input 
                      type="number" 
                      value={inflation || ''} 
                      onChange={(e) => setInflation(Number(e.target.value))}
                      className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all font-medium text-slate-800"
                    />
                 </div>
                 <div>
                    <label className="block text-sm font-semibold text-slate-700 mb-2">Assumed return before retirement (%)</label>
                    <input 
                      type="number" 
                      value={returnBeforeRetirement || ''} 
                      onChange={(e) => setReturnBeforeRetirement(Number(e.target.value))}
                      className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all font-medium text-slate-800"
                    />
                 </div>
                 <div>
                    <label className="block text-sm font-semibold text-slate-700 mb-2">Assumed return after retirement (%)</label>
                    <input 
                      type="number" 
                      value={returnAfterRetirement || ''} 
                      onChange={(e) => setReturnAfterRetirement(Number(e.target.value))}
                      className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all font-medium text-slate-800"
                    />
                 </div>
                 <div>
                    <label className="block text-sm font-semibold text-slate-700 mb-2">Current value of linked investment (₹)</label>
                    <input 
                      type="number" 
                      value={currentInvestment || ''} 
                      onChange={(e) => setCurrentInvestment(Number(e.target.value))}
                      className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all font-medium text-slate-800"
                    />
                 </div>
                 <div>
                    <label className="block text-sm font-semibold text-slate-700 mb-2">Assumed return from above investment (%)</label>
                    <input 
                      type="number" 
                      value={returnOnInvestment || ''} 
                      onChange={(e) => setReturnOnInvestment(Number(e.target.value))}
                      className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all font-medium text-slate-800"
                    />
                 </div>
              </div>
           </div>

           {/* Results Panel */}
           <div className="w-full lg:w-2/3 flex flex-col bg-[#FAFAFA] min-h-0">
              {/* Summary Cards */}
              <div className="p-6 sm:p-8 grid grid-cols-2 lg:grid-cols-3 gap-4 shrink-0 border-b border-slate-200 bg-white">
                 <div className="bg-slate-50 p-4 rounded-2xl border border-slate-100">
                    <p className="text-xs font-semibold text-slate-500 uppercase tracking-wide mb-1">Monthly Exp @ Retirement</p>
                    <p className="text-xl font-bold text-slate-800">₹{formatCurrency(monthlyExpensesRetirement)}</p>
                 </div>
                 <div className="bg-blue-50 p-4 rounded-2xl border border-blue-100">
                    <p className="text-xs font-semibold text-blue-600 uppercase tracking-wide mb-1">Required Corpus</p>
                    <p className="text-2xl font-black text-blue-700">₹{formatCurrency(requiredCorpus)}</p>
                 </div>
                 <div className="bg-slate-50 p-4 rounded-2xl border border-slate-100">
                    <p className="text-xs font-semibold text-slate-500 uppercase tracking-wide mb-1">Required Lumpsum</p>
                    <p className="text-xl font-bold text-slate-800">₹{formatCurrency(requiredLumpsum)}</p>
                 </div>
                 <div className="bg-sky-50 p-4 rounded-2xl border border-sky-100">
                    <p className="text-xs font-semibold text-sky-600 uppercase tracking-wide mb-1">Required Fixed SIP</p>
                    <p className="text-xl font-bold text-sky-700">₹{formatCurrency(requiredSip)}</p>
                 </div>
                 <div className="bg-blue-50 p-4 rounded-2xl border border-blue-100 lg:col-span-2">
                    <p className="text-xs font-semibold text-blue-600 uppercase tracking-wide mb-1">Required 10% Step-up SIP (1st Year)</p>
                    <p className="text-xl font-bold text-blue-700">₹{formatCurrency(requiredStepUpSip)}</p>
                 </div>
              </div>

              {/* Action Bar */}
              <div className="px-6 py-4 bg-white flex justify-between items-center border-b border-slate-200 shrink-0">
                 <h3 className="font-bold text-slate-800">Retirement Phase Schedule</h3>
                 <button 
                  onClick={() => {
                     if (!isFormOpened) {
                       setIsFormModalOpen(true);
                     } else {
                       exportToExcel();
                     }
                  }}
                  className={`flex items-center gap-2 ${isFormOpened ? 'bg-sky-600 hover:bg-sky-700' : 'bg-[#3B82F6] hover:bg-[#1D4ED8]'} text-white px-4 py-2 rounded-lg text-sm font-medium transition-colors`}
                 >
                    <Download className="w-4 h-4" /> {isFormOpened ? 'Download Excel' : 'Fill Form & Download'}
                 </button>
                 <LeadFormModal 
                    isOpen={isFormModalOpen}
                    onClose={() => setIsFormModalOpen(false)}
                    onSubmitAndDownload={() => {
                       setIsFormOpened(true);
                       setIsFormModalOpen(false);
                       exportToExcel();
                    }}
                 />
              </div>

             <div data-lenis-prevent="true" className="flex-1 overflow-auto bg-white p-6 sm:p-8">
                 <div className="border border-slate-200 rounded-2xl overflow-hidden bg-white">
                   <table className="w-full text-left text-sm whitespace-nowrap">
                      <thead className="bg-slate-50 sticky top-0 z-10 shadow-sm">
                         <tr>
                            <th className="px-4 py-3 font-semibold text-slate-600 border-b border-slate-200">Year</th>
                            <th className="px-4 py-3 font-semibold text-slate-600 border-b border-slate-200">Age</th>
                            <th className="px-4 py-3 font-semibold text-slate-600 border-b border-slate-200 text-right">Start Balance</th>
                            <th className="px-4 py-3 font-semibold text-slate-600 border-b border-slate-200 text-right">Annual W/D</th>
                            <th className="px-4 py-3 font-semibold text-slate-600 border-b border-slate-200 text-right">Monthly W/D</th>
                            <th className="px-4 py-3 font-semibold text-slate-600 border-b border-slate-200 text-right">Remain Balance</th>
                            <th className="px-4 py-3 font-semibold text-slate-600 border-b border-slate-200 text-right">End Balance</th>
                         </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100">
                         {schedule.map((row, idx) => (
                            <tr key={idx} className="hover:bg-slate-50 transition-colors">
                               <td className="px-4 py-3 text-slate-600">{row.year}</td>
                               <td className="px-4 py-3 font-medium text-slate-800">{row.age}</td>
                               <td className="px-4 py-3 text-right text-slate-600">₹{formatCurrency(row.startBalance)}</td>
                               <td className="px-4 py-3 text-right text-blue-600 font-medium">₹{formatCurrency(row.annualWithdrawal)}</td>
                               <td className="px-4 py-3 text-right text-slate-600">₹{formatCurrency(row.monthlyWithdrawal)}</td>
                               <td className="px-4 py-3 text-right text-slate-600">₹{formatCurrency(row.remainingBalance)}</td>
                               <td className="px-4 py-3 text-right text-slate-800 font-semibold">₹{formatCurrency(row.endBalance)}</td>
                            </tr>
                         ))}
                         {schedule.length === 0 && (
                            <tr>
                               <td colSpan={7} className="text-center p-8 text-slate-500">
                                  Invalid retirement duration. Check ages.
                               </td>
                            </tr>
                         )}
                      </tbody>
                   </table>
                 </div>
              </div>
           </div>
        </div>
      </div>
    </div>
  );
};
