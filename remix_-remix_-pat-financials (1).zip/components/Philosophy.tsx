import React from 'react';
import { motion } from 'motion/react';
import { Heart, Globe, Cpu, GraduationCap } from 'lucide-react';

const values = [
  {
    icon: Heart,
    title: 'Client-Centric',
    description: 'Your interests always come first. No hidden agendas, just pure advice.',
    color: 'text-blue-600',
    bgColor: 'bg-blue-50'
  },
  {
    icon: Globe,
    title: 'Holistic Wealth',
    description: 'Looking at the big picture—investment, tax, and legacy together.',
    color: 'text-sky-600',
    bgColor: 'bg-sky-50'
  },
  {
    icon: Cpu,
    title: 'Human + Data',
    description: 'Data-driven strategies delivered with human empathy.',
    color: 'text-blue-600',
    bgColor: 'bg-blue-50'
  },
  {
    icon: GraduationCap,
    title: 'Education First',
    description: 'Empowering you with knowledge to make informed decisions.',
    color: 'text-yellow-600',
    bgColor: 'bg-yellow-50'
  }
];

export const Philosophy: React.FC = () => {
  return (
    <section className="py-20 bg-brand-light">
      <div className="container mx-auto px-4 md:px-6">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <div>
            <h4 className="text-brand-primary font-semibold tracking-wide uppercase mb-2">Our Core Values</h4>
            <h2 className="text-4xl font-display font-bold text-brand-dark mb-6">Philosophy Driven by Purpose</h2>
            <p className="text-lg text-slate-600 mb-6">
              We believe that true wealth is not just about numbers; it's about freedom, security, and the ability to pursue what matters most to you.
            </p>
            <p className="text-lg text-slate-600">
              Our approach is rooted in transparency and education, ensuring you are always in the driver's seat of your financial life.
            </p>
          </div>

          <div className="grid sm:grid-cols-2 gap-6">
            {values.map((value, index) => (
              <motion.div 
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: false, margin: "-50px" }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                className="group relative bg-white hover:bg-sky-50 p-8 rounded-3xl shadow-sm hover:shadow-2xl transition-all duration-500 hover:-translate-y-2 border border-slate-100 overflow-hidden"
              >
                {/* Creative Decorative Background Elements */}
                <div className="absolute -top-16 -right-16 w-32 h-32 rounded-full bg-gradient-to-br from-brand-primary/10 to-transparent transition-all duration-700 ease-in-out group-hover:scale-[1.5] opacity-0 group-hover:opacity-100"></div>
                <div className="absolute top-8 -right-8 w-16 h-16 rounded-full border-2 border-brand-primary/20 transition-all duration-500 delay-100 ease-out group-hover:-translate-x-2 group-hover:translate-y-2 group-hover:scale-125 opacity-0 group-hover:opacity-100"></div>

                <div className="relative z-10 flex flex-col h-full">
                  <div className={`w-14 h-14 ${value.bgColor} rounded-xl flex items-center justify-center mb-6 group-hover:bg-brand-primary group-hover:scale-110 group-hover:rotate-3 transition-all duration-300 shadow-sm group-hover:shadow-brand-primary/30`}>
                    <value.icon className={`w-7 h-7 ${value.color} group-hover:text-white transition-colors duration-300`} />
                  </div>
                  
                  <h3 className="text-xl font-bold text-brand-dark mb-3 group-hover:text-brand-primary transition-colors duration-300">{value.title}</h3>
                  <p className="text-slate-600 leading-relaxed text-sm">{value.description}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};