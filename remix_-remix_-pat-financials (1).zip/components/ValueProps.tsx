import React from 'react';
import { Award, User, Map, RefreshCcw, Eye } from 'lucide-react';
import { motion } from 'motion/react';

const benefits = [
  { title: 'Legacy of Trust', desc: 'Over a decade of unwavering commitment to client success.', icon: Award, color: 'text-yellow-600', bg: 'bg-yellow-100' },
  { title: 'Founder-Led', desc: 'Direct involvement of Pradnya Tamhane in high-level strategy.', icon: User, color: 'text-brand-primary', bg: 'bg-brand-light' },
  { title: 'Customized Roadmaps', desc: 'Tailor-made plans that evolve with your life stages.', icon: Map, color: 'text-sky-600', bg: 'bg-sky-100' },
  { title: 'Continuous Review', desc: 'Proactive portfolio rebalancing to manage risk.', icon: RefreshCcw, color: 'text-blue-600', bg: 'bg-blue-100' },
  { title: 'Full Transparency', desc: 'Fee-only models available with zero hidden charges.', icon: Eye, color: 'text-blue-600', bg: 'bg-blue-100' },
];

export const ValueProps: React.FC = () => {
  return (
    <section className="py-16 bg-white">
      <div className="container mx-auto px-4 md:px-6">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: false, margin: "-50px" }}
          transition={{ duration: 0.5 }}
          className="text-center mb-12"
        >
          <h2 className="text-4xl font-display font-bold text-brand-dark mb-4">Why Choose PAT Financials?</h2>
          <p className="text-slate-600 max-w-2xl mx-auto">We build relationships, not just portfolios. Here is what sets us apart.</p>
        </motion.div>
        
        <div className="flex flex-wrap justify-center gap-8 lg:gap-6 xl:gap-8">
           {benefits.map((item, idx) => (
             <motion.div 
               key={idx} 
               initial={{ opacity: 0, scale: 0.8, y: 30 }}
               whileInView={{ opacity: 1, scale: 1, y: 0 }}
               viewport={{ once: false, margin: "-50px" }}
               transition={{ 
                 duration: 0.5, 
                 delay: idx * 0.15,
                 type: "spring",
                 bounce: 0.4
               }}
               className="flex flex-col items-center text-center group w-full sm:w-[calc(50%-2rem)] md:w-[calc(33.333%-2rem)] lg:w-auto lg:flex-1"
             >
                <div className={`w-16 h-16 ${item.bg} rounded-full flex items-center justify-center mb-6 shadow-sm group-hover:scale-110 transition-transform duration-300`}>
                   <item.icon className={`w-8 h-8 ${item.color}`} />
                </div>
                <h3 className="text-lg font-bold text-brand-dark mb-3">{item.title}</h3>
                <p className="text-sm text-slate-500 leading-relaxed">{item.desc}</p>
             </motion.div>
           ))}
        </div>
      </div>
    </section>
  );
};