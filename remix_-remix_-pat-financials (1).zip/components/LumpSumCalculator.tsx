import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, RefreshCw, Calculator, TrendingUp, Award, Calendar, Landmark, Download } from 'lucide-react';
import { LeadFormModal } from './LeadFormModal';

interface CalculationRow {
  year: number;
  age: number;
  additionalInvestment: number;
  totalInvested: number;
  yearEndValue: number;
}

interface LumpSumCalculatorProps {
  isOpen: boolean;
  onClose: () => void;
}

export const LumpSumCalculator: React.FC<LumpSumCalculatorProps> = ({ isOpen, onClose }) => {
  const [initialInvestment, setInitialInvestment] = useState(1000000);
  const [rate, setRate] = useState(12);
  const [durationYears, setDurationYears] = useState(25);
  const [currentAge, setCurrentAge] = useState(21);
  const [additionalInvestments, setAdditionalInvestments] = useState<{[key: number]: number}>({});
  const [results, setResults] = useState<CalculationRow[]>([]);
  const [selectedLookupAge, setSelectedLookupAge] = useState<number>(31);

  const formURL = "https://task-flow-pro-23-01.vercel.app/#/p/b8241986-9abe-4e33-974b-63f48dfcf893";
  const [isFormOpened, setIsFormOpened] = useState(false);
  const [isFormModalOpen, setIsFormModalOpen] = useState(false);

  const exportToExcel = () => {
    if (results.length === 0) return;

    const totalInvested = results[results.length - 1]?.totalInvested || initialInvestment;
    const finalValue = results[results.length - 1]?.yearEndValue || 0;
    const formatNumber = (val: number) => {
      return new Intl.NumberFormat('en-IN', {
        maximumFractionDigits: 2
      }).format(val);
    };

    const htmlContent = `
<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40">
<head>
<!--[if gte mso 9]>
<xml>
<x:ExcelWorkbook>
<x:ExcelWorksheets>
<x:ExcelWorksheet>
<x:Name>LumpSum Plan</x:Name>
<x:WorksheetOptions>
<x:DisplayGridlines/>
<x:ProtectContents>True</x:ProtectContents>
</x:WorksheetOptions>
</x:ExcelWorksheet>
</x:ExcelWorksheets>
</x:ExcelWorkbook>
</xml>
<![endif]-->
<meta charset="utf-8">
<style>
  table { border-collapse: collapse; font-family: 'Segoe UI', Arial, sans-serif; }
  th, td { border: 1px solid #CBD5E1; padding: 10px; font-size: 11pt; mso-protection: locked hidden; }
  
  .title-cell { font-size: 16pt; font-weight: bold; color: #FFFFFF; background-color: #2563EB; padding: 15px; border: none; text-align: center; mso-protection: locked hidden; }
  
  .section-header { background-color: #3B82F6; color: #FFFFFF; font-weight: bold; font-size: 12pt; text-align: left; padding: 10px; mso-protection: locked hidden; }
  .grid-header { background-color: #1E293B; color: #FFFFFF; font-weight: bold; font-size: 11pt; text-align: center; mso-protection: locked hidden; }
  
  .label-cell { color: #334155; font-weight: 500; background-color: #F8FAFC; mso-protection: locked hidden; }
  .value-cell { text-align: right; font-weight: bold; color: #020617; mso-protection: locked hidden; }
  .input-cell { text-align: right; font-weight: bold; color: #020617; background-color: #FFFFD0; mso-protection: unlocked; border: 1px solid #94A3B8; }
  
  .result-label { font-weight: bold; color: #1D4ED8; background-color: #EFF6FF; border: 1px solid #BFDBFE; mso-protection: locked hidden; }
  .result-value { font-weight: bold; color: #1D4ED8; background-color: #DBEAFE; text-align: right; border: 1px solid #BFDBFE; mso-protection: locked hidden; }
  
  .schedule-row-even { background-color: #F8FAFC; }
  .schedule-row-odd { background-color: #FFFFFF; }
  
  .currency-cell { text-align: right; mso-protection: locked hidden; }
  .center-cell { text-align: center; mso-protection: locked hidden; }
  .empty-cell { background-color: #FFFFFF; border: none; mso-protection: locked hidden; }
</style>
</head>
<body>
  <table>
    <tr>
      <td class="title-cell" colspan="5">PAT FINANCIALS - LUMPSUM PLANNER REPORT</td>
    </tr>
    <tr><td colspan="5" style="border: none; height: 10px;"></td></tr>

    <tr><td class="section-header" colspan="5">INPUTS &amp; ASSUMPTIONS</td></tr>
    <tr>
      <td class="label-cell">Initial Investment Amount</td>
      <td class="input-cell">${initialInvestment}</td>
      <td class="empty-cell" style="border: none;"></td>
      <td class="label-cell">Expected Return (% p.a.)</td>
      <td class="input-cell">${rate}</td>
    </tr>
    <tr>
      <td class="label-cell">Investment Duration (Years)</td>
      <td class="input-cell">${durationYears}</td>
      <td class="empty-cell" style="border: none;"></td>
      <td class="label-cell">Current Age (Years)</td>
      <td class="input-cell">${currentAge}</td>
    </tr>

    <tr><td colspan="5" style="border: none; height: 15px;"></td></tr>

    <tr><td class="section-header" colspan="5">PLAN SUMMARY OUTCOMES (LIVE FORMULAS)</td></tr>
    <tr>
      <td class="result-label" colspan="3">Total Capital Invested</td>
      <td class="result-value" colspan="2">=SUM(C14:C${13 + results.length}) + B4</td>
    </tr>
    <tr>
      <td class="result-label" colspan="3">Final Wealth / Valuation</td>
      <td class="result-value" colspan="2">=E${13 + results.length}</td>
    </tr>
    <tr>
      <td class="result-label" colspan="3">Wealth Multiplier</td>
      <td class="result-value" colspan="2">=D9/D8</td>
    </tr>

    <tr><td colspan="5" style="border: none; height: 15px;"></td></tr>

    <tr><td class="section-header" colspan="5">YEARLY WEALTH ACCUMULATION SCHEDULE</td></tr>
    <tr>
      <td class="grid-header">AGE</td>
      <td class="grid-header">YEAR</td>
      <td class="grid-header">ADDITIONAL INVESTMENT</td>
      <td class="grid-header">TOTAL INVESTED (TO DATE)</td>
      <td class="grid-header">YEAR END VALUE</td>
    </tr>
    ${results.map((row, idx) => {
      const rowClass = idx % 2 === 0 ? 'schedule-row-even' : 'schedule-row-odd';
      const r = 14 + idx; // Excel row index
      const totalInvestedFormula = idx === 0 ? '=B4+C14' : `=D${r - 1}+C${r}`;
      const endValFormula = idx === 0 ? '=(B4+C14)*(1+$E$4/100)' : `=(E${r - 1}+C${r})*(1+$E$4/100)`;
      return `
      <tr class="${rowClass}">
        <td class="center-cell" style="font-weight: bold;">=$E$5+B${r}</td>
        <td class="center-cell">${row.year}</td>
        <td class="currency-cell" style="color: #2563EB;">${row.additionalInvestment}</td>
        <td class="currency-cell">${totalInvestedFormula}</td>
        <td class="currency-cell" style="font-weight: bold; color: #0284C7;">${endValFormula}</td>
      </tr>
      `;
    }).join('')}
  </table>
</body>
</html>
`;

    const blob = new Blob([htmlContent], { type: 'application/vnd.ms-excel;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `lumpsum_plan_report_${new Date().toISOString().split('T')[0]}.xls`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const calculate = () => {
    const newResults: CalculationRow[] = [];
    let balance = initialInvestment;
    let totalInvested = initialInvestment;

    for (let year = 1; year <= durationYears; year++) {
      const additional = year === 1 ? 0 : (additionalInvestments[year] || 0);
      totalInvested += additional;
      const yearEndValue = balance * (1 + rate / 100);

      newResults.push({
        year,
        age: currentAge + year,
        additionalInvestment: additional,
        totalInvested: totalInvested,
        yearEndValue: yearEndValue,
      });

      balance = yearEndValue + additional;
    }
    setResults(newResults);
  };

  useEffect(() => {
    if (isOpen) calculate();
  }, [initialInvestment, rate, durationYears, currentAge, additionalInvestments, isOpen]);

  // Keep selectedLookupAge in bounds when currentAge or durationYears changes
  useEffect(() => {
    const minAge = currentAge + 1;
    const maxAge = currentAge + durationYears;
    if (selectedLookupAge < minAge || selectedLookupAge > maxAge) {
      setSelectedLookupAge(Math.min(maxAge, Math.max(minAge, currentAge + Math.min(10, durationYears))));
    }
  }, [currentAge, durationYears, selectedLookupAge]);

  const handleInvestmentChange = (year: number, value: string) => {
    const val = parseInt(value) || 0;
    setAdditionalInvestments(prev => ({ ...prev, [year]: val }));
  };

  const formatCurrency = (val: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0,
    }).format(val);
  };

  // Find the result for the currently selected age
  const selectedResult = results.find(r => r.age === selectedLookupAge) || results[results.length - 1];

  // Generate standard dynamic milestone ages to showcase as buttons
  const milestoneAges = [30, 40, 50, 60, 65].filter(age => age > currentAge && age <= currentAge + durationYears);

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-[9999] flex items-center justify-center bg-black/50 p-4 backdrop-blur-sm"
        >
          <motion.div
            initial={{ scale: 0.95, y: 20 }}
            animate={{ scale: 1, y: 0 }}
            exit={{ scale: 0.95, y: 20 }}
            className="bg-white rounded-3xl w-full max-w-6xl h-[90vh] flex flex-col overflow-hidden shadow-2xl border border-slate-100"
          >
            {/* Header */}
        <div className="flex flex-wrap items-center justify-between p-6 bg-brand-primary text-white border-b border-white/20 gap-4 shrink-0">
          <div className="flex items-center gap-3">
            <div className="bg-white/20 p-2.5 rounded-xl">
              <Calculator className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-xl font-bold tracking-tight">LumpSum Calculator</h2>
              <p className="text-xs text-blue-100">Interactive Wealth & Milestone Planner</p>
            </div>
          </div>
          <div className="flex items-center gap-3 ml-auto">
            <button
              onClick={() => {
                if (!isFormOpened) {
                  setIsFormModalOpen(true);
                } else {
                  exportToExcel();
                }
              }}
              className={`flex items-center gap-2 ${isFormOpened ? 'bg-sky-600 hover:bg-sky-700' : 'bg-[#3B82F6] hover:bg-[#1D4ED8]'} text-white px-4 py-2 rounded-xl transition-colors font-semibold text-sm shadow-sm`}
            >
              <Download className="w-4 h-4" />
              {isFormOpened ? 'Download Excel Sheet' : 'Fill Form & Download'}
            </button>
            <LeadFormModal
              isOpen={isFormModalOpen}
              onClose={() => setIsFormModalOpen(false)}
              onSubmitAndDownload={() => {
                setIsFormOpened(true);
                setIsFormModalOpen(false);
                exportToExcel();
              }}
            />
            <button onClick={onClose} className="p-2.5 bg-white/10 hover:bg-white/20 rounded-xl transition-colors text-white">
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>
        {/* Content */}
            <div className="flex-1 p-6 grid grid-cols-1 lg:grid-cols-3 gap-6 min-h-0 overflow-y-auto lg:overflow-hidden bg-slate-50/30">
              {/* Controls Column */}
              <div className="lg:col-span-1 space-y-6 lg:overflow-y-auto lg:pr-2" data-lenis-prevent="true">
                <div className="bg-white p-5 rounded-2xl border border-slate-100 shadow-sm space-y-5">
                  <h3 className="text-sm font-semibold text-slate-400 uppercase tracking-wider">Input parameters</h3>
                  
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-2 flex justify-between">
                      <span>Current Age</span>
                      <span className="text-brand-primary font-semibold">{currentAge} Years</span>
                    </label>
                    <input
                      type="number"
                      value={currentAge}
                      onChange={(e) => setCurrentAge(Math.max(1, Number(e.target.value)))}
                      className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-brand-primary focus:border-transparent transition-all font-medium text-slate-800"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-2 flex justify-between">
                      <span>Initial Investment</span>
                      <span className="text-brand-primary font-semibold">{formatCurrency(initialInvestment)}</span>
                    </label>
                    <input
                      type="number"
                      value={initialInvestment}
                      onChange={(e) => setInitialInvestment(Math.max(0, Number(e.target.value)))}
                      className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-brand-primary focus:border-transparent transition-all font-medium text-slate-800"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-2 flex justify-between">
                      <span>Expected Return (p.a.)</span>
                      <span className="text-brand-primary font-semibold">{rate}%</span>
                    </label>
                    <input
                      type="number"
                      value={rate}
                      onChange={(e) => setRate(Number(e.target.value))}
                      className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-brand-primary focus:border-transparent transition-all font-medium text-slate-800"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-2 flex justify-between">
                      <span>Investment Duration</span>
                      <span className="text-brand-primary font-semibold">{durationYears} Years</span>
                    </label>
                    <input
                      type="number"
                      value={durationYears}
                      onChange={(e) => setDurationYears(Math.max(1, Math.min(100, Number(e.target.value))))}
                      className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-brand-primary focus:border-transparent transition-all font-medium text-slate-800"
                    />
                  </div>

                  <button 
                    onClick={() => setAdditionalInvestments({})}
                    className="w-full flex items-center justify-center gap-2 px-4 py-3 text-sm font-medium text-slate-600 hover:text-brand-primary hover:border-brand-primary transition-colors bg-white border border-slate-200 rounded-xl shadow-sm"
                  >
                    <RefreshCw className="w-4 h-4" /> Reset Additional Investments
                  </button>
                </div>
              </div>

              {/* Main Interactive & Table Column */}
              <div className="lg:col-span-2 flex flex-col gap-6 h-full min-h-0">
                
                {/* INTERACTIVE MILESTONE CARD */}
                <div className="bg-gradient-to-r from-brand-primary/10 to-blue-50 border border-brand-primary/10 p-6 rounded-3xl shadow-sm space-y-4">
                  <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
                    <div className="flex items-center gap-2">
                      <TrendingUp className="text-brand-primary w-5 h-5" />
                      <span className="text-sm font-semibold text-slate-700 uppercase tracking-wider">Interactive Wealth Lookup</span>
                    </div>
                    {/* Milestone presets */}
                    {milestoneAges.length > 0 && (
                      <div className="flex flex-wrap gap-2 items-center">
                        <span className="text-xs text-slate-500 font-medium">Quick Jumps:</span>
                        {milestoneAges.map(age => (
                          <button
                            key={age}
                            onClick={() => setSelectedLookupAge(age)}
                            className={`px-3 py-1 rounded-full text-xs font-semibold border transition-all ${
                              selectedLookupAge === age 
                                ? 'bg-brand-primary text-white border-brand-primary shadow-sm shadow-brand-primary/20' 
                                : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'
                            }`}
                          >
                            Age {age}
                          </button>
                        ))}
                      </div>
                    )}
                  </div>

                  {/* Interactive Age Slider */}
                  <div className="space-y-2 py-2">
                    <div className="flex justify-between text-xs text-slate-500 font-semibold">
                      <span>Age {currentAge + 1}</span>
                      <span className="text-brand-primary px-2 py-0.5 bg-brand-primary/10 rounded font-bold">Selected Age: {selectedLookupAge}</span>
                      <span>Age {currentAge + durationYears}</span>
                    </div>
                    <input
                      type="range"
                      min={currentAge + 1}
                      max={currentAge + durationYears}
                      value={selectedLookupAge}
                      onChange={(e) => setSelectedLookupAge(Number(e.target.value))}
                      className="w-full h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-brand-primary focus:outline-none"
                    />
                  </div>

                  {/* Dynamic Projection Outcome */}
                  {selectedResult && (
                    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4 bg-white/70 backdrop-blur-sm p-4 rounded-2xl border border-white/60">
                      <div>
                        <div className="text-xs text-slate-400 font-semibold mb-1 flex items-center gap-1">
                          <Calendar className="w-3.5 h-3.5 text-slate-400" /> At Age {selectedLookupAge} (Year {selectedResult.year})
                        </div>
                        <div className="text-2xl font-bold text-sky-600">
                          {formatCurrency(selectedResult.yearEndValue)}
                        </div>
                      </div>
                      <div>
                        <div className="text-xs text-slate-400 font-semibold mb-1 flex items-center gap-1">
                          <Landmark className="w-3.5 h-3.5 text-slate-400" /> Total Capital Invested
                        </div>
                        <div className="text-xl font-bold text-slate-800">
                          {formatCurrency(selectedResult.totalInvested)}
                        </div>
                      </div>
                      <div className="sm:col-span-2 md:col-span-1">
                        <div className="text-xs text-slate-400 font-semibold mb-1 flex items-center gap-1">
                          <Award className="w-3.5 h-3.5 text-slate-400" /> Wealth Multiplier
                        </div>
                        <div className="text-xl font-bold text-blue-600 flex items-center gap-1">
                          {(selectedResult.yearEndValue / selectedResult.totalInvested).toFixed(2)}x
                          <span className="text-xs text-slate-400 font-medium font-mono">growth</span>
                        </div>
                      </div>
                    </div>
                  )}
                </div>

                {/* Table Container */}
                <div data-lenis-prevent="true" className="flex-1 overflow-y-auto border border-slate-100 rounded-3xl bg-white shadow-sm min-h-0">
                  <table className="w-full text-sm">
                    <thead className="bg-slate-50 sticky top-0 z-10">
                      <tr>
                        <th className="px-6 py-4 text-left font-semibold text-slate-600">Age</th>
                        <th className="px-6 py-4 text-left font-semibold text-slate-600">Year</th>
                        <th className="px-6 py-4 text-left font-semibold text-slate-600">Addl. Investment</th>
                        <th className="px-6 py-4 text-right font-semibold text-slate-600">Year End Value</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {results.map((row) => {
                        const isSelected = row.age === selectedLookupAge;
                        return (
                          <tr 
                            key={row.year} 
                            onClick={() => setSelectedLookupAge(row.age)}
                            className={`hover:bg-slate-50/50 cursor-pointer transition-all ${
                              isSelected ? 'bg-brand-primary/5 font-semibold text-brand-primary border-l-4 border-l-brand-primary' : ''
                            }`}
                          >
                            <td className="px-6 py-4">
                              <span className={`px-2.5 py-1 rounded-full text-xs font-semibold ${
                                isSelected ? 'bg-brand-primary text-white' : 'bg-slate-100 text-slate-700'
                              }`}>
                                Age {row.age}
                              </span>
                            </td>
                            <td className="px-6 py-4 text-slate-500">Year {row.year}</td>
                            <td className="px-4 py-2" onClick={(e) => e.stopPropagation()}>
                              {row.year === 1 ? (
                                <span className="text-slate-400 pl-4 font-medium">-</span>
                              ) : (
                                <div className="relative">
                                  <span className="absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400 font-medium text-xs">₹</span>
                                  <input 
                                    type="number" 
                                    placeholder="0"
                                    value={additionalInvestments[row.year] || ''}
                                    onChange={(e) => handleInvestmentChange(row.year, e.target.value)}
                                    className="w-full pl-6 pr-2 py-1.5 text-xs border border-slate-200 rounded-lg focus:ring-2 focus:ring-brand-primary focus:border-transparent bg-white"
                                  />
                                </div>
                              )}
                            </td>
                            <td className={`px-6 py-4 text-right font-bold ${
                              isSelected ? 'text-brand-primary text-base' : 'text-sky-600'
                            }`}>
                              {formatCurrency(row.yearEndValue)}
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>

            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

