import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, RefreshCw, Calculator, TrendingUp, Calendar, Landmark, Download, Percent, ShieldCheck, HelpCircle } from 'lucide-react';
import { LeadFormModal } from './LeadFormModal';

const CII_TABLE: { [key: string]: number } = {
  '2001-02': 100,
  '2002-03': 105,
  '2003-04': 109,
  '2004-05': 113,
  '2005-06': 117,
  '2006-07': 122,
  '2007-08': 129,
  '2008-09': 137,
  '2009-10': 148,
  '2010-11': 167,
  '2011-12': 184,
  '2012-13': 200,
  '2013-14': 220,
  '2014-15': 240,
  '2015-16': 254,
  '2016-17': 264,
  '2017-18': 272,
  '2018-19': 280,
  '2019-20': 289,
  '2020-21': 301,
  '2021-22': 317,
  '2022-23': 331,
  '2023-24': 348,
  '2024-25': 363,
  '2025-26': 376
};

const YEARS_LIST = Object.keys(CII_TABLE);

interface PropertyCapitalGainsCalculatorProps {
  isOpen: boolean;
  onClose: () => void;
}

export const PropertyCapitalGainsCalculator: React.FC<PropertyCapitalGainsCalculatorProps> = ({ isOpen, onClose }) => {
  // Input states
  const [purchaseYear, setPurchaseYear] = useState('2010-11');
  const [saleYear, setSaleYear] = useState('2025-26');
  const [purchasePrice, setPurchasePrice] = useState(1000000);
  const [salePrice, setSalePrice] = useState(2500000);

  // Reinvestment inputs
  const [bondInterestRate, setBondInterestRate] = useState(5.25);
  const [bondLockInPeriod, setBondLockInPeriod] = useState(5);
  const [bondTaxRate, setBondTaxRate] = useState(0.00);
  const [mfReturnRate, setMfReturnRate] = useState(12.00);
  const [mfInvestmentPeriod, setMfInvestmentPeriod] = useState(5);
  const [mfLTCGRate, setMfLTCGRate] = useState(12.50);

  // Auto-calculated bond investment toggle
  const [bondExemptChecked, setBondExemptChecked] = useState(true);

  // Lead Form State
  const [isFormOpened, setIsFormOpened] = useState(false);
  const [isFormModalOpen, setIsFormModalOpen] = useState(false);

  // Validation logic for purchase and sale years
  useEffect(() => {
    const purchaseIdx = YEARS_LIST.indexOf(purchaseYear);
    const saleIdx = YEARS_LIST.indexOf(saleYear);
    if (saleIdx < purchaseIdx) {
      // Set sale year to purchase year if invalid
      setSaleYear(purchaseYear);
    }
  }, [purchaseYear]);

  // Calculations
  const ciiPurchase = CII_TABLE[purchaseYear] || 100;
  const ciiSale = CII_TABLE[saleYear] || 100;
  
  const purchaseYearNum = parseInt(purchaseYear.split('-')[0], 10);
  const saleYearNum = parseInt(saleYear.split('-')[0], 10);
  const holdingPeriod = Math.max(0, saleYearNum - purchaseYearNum);

  // Indexed Cost of Acquisition
  const indexedCost = Math.round(purchasePrice * (ciiSale / ciiPurchase));

  // Method A - 20% Tax (With Indexation)
  const capitalGainIndexed = Math.max(0, salePrice - indexedCost);
  const taxRateMethodA = 20.00;
  const taxPayableMethodA = Math.round(capitalGainIndexed * (taxRateMethodA / 100));

  // Method B - 12.5% Flat Tax (No Indexation)
  const capitalGainFlat = Math.max(0, salePrice - purchasePrice);
  const taxRateMethodB = 12.50;
  const taxPayableMethodB = Math.round(capitalGainFlat * (taxRateMethodB / 100));

  // Summary recommendation
  const cheaperTax = Math.min(taxPayableMethodA, taxPayableMethodB);
  const betterMethod = taxPayableMethodA <= taxPayableMethodB ? 'Method A (20% Indexed)' : 'Method B (12.5% Flat)';
  const taxSaved = Math.max(0, Math.abs(taxPayableMethodA - taxPayableMethodB));

  // Bond Reinvestment Logic (Sec 54EC Cap is 50,00,000)
  const bondCap = 5000000;
  
  // Under Option A, we model Section 54EC exemption:
  // If checked, the 54EC Bond Principal is ₹50L compulsory (capped at salePrice)
  const bondInvested = bondExemptChecked ? Math.min(bondCap, salePrice) : 0;
  
  // Max eligible exemption for tax shielding is the minimum of capital gain and 50L cap
  const baseCapitalGain = taxPayableMethodA <= taxPayableMethodB ? capitalGainIndexed : capitalGainFlat;
  const eligibleExemption = bondExemptChecked ? Math.min(baseCapitalGain, bondCap) : 0;
  
  // Tax on remaining excess capital gain if bond cap exceeded or if bonds not used
  const taxableExcessGain = Math.max(0, baseCapitalGain - eligibleExemption);
  const selectedTaxRate = taxPayableMethodA <= taxPayableMethodB ? taxRateMethodA : taxRateMethodB;
  const excessGainTax = Math.round(taxableExcessGain * (selectedTaxRate / 100));

  // Net proceeds available to invest (for Lumpsum comparison)
  const netProceedsLumpsum = salePrice - cheaperTax;

  // Split calculations - remaining proceeds after bonds and excess tax go to Mutual Fund principal
  const mfInvested = Math.max(0, salePrice - bondInvested - excessGainTax);

  // Option A (Bond + MF) returns
  // Bond compound rate: Rate * (1 - Tax Rate)
  const bondEffectiveRate = (bondInterestRate / 100) * (1 - (bondTaxRate / 100));
  const bondFV = Math.round(bondInvested * Math.pow(1 + bondEffectiveRate, bondLockInPeriod));
  const bondGain = Math.max(0, bondFV - bondInvested);

  // MF portion of Option A
  const mfFVOptionA = Math.round(mfInvested * Math.pow(1 + (mfReturnRate / 100), mfInvestmentPeriod));
  const mfGainOptionA = Math.max(0, mfFVOptionA - mfInvested);
  const mfLTCGTaxOptionA = Math.round(mfGainOptionA * (mfLTCGRate / 100));
  const mfNetFVOptionA = mfFVOptionA - mfLTCGTaxOptionA;
  const mfNetGainOptionA = mfNetFVOptionA - mfInvested;

  // Option A totals
  const optionATotalPrincipal = bondInvested + mfInvested;
  const optionATotalFV = bondFV + mfNetFVOptionA;
  const optionATotalGain = optionATotalFV - optionATotalPrincipal;
  const optionACAGR = optionATotalPrincipal > 0 ? (Math.pow(optionATotalFV / optionATotalPrincipal, 1 / mfInvestmentPeriod) - 1) * 100 : 0;

  // Option B (Pure Lumpsum) returns
  const optionBFV = Math.round(netProceedsLumpsum * Math.pow(1 + (mfReturnRate / 100), mfInvestmentPeriod));
  const optionBGain = Math.max(0, optionBFV - netProceedsLumpsum);
  const optionBLTCGTax = Math.round(optionBGain * (mfLTCGRate / 100));
  const optionBNetFV = optionBFV - optionBLTCGTax;
  const optionBNetGain = optionBNetFV - netProceedsLumpsum;
  const optionBCAGR = netProceedsLumpsum > 0 ? (Math.pow(optionBNetFV / netProceedsLumpsum, 1 / mfInvestmentPeriod) - 1) * 100 : 0;

  // Reinvestment Summary
  const betterReinvestmentOption = optionATotalFV >= optionBNetFV ? 'Option A - Government Bond+MF' : 'Option B - Lumpsum Investment';
  const extraWealth = Math.abs(optionATotalFV - optionBNetFV);

  // Currency Formatter
  const formatCurrency = (val: number) => {
    if (isNaN(val) || !isFinite(val)) return '₹0';
    return '₹' + new Intl.NumberFormat('en-IN', {
      maximumFractionDigits: 0
    }).format(val);
  };

  const handleDownloadClick = () => {
    if (!isFormOpened) {
      setIsFormModalOpen(true);
    } else {
      triggerExcelDownload();
    }
  };

  const triggerExcelDownload = () => {
    const formatNumber = (val: number) => {
      return new Intl.NumberFormat('en-IN', {
        maximumFractionDigits: 0
      }).format(val);
    };

    const htmlContent = `
<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40">
<head>
<!--[if gte mso 9]>
<xml>
<x:ExcelWorkbook>
<x:ExcelWorksheets>
<x:ExcelWorksheet>
<x:Name>Property Capital Gains</x:Name>
<x:WorksheetOptions>
<x:DisplayGridlines/>
<x:ProtectContents>True</x:ProtectContents>
</x:WorksheetOptions>
</x:ExcelWorksheet>
</x:ExcelWorksheets>
</x:ExcelWorkbook>
</xml>
<![endif]-->
<meta charset="utf-8">
<style>
  table { border-collapse: collapse; font-family: 'Segoe UI', Arial, sans-serif; }
  th, td { border: 1px solid #CBD5E1; padding: 10px; font-size: 11pt; mso-protection: locked hidden; }
  
  .title-cell { font-size: 16pt; font-weight: bold; color: #FFFFFF; background-color: #1E3A8A; padding: 15px; border: none; text-align: center; }
  .section-header { background-color: #3B82F6; color: #FFFFFF; font-weight: bold; font-size: 12pt; text-align: left; padding: 10px; }
  .grid-header { background-color: #1E293B; color: #FFFFFF; font-weight: bold; font-size: 11pt; text-align: center; }
  
  .label-cell { color: #334155; font-weight: 500; background-color: #F8FAFC; }
  .value-cell { text-align: right; font-weight: bold; color: #020617; }
  .input-cell { text-align: right; font-weight: bold; color: #020617; background-color: #FFFFD0; mso-protection: unlocked; border: 1px solid #94A3B8; }
  
  .result-label { font-weight: bold; color: #1E3A8A; background-color: #EFF6FF; border: 1px solid #BFDBFE; }
  .result-value { font-weight: bold; color: #1E3A8A; background-color: #DBEAFE; text-align: right; border: 1px solid #BFDBFE; }
  
  .notes-box { font-size: 9.5pt; color: #475569; background-color: #F8FAFC; text-align: left; vertical-align: top; }
</style>
</head>
<body>
  <table>
    <tr>
      <td class="title-cell" colspan="6">PROPERTY CAPITAL GAINS TAX CALCULATOR (INDEXATION)</td>
    </tr>
    <tr><td colspan="6" style="border: none; height: 10px;"></td></tr>

    <tr><td class="section-header" colspan="6">INPUT ASSUMPTIONS (Yellow cells are editable)</td></tr>
    <tr>
      <td class="label-cell">Financial Year of Purchase</td>
      <td class="input-cell" colspan="2">${purchaseYear}</td>
      <td class="label-cell">Financial Year of Sale</td>
      <td class="input-cell" colspan="2">${saleYear}</td>
    </tr>
    <tr>
      <td class="label-cell">Purchase (Acquisition) Price (₹)</td>
      <td class="input-cell" colspan="2">${purchasePrice}</td>
      <td class="label-cell">Sale Price (₹)</td>
      <td class="input-cell" colspan="2">${salePrice}</td>
    </tr>

    <tr><td colspan="6" style="border: none; height: 10px;"></td></tr>
    <tr><td class="section-header" colspan="6">INDEXATION WORKINGS</td></tr>
    <tr>
      <td class="label-cell">Holding Period (approx. Years)</td>
      <td class="value-cell" colspan="2">${holdingPeriod}</td>
      <td class="label-cell">CII at Purchase Year</td>
      <td class="value-cell" colspan="2">${ciiPurchase}</td>
    </tr>
    <tr>
      <td class="label-cell">CII at Sale Year</td>
      <td class="value-cell" colspan="2">${ciiSale}</td>
      <td class="result-label">Indexed Cost of Acquisition (₹)</td>
      <td class="result-value" colspan="2">${formatNumber(indexedCost)}</td>
    </tr>

    <tr><td colspan="6" style="border: none; height: 10px;"></td></tr>
    <tr><td class="section-header" colspan="3">METHOD A - 20% Tax (With Indexation)</td><td class="section-header" colspan="3">METHOD B - 12.5% Flat Tax (No Indexation)</td></tr>
    <tr>
      <td class="label-cell">Sale Price</td>
      <td class="value-cell" colspan="2">${formatNumber(salePrice)}</td>
      <td class="label-cell">Sale Price</td>
      <td class="value-cell" colspan="2">${formatNumber(salePrice)}</td>
    </tr>
    <tr>
      <td class="label-cell">Less: Indexed Cost of Acquisition</td>
      <td class="value-cell" colspan="2">${formatNumber(indexedCost)}</td>
      <td class="label-cell">Less: Cost of Acquisition (Actual)</td>
      <td class="value-cell" colspan="2">${formatNumber(purchasePrice)}</td>
    </tr>
    <tr>
      <td class="label-cell">Capital Gain (Indexed)</td>
      <td class="value-cell" colspan="2">${formatNumber(capitalGainIndexed)}</td>
      <td class="label-cell">Capital Gain (Un-indexed)</td>
      <td class="value-cell" colspan="2">${formatNumber(capitalGainFlat)}</td>
    </tr>
    <tr>
      <td class="label-cell">Tax Rate</td>
      <td class="value-cell" colspan="2">20.00%</td>
      <td class="label-cell">Tax Rate</td>
      <td class="value-cell" colspan="2">12.50%</td>
    </tr>
    <tr>
      <td class="result-label">Tax Payable (Method A)</td>
      <td class="result-value" colspan="2">${formatNumber(taxPayableMethodA)}</td>
      <td class="result-label">Tax Payable (Method B)</td>
      <td class="result-value" colspan="2">${formatNumber(taxPayableMethodB)}</td>
    </tr>

    <tr><td colspan="6" style="border: none; height: 10px;"></td></tr>
    <tr><td class="section-header" colspan="6">TAX SUMMARY &amp; RECOMMENDATION</td></tr>
    <tr>
      <td class="label-cell" colspan="2">Lower Tax Amount</td>
      <td class="result-value" colspan="4">${formatNumber(cheaperTax)}</td>
    </tr>
    <tr>
      <td class="label-cell" colspan="2">Better Method</td>
      <td class="result-value" style="color: #047857; background-color: #ECFDF5;" colspan="4">${betterMethod}</td>
    </tr>
    <tr>
      <td class="label-cell" colspan="2">Tax Saved vs. Other Option</td>
      <td class="result-value" style="color: #047857; background-color: #ECFDF5;" colspan="4">${formatNumber(taxSaved)}</td>
    </tr>

    <tr><td colspan="6" style="border: none; height: 10px;"></td></tr>
    <tr><td class="section-header" colspan="6">REINVESTING NET PROCEEDS COMPARISON</td></tr>
    <tr>
      <td class="grid-header">Metric</td>
      <td class="grid-header">54EC Bond</td>
      <td class="grid-header">Mutual Funds (Portion)</td>
      <td class="grid-header">Option A Total (Bond+MF)</td>
      <td class="grid-header" colspan="2">Option B (Lumpsum MF)</td>
    </tr>
    <tr>
      <td class="label-cell">Principal Invested</td>
      <td class="value-cell">${formatNumber(bondInvested)}</td>
      <td class="value-cell">${formatNumber(mfInvested)}</td>
      <td class="result-value">${formatNumber(optionATotalPrincipal)}</td>
      <td class="result-value" colspan="2">${formatNumber(netProceedsLumpsum)}</td>
    </tr>
    <tr>
      <td class="label-cell">Expected Annual Return</td>
      <td class="value-cell">${bondInterestRate}%</td>
      <td class="value-cell">${mfReturnRate}%</td>
      <td class="result-value">-</td>
      <td class="result-value" colspan="2">${mfReturnRate}%</td>
    </tr>
    <tr>
      <td class="label-cell">Post-Tax Final Wealth</td>
      <td class="value-cell">${formatNumber(bondFV)}</td>
      <td class="value-cell">${formatNumber(mfNetFVOptionA)}</td>
      <td class="result-value" style="color: #047857;">${formatNumber(optionATotalFV)}</td>
      <td class="result-value" style="color: #1E3A8A;" colspan="2">${formatNumber(optionBNetFV)}</td>
    </tr>
    <tr>
      <td class="label-cell">Total Post-Tax Gain</td>
      <td class="value-cell">${formatNumber(bondGain)}</td>
      <td class="value-cell">${formatNumber(mfNetGainOptionA)}</td>
      <td class="result-value">${formatNumber(optionATotalGain)}</td>
      <td class="result-value" colspan="2">${formatNumber(optionBNetGain)}</td>
    </tr>
    <tr>
      <td class="label-cell">Effective Post-Tax CAGR</td>
      <td class="value-cell">${(bondEffectiveRate * 100).toFixed(2)}%</td>
      <td class="value-cell">${optionACAGR.toFixed(2)}%</td>
      <td class="result-value">${optionACAGR.toFixed(2)}%</td>
      <td class="result-value" colspan="2">${optionBCAGR.toFixed(2)}%</td>
    </tr>

    <tr><td colspan="6" style="border: none; height: 10px;"></td></tr>
    <tr>
      <td class="label-cell" colspan="2">Better Reinvestment Option</td>
      <td class="result-value" style="color: #047857; background-color: #ECFDF5;" colspan="4">${betterReinvestmentOption}</td>
    </tr>
    <tr>
      <td class="label-cell" colspan="2">Extra Wealth Created</td>
      <td class="result-value" style="color: #047857; background-color: #ECFDF5;" colspan="4">${formatNumber(extraWealth)}</td>
    </tr>

    <tr><td colspan="6" style="border: none; height: 10px;"></td></tr>
    <tr>
      <td class="notes-box" colspan="6">
        <strong>Notes &amp; Assumptions:</strong><br>
        1. Sourced from Finance Act 2024 / Income Tax Dept. CII Table Notification 70/2025. This compares flat 12.5% tax with no indexation versus 20% with indexation.<br>
        2. Indexed Cost of Acquisition = Purchase Price * (CII of Sale Year / CII of Purchase Year).<br>
        3. Option A (Section 54EC Government Bonds) shelters capital gains up to ₹50,00,000 per financial year, with a fixed 5-year lock-in period.<br>
        4. Option B (Pure Lumpsum) reinvests the net proceeds of the sale (after paying the capital gains tax up front) directly into market instruments.
      </td>
    </tr>
  </table>
</body>
</html>
    `;

    const blob = new Blob([htmlContent], { type: 'application/vnd.ms-excel;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', 'Property_Capital_Gains_Tax_Report.xls');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[9999] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm overflow-hidden">
      <style>{`
        .custom-scrollbar::-webkit-scrollbar {
          width: 8px;
          height: 8px;
        }
        .custom-scrollbar::-webkit-scrollbar-track {
          background: #f1f5f9;
          border-radius: 9999px;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb {
          background: #cbd5e1;
          border-radius: 9999px;
          border: 2px solid #f1f5f9;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover {
          background: #94a3b8;
        }
      `}</style>
      <div className="absolute inset-0 pointer-events-auto" onClick={onClose} />
      
      <motion.div
        initial={{ opacity: 0, scale: 0.9, y: 30 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.9, y: 30 }}
        className="relative bg-white rounded-[32px] shadow-2xl w-full max-w-5xl h-[90vh] flex flex-col overflow-hidden border border-slate-100 z-10"
      >
        {/* Header */}
        <div className="px-6 py-5 bg-gradient-to-r from-blue-700 to-blue-800 text-white flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-white/10 rounded-xl">
              <Calculator className="w-6 h-6 text-white" />
            </div>
            <div>
              <h3 className="font-display font-bold text-lg md:text-xl leading-none">Property Capital Gains Tax Calculator</h3>
              <p className="text-blue-100 text-xs mt-1 font-sans">Compare 12.5% Flat vs 20% Indexed Taxes (Finance Act 2024 / 2025)</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <button
              onClick={handleDownloadClick}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl text-white font-bold text-xs shadow-sm transition-all shrink-0 ${isFormOpened ? 'bg-emerald-600 hover:bg-emerald-700' : 'bg-amber-500 hover:bg-amber-600'}`}
            >
              <Download className="w-3.5 h-3.5" />
              {isFormOpened ? 'Download Excel Sheet' : 'Fill Form & Download'}
            </button>
            <button
              onClick={onClose}
              className="p-2 hover:bg-white/10 rounded-xl transition-colors text-white/80 hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Content Panel */}
        <div className="flex-grow overflow-y-auto custom-scrollbar p-6 md:p-8 space-y-8 bg-slate-50/50">
          
          {/* Main Calculation Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
            
            {/* Input Form Fields */}
            <div className="lg:col-span-5 bg-white border border-slate-100 p-6 rounded-3xl shadow-sm space-y-6">
              <h4 className="font-bold text-slate-800 text-base border-b border-slate-100 pb-3 flex items-center gap-2">
                <Calendar className="w-4 h-4 text-blue-600" /> Input Assumptions
              </h4>

              {/* Financial Year Dropdowns */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-2">Purchase FY</label>
                  <select
                    value={purchaseYear}
                    onChange={(e) => setPurchaseYear(e.target.value)}
                    className="w-full px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-semibold text-slate-800 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:bg-white transition-all"
                  >
                    {YEARS_LIST.map((yr) => (
                      <option key={yr} value={yr}>{yr}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-2">Sale FY</label>
                  <select
                    value={saleYear}
                    onChange={(e) => setSaleYear(e.target.value)}
                    className="w-full px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-semibold text-slate-800 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:bg-white transition-all"
                  >
                    {YEARS_LIST.map((yr) => (
                      <option key={yr} value={yr}>{yr}</option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Slider for Purchase Price */}
              <div className="space-y-2">
                <div className="flex justify-between items-center text-sm">
                  <span className="font-medium text-slate-600">Purchase Price</span>
                  <input
                    type="number"
                    value={purchasePrice}
                    onChange={(e) => setPurchasePrice(Math.max(0, Number(e.target.value)))}
                    className="px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-right font-bold text-slate-800 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:bg-white w-32"
                  />
                </div>
                <input
                  type="range"
                  min="100000"
                  max="50000000"
                  step="50000"
                  value={purchasePrice}
                  onChange={(e) => setPurchasePrice(Number(e.target.value))}
                  className="w-full accent-blue-600"
                />
                <div className="flex justify-between text-[11px] text-slate-400 font-medium">
                  <span>1 Lakh</span>
                  <span>5 Crores</span>
                </div>
              </div>

              {/* Slider for Sale Price */}
              <div className="space-y-2">
                <div className="flex justify-between items-center text-sm">
                  <span className="font-medium text-slate-600">Sale Price</span>
                  <input
                    type="number"
                    value={salePrice}
                    onChange={(e) => setSalePrice(Math.max(0, Number(e.target.value)))}
                    className="px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-right font-bold text-slate-800 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:bg-white w-32"
                  />
                </div>
                <input
                  type="range"
                  min="200000"
                  max="100000000"
                  step="100000"
                  value={salePrice}
                  onChange={(e) => setSalePrice(Number(e.target.value))}
                  className="w-full accent-blue-600"
                />
                <div className="flex justify-between text-[11px] text-slate-400 font-medium">
                  <span>2 Lakhs</span>
                  <span>10 Crores</span>
                </div>
              </div>

              {/* Indexation workings cards */}
              <div className="p-4 bg-slate-50 rounded-2xl border border-slate-100 space-y-3.5">
                <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block">Indexation Info</span>
                <div className="grid grid-cols-2 gap-4 text-xs">
                  <div>
                    <span className="text-slate-500 block mb-0.5">Holding Period</span>
                    <span className="font-bold text-slate-800 text-sm">{holdingPeriod} Years</span>
                  </div>
                  <div>
                    <span className="text-slate-500 block mb-0.5">Indexed Cost</span>
                    <span className="font-bold text-slate-800 text-sm">{formatCurrency(indexedCost)}</span>
                  </div>
                  <div>
                    <span className="text-slate-500 block mb-0.5">CII Purchase ({purchaseYear})</span>
                    <span className="font-semibold text-slate-700">{ciiPurchase}</span>
                  </div>
                  <div>
                    <span className="text-slate-500 block mb-0.5">CII Sale ({saleYear})</span>
                    <span className="font-semibold text-slate-700">{ciiSale}</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Tax Methods Side-by-Side comparison */}
            <div className="lg:col-span-7 flex flex-col justify-between space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                
                {/* Method A Card */}
                <div className="bg-white border border-slate-100 rounded-3xl p-5 shadow-sm relative overflow-hidden flex flex-col justify-between">
                  <div>
                    <div className="flex justify-between items-center mb-4">
                      <span className="px-3 py-1 bg-blue-50 text-blue-700 text-xs font-bold rounded-lg">Method A</span>
                      <span className="text-xs font-medium text-slate-400">Indexed (20%)</span>
                    </div>
                    <div className="space-y-2 text-sm border-b border-slate-100 pb-3 mb-3">
                      <div className="flex justify-between text-slate-500">
                        <span>Sale Price:</span>
                        <span>{formatCurrency(salePrice)}</span>
                      </div>
                      <div className="flex justify-between text-slate-500">
                        <span>Indexed Cost:</span>
                        <span className="text-red-500">-{formatCurrency(indexedCost)}</span>
                      </div>
                      <div className="flex justify-between font-bold text-slate-800">
                        <span>Capital Gain:</span>
                        <span>{formatCurrency(capitalGainIndexed)}</span>
                      </div>
                    </div>
                  </div>
                  <div>
                    <span className="text-xs text-slate-400 block mb-0.5">Tax Payable (20.00%)</span>
                    <span className="text-xl font-bold text-blue-700">{formatCurrency(taxPayableMethodA)}</span>
                  </div>
                </div>

                {/* Method B Card */}
                <div className="bg-white border border-slate-100 rounded-3xl p-5 shadow-sm relative overflow-hidden flex flex-col justify-between">
                  <div>
                    <div className="flex justify-between items-center mb-4">
                      <span className="px-3 py-1 bg-slate-100 text-slate-700 text-xs font-bold rounded-lg">Method B</span>
                      <span className="text-xs font-medium text-slate-400">Flat (12.5%)</span>
                    </div>
                    <div className="space-y-2 text-sm border-b border-slate-100 pb-3 mb-3">
                      <div className="flex justify-between text-slate-500">
                        <span>Sale Price:</span>
                        <span>{formatCurrency(salePrice)}</span>
                      </div>
                      <div className="flex justify-between text-slate-500">
                        <span>Actual Cost:</span>
                        <span className="text-red-500">-{formatCurrency(purchasePrice)}</span>
                      </div>
                      <div className="flex justify-between font-bold text-slate-800">
                        <span>Capital Gain:</span>
                        <span>{formatCurrency(capitalGainFlat)}</span>
                      </div>
                    </div>
                  </div>
                  <div>
                    <span className="text-xs text-slate-400 block mb-0.5">Tax Payable (12.50%)</span>
                    <span className="text-xl font-bold text-slate-700">{formatCurrency(taxPayableMethodB)}</span>
                  </div>
                </div>

              </div>

              {/* Recommendation Banner */}
              <div className="bg-emerald-50/50 border border-emerald-100/80 rounded-3xl p-5 md:p-6 flex items-start gap-4 shadow-sm">
                <div className="p-3 bg-emerald-500 text-white rounded-2xl">
                  <ShieldCheck className="w-6 h-6" />
                </div>
                <div className="flex-grow grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <h5 className="font-bold text-slate-800 text-sm">Best Filing Choice</h5>
                    <p className="text-emerald-700 text-base font-extrabold mt-1">{betterMethod}</p>
                    <p className="text-xs text-slate-500 mt-0.5">Minimizes your overall capital gains liability</p>
                  </div>
                  <div className="md:text-right flex flex-col justify-center">
                    <span className="text-xs text-slate-400 block uppercase font-bold tracking-wider">Estimated Tax Saved</span>
                    <span className="text-2xl font-black text-emerald-600 mt-1">{formatCurrency(taxSaved)}</span>
                  </div>
                </div>
              </div>

            </div>
          </div>

          {/* Reinvestment Options Comparison section */}
          <div className="bg-white border border-slate-100 rounded-3xl p-6 md:p-8 shadow-sm space-y-6">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center border-b border-slate-100 pb-5 gap-4">
              <div>
                <h4 className="font-display font-extrabold text-slate-800 text-lg flex items-center gap-2">
                  <TrendingUp className="w-5 h-5 text-blue-600" /> Reinvesting Net Proceeds Comparison
                </h4>
                <p className="text-slate-500 text-sm mt-1">Section 54EC Government Bond + Mutual Funds vs Pure Lumpsum Investing</p>
              </div>
              <div className="flex items-center gap-3">
                <input
                  type="checkbox"
                  id="bondExemptChecked"
                  checked={bondExemptChecked}
                  onChange={(e) => setBondExemptChecked(e.target.checked)}
                  className="w-4 h-4 rounded text-blue-600 focus:ring-blue-500 border-slate-300"
                />
                <label htmlFor="bondExemptChecked" className="text-sm font-semibold text-slate-700 cursor-pointer">
                  Invest ₹50L Compulsory in 54EC Bonds
                </label>
              </div>
            </div>

            {/* Grid of Reinvestment Param Controls */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 bg-slate-50/50 p-5 rounded-2xl border border-slate-100">
              <div className="space-y-1.5">
                <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">54EC Bond Return Rate (% p.a.)</span>
                <input
                  type="number"
                  step="0.1"
                  value={bondInterestRate}
                  onChange={(e) => setBondInterestRate(Number(e.target.value))}
                  className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl text-sm font-bold text-slate-800 focus:ring-2 focus:ring-blue-500 focus:outline-none"
                />
              </div>
              <div className="space-y-1.5">
                <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Bond Lock-In & Period (Years)</span>
                <input
                  type="number"
                  value={bondLockInPeriod}
                  onChange={(e) => setBondLockInPeriod(Number(e.target.value))}
                  className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl text-sm font-bold text-slate-800 focus:ring-2 focus:ring-blue-500 focus:outline-none"
                />
              </div>
              <div className="space-y-1.5">
                <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Mutual Fund Expected Return (% p.a.)</span>
                <input
                  type="number"
                  step="0.1"
                  value={mfReturnRate}
                  onChange={(e) => setMfReturnRate(Number(e.target.value))}
                  className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl text-sm font-bold text-slate-800 focus:ring-2 focus:ring-blue-500 focus:outline-none"
                />
              </div>
            </div>

            {/* Visual breakdown of Wealth Created */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 pt-4">
              
              {/* Option A Card */}
              <div className="border border-slate-100 rounded-2xl p-5 bg-gradient-to-br from-blue-50/30 to-slate-50/50 flex flex-col justify-between">
                <div>
                  <h5 className="font-bold text-slate-800 text-sm uppercase tracking-wider mb-3 text-blue-700">Option A: Reinvested in Government Bond + MF</h5>
                  <div className="space-y-2 text-sm border-b border-slate-100 pb-3 mb-3">
                    <div className="flex justify-between">
                      <span className="text-slate-500">54EC Bond principal:</span>
                      <span className="font-bold text-slate-700">{formatCurrency(bondInvested)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-500">Mutual Fund principal:</span>
                      <span className="font-bold text-slate-700">{formatCurrency(mfInvested)}</span>
                    </div>
                    <div className="flex justify-between border-t border-slate-100 pt-2 font-bold text-slate-800">
                      <span>Total Principal Invested:</span>
                      <span>{formatCurrency(optionATotalPrincipal)}</span>
                    </div>
                  </div>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-slate-500">Bond post-tax value:</span>
                      <span className="font-semibold text-slate-700">{formatCurrency(bondFV)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-500">MF post-tax value (after 12.5% LTCG):</span>
                      <span className="font-semibold text-slate-700">{formatCurrency(mfNetFVOptionA)}</span>
                    </div>
                  </div>
                </div>
                <div className="mt-5 pt-3 border-t border-slate-100">
                  <span className="text-xs text-slate-400 block mb-0.5">Post-Tax Final Wealth</span>
                  <span className="text-2xl font-black text-blue-700">{formatCurrency(optionATotalFV)}</span>
                  <span className="text-[11px] text-slate-500 block mt-1">Effective Post-Tax CAGR: {optionACAGR.toFixed(2)}%</span>
                </div>
              </div>

              {/* Option B Card */}
              <div className="border border-slate-100 rounded-2xl p-5 bg-gradient-to-br from-slate-50 to-slate-100/50 flex flex-col justify-between">
                <div>
                  <h5 className="font-bold text-slate-800 text-sm uppercase tracking-wider mb-3 text-slate-600">Option B: Pure Lumpsum Investment</h5>
                  <div className="space-y-2 text-sm border-b border-slate-100 pb-3 mb-3">
                    <div className="flex justify-between">
                      <span className="text-slate-500">Net sale proceeds after taxes:</span>
                      <span className="font-bold text-slate-700">{formatCurrency(netProceedsLumpsum)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-500">LTCG Tax on gains at exit ({mfLTCGRate}%):</span>
                      <span className="font-bold text-red-500">-{formatCurrency(optionBLTCGTax)}</span>
                    </div>
                    <div className="flex justify-between border-t border-slate-100 pt-2 font-bold text-slate-800">
                      <span>Total Principal Invested:</span>
                      <span>{formatCurrency(netProceedsLumpsum)}</span>
                    </div>
                  </div>
                  <div className="space-y-2 text-sm text-slate-500">
                    <p className="text-xs italic">Option B assumes you pay the property capital gains tax upfront ({formatCurrency(cheaperTax)}) and invest the remaining proceeds into your chosen Mutual Funds.</p>
                  </div>
                </div>
                <div className="mt-5 pt-3 border-t border-slate-100">
                  <span className="text-xs text-slate-400 block mb-0.5">Post-Tax Final Wealth</span>
                  <span className="text-2xl font-black text-slate-800">{formatCurrency(optionBNetFV)}</span>
                  <span className="text-[11px] text-slate-500 block mt-1">Effective Post-Tax CAGR: {optionBCAGR.toFixed(2)}%</span>
                </div>
              </div>

            </div>

            {/* Reinvestment recommendation panel */}
            <div className="bg-blue-50/50 p-4 rounded-2xl border border-blue-100 flex items-center justify-between text-sm flex-col md:flex-row gap-4">
              <div>
                <span className="text-slate-500 block font-medium">Reinvestment Outcome:</span>
                <span className="font-extrabold text-blue-950 text-base">{betterReinvestmentOption} produces more post-tax wealth.</span>
              </div>
              <div className="text-right">
                <span className="text-xs text-slate-400 block uppercase font-bold tracking-wider">Extra Wealth Gained</span>
                <span className="text-xl font-bold text-blue-700">{formatCurrency(extraWealth)}</span>
              </div>
            </div>
          </div>

          {/* Notes and assumptions section */}
          <div className="bg-slate-100/50 border border-slate-200/50 p-5 rounded-2xl text-xs space-y-3 text-slate-500 leading-relaxed">
            <h5 className="font-bold text-slate-700 text-[13px] flex items-center gap-1.5"><HelpCircle className="w-4 h-4 text-blue-600" /> Notes &amp; Assumptions</h5>
            <ol className="list-decimal pl-4 space-y-1.5">
              <li>Applicable to sale of land/building by individuals &amp; HUFs. Method A vs Method B choice under the Finance Act (No. 2), 2024 generally applies to immovable property acquired before 23-Jul-2024; verify current eligibility before relying on this for filing.</li>
              <li>Cost Inflation Index values sourced from Income Tax Dept. Notification 70/2025 dated 01-07-2025 (FY 2001-02 to FY 2025-26).</li>
              <li>Holding period, surcharge, cess, and Section 54/54EC exemptions are not factored into the basic tax comparison.</li>
              <li>Indexed Cost of Acquisition = Purchase Price * (CII of Sale Year / CII of Purchase Year).</li>
              <li>Option A (Government Bond) models Section 54EC-style bonds: interest is fully taxable each year at the slab rate, so post-tax value correctly compounds at Rate * (1 - Tax Rate); it is NOT eligible for LTCG/indexation treatment.</li>
            </ol>
          </div>

        </div>

        {/* Floating lead capture trigger footer inside the calculator dialog */}
        <div className="px-6 py-4 bg-slate-50 border-t border-slate-100 flex flex-col sm:flex-row items-center justify-between gap-4 shrink-0">
          <div className="text-center sm:text-left">
            <h4 className="font-bold text-slate-800 text-sm">Download Premium Excel Model</h4>
            <p className="text-xs text-slate-500 mt-0.5">Save all comparisons, tables, and tax formulas to your system.</p>
          </div>
          <button
            onClick={handleDownloadClick}
            className={`flex items-center gap-2 ${isFormOpened ? 'bg-emerald-600 hover:bg-emerald-700' : 'bg-blue-600 hover:bg-blue-700'} text-white px-5 py-2.5 rounded-xl transition-all font-semibold text-sm shadow-sm`}
          >
            <Download className="w-4 h-4" />
            {isFormOpened ? 'Download Excel Sheet' : 'Fill Form & Download'}
          </button>
        </div>

        {/* Lead Form Modal */}
        <LeadFormModal
          isOpen={isFormModalOpen}
          onClose={() => setIsFormModalOpen(false)}
          onSubmitAndDownload={() => {
            setIsFormModalOpen(false);
            setIsFormOpened(true);
            localStorage.setItem('pat_form_submitted', 'true');
            triggerExcelDownload();
          }}
        />

      </motion.div>
    </div>
  );
};
