import React, { useEffect } from 'react';
import { ScrollReveal } from '../components/ui/ScrollReveal';
import { Link } from 'react-router-dom';
import { Target, Shield, Landmark, ArrowLeft } from 'lucide-react';
import { ContactCTA } from '../components/ContactCTA';

export const FinancialPlanningDetails: React.FC = () => {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  return (
    <>
      <ScrollReveal>
      <section className="py-20 bg-brand-light relative overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img src="https://images.unsplash.com/photo-1554224155-8d04cb21cd6c?w=1600&q=80" alt="Background" className="w-full h-full object-cover opacity-[0.06] mix-blend-multiply" />
        </div>
        <div className="absolute top-0 right-0 w-64 h-64 bg-brand-primary/10 rounded-full blur-3xl"></div>
        <div className="absolute bottom-0 left-0 w-64 h-64 bg-brand-secondary/10 rounded-full blur-3xl"></div>
        
        <div className="container mx-auto px-4 md:px-6 relative z-10 text-center max-w-4xl pt-16">
          
          <Link to="/" className="inline-flex items-center gap-2 px-4 py-2 bg-white/50 hover:bg-white text-brand-primary font-medium rounded-full mb-8 backdrop-blur-sm border border-slate-200/50 hover:border-brand-primary/30 transition-all shadow-sm hover:shadow-md group">
            <ArrowLeft className="w-4 h-4 group-hover:-translate-x-1 transition-transform" /> Back to Home
          </Link>
          <h1 className="text-5xl md:text-6xl font-display font-bold text-brand-dark mb-6">Financial Structuring</h1>
          <p className="text-xl text-slate-600 mb-8 leading-relaxed">
            A comprehensive roadmap aligned with your life goals. We help you navigate complex financial decisions, prioritize your objectives, and achieve a secure future.
          </p>
        </div>
      </section>
      </ScrollReveal>

      <ScrollReveal>
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4 md:px-6 max-w-4xl">
          <div className="pred pred-lg pred-slate max-w-none text-slate-600 space-y-6">
            <h2 className="text-3xl font-display font-bold text-brand-dark">Why Do You Need Financial Structuring?</h2>
            <p>
              Financial structuring is more than just investing; it's about connecting your finances to your goals. Whether you are aiming for a comfortable retirement, funding your children's education, or buying your dream home, a well-structured financial framework is essential. We assess an individual's current financial condition, including their income, expenses, assets, and liabilities, to develop a strategy that helps them meet their objectives.
            </p>
            
            <h3 className="text-2xl font-display font-bold text-brand-dark mt-12 mb-4">Our Approach</h3>
            
            <div className="grid md:grid-cols-3 gap-8 my-8">
              <div className="bg-slate-50 p-6 rounded-2xl border border-slate-100 shadow-sm">
                <Target className="w-10 h-10 text-brand-primary mb-4" />
                <h4 className="text-lg font-bold text-brand-dark mb-2">Goal Setting</h4>
                <p className="text-sm">We define what you want to achieve, quantifying your goals along timelines to chart a realistic course.</p>
              </div>
              
              <div className="bg-slate-50 p-6 rounded-2xl border border-slate-100 shadow-sm">
                <Shield className="w-10 h-10 text-brand-primary mb-4" />
                <h4 className="text-lg font-bold text-brand-dark mb-2">Risk Assessment</h4>
                <p className="text-sm">We construct a profile to understand your risk tolerance and establish an adequate safety net via insurance.</p>
              </div>
              
              <div className="bg-slate-50 p-6 rounded-2xl border border-slate-100 shadow-sm">
                <Landmark className="w-10 h-10 text-brand-primary mb-4" />
                <h4 className="text-lg font-bold text-brand-dark mb-2">Portfolio Construction</h4>
                <p className="text-sm">A personalized asset allocation plan is put in place, optimized for your profile and tax efficiency.</p>
              </div>
            </div>

            <h3 className="text-2xl font-display font-bold text-brand-dark mt-12 mb-4">The Result</h3>
            <p>
              You receive not just a document, but a living breathing blueprint that evolves alongside your life. We continue to review and adjust your portfolio as your circumstances or market conditions change, ensuring that you remain firmly on track towards your financial independence.
            </p>
          </div>
        </div>
      </section>
      </ScrollReveal>
      
      <ContactCTA />
    </>
  );
};
