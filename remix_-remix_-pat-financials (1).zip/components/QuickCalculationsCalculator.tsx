import React, { useState, useEffect } from 'react';
import { X, Calculator, Download, Zap } from 'lucide-react';
import { motion } from 'motion/react';
import { LeadFormModal } from './LeadFormModal';

interface QuickCalculationsCalculatorProps {
  isOpen: boolean;
  onClose: () => void;
}

export const QuickCalculationsCalculator: React.FC<QuickCalculationsCalculatorProps> = ({ isOpen, onClose }) => {
  // Format currency in Indian standard format (Lakhs/Crores)
  const formatCurrency = (val: number) => {
    if (isNaN(val) || !isFinite(val)) return '0';
    return new Intl.NumberFormat('en-IN', {
      maximumFractionDigits: 0
    }).format(Math.round(val));
  };

  const formatNumber = (val: number, decimals: number = 2) => {
    if (isNaN(val) || !isFinite(val)) return '0.00';
    return val.toFixed(decimals);
  };

  // --- Parent state for calculators ---
  const [sipFvP, setSipFvP] = useState(10000); 
  const [sipFvY, setSipFvY] = useState(3);     
  const [sipFvR, setSipFvR] = useState(12);    

  const [sipYearsP, setSipYearsP] = useState(10000);     
  const [sipYearsFv, setSipYearsFv] = useState(2500000); 
  const [sipYearsR, setSipYearsR] = useState(12);        

  const [sipAmtFv, setSipAmtFv] = useState(2500000); 
  const [sipAmtY, setSipAmtY] = useState(5);         
  const [sipAmtR, setSipAmtR] = useState(12);        

  const [sipRateP, setSipRateP] = useState(10000);     
  const [sipRateFv, setSipRateFv] = useState(5000000); 
  const [sipRateY, setSipRateY] = useState(15);        

  const [lumpFvP, setLumpFvP] = useState(360000); 
  const [lumpFvY, setLumpFvY] = useState(3);      
  const [lumpFvR, setLumpFvR] = useState(6.2);    

  const [lumpYearsP, setLumpYearsP] = useState(2500000);     
  const [lumpYearsFv, setLumpYearsFv] = useState(20000000);  
  const [lumpYearsR, setLumpYearsR] = useState(14);          

  const [lumpAmtFv, setLumpAmtFv] = useState(3000000); 
  const [lumpAmtY, setLumpAmtY] = useState(10);        
  const [lumpAmtR, setLumpAmtR] = useState(12);        

  const [lumpRateP, setLumpRateP] = useState(1000000);  
  const [lumpRateFv, setLumpRateFv] = useState(3000000); 
  const [lumpRateY, setLumpRateY] = useState(10);        

  // --- Calculations ---

  // 1. SIP Future Value
  const rm1 = Math.pow(1 + sipFvR / 100, 1 / 12) - 1;
  const n1 = sipFvY * 12;
  const calculatedSipFv = rm1 === 0 ? sipFvP * n1 : sipFvP * ((Math.pow(1 + rm1, n1) - 1) / rm1) * (1 + rm1);

  // 2. No. of Years Reqd in SIP
  const rm2 = Math.pow(1 + sipYearsR / 100, 1 / 12) - 1;
  let calculatedSipYears = 0;
  if (rm2 > 0 && sipYearsP > 0) {
    const term2 = (sipYearsFv * rm2) / (sipYearsP * (1 + rm2)) + 1;
    if (term2 > 0) {
      const n2 = Math.log(term2) / Math.log(1 + rm2);
      calculatedSipYears = n2 / 12;
    }
  } else if (sipYearsP > 0) {
    calculatedSipYears = sipYearsFv / (sipYearsP * 12);
  }

  // 3. Reqd. SIP Investment Amount
  const rm3 = Math.pow(1 + sipAmtR / 100, 1 / 12) - 1;
  const n3 = sipAmtY * 12;
  let calculatedSipAmtP = 0;
  if (rm3 > 0 && n3 > 0) {
    calculatedSipAmtP = sipAmtFv / (((Math.pow(1 + rm3, n3) - 1) / rm3) * (1 + rm3));
  } else if (n3 > 0) {
    calculatedSipAmtP = sipAmtFv / n3;
  }

  // 4. Reqd. Rate of Return in SIP
  let calculatedSipRate = 0;
  const n4 = sipRateY * 12;
  if (n4 > 0 && sipRateP > 0 && sipRateFv > sipRateP * n4) {
    let low = 0;
    let high = 10; 
    for (let i = 0; i < 50; i++) {
      let mid = (low + high) / 2;
      let rm = Math.pow(1 + mid, 1 / 12) - 1;
      let calculatedFv = sipRateP * ((Math.pow(1 + rm, n4) - 1) / rm) * (1 + rm);
      if (calculatedFv > sipRateFv) {
        high = mid;
      } else {
        low = mid;
      }
    }
    calculatedSipRate = ((low + high) / 2) * 100;
  }

  // 5. Lump Sum Future Value
  const calculatedLumpFv = lumpFvP * Math.pow(1 + lumpFvR / 100, lumpFvY);

  // 6. No. of Years Reqd in Lump Sum
  let calculatedLumpYears = 0;
  if (lumpYearsR > 0 && lumpYearsP > 0 && lumpYearsFv > lumpYearsP) {
    calculatedLumpYears = Math.log(lumpYearsFv / lumpYearsP) / Math.log(1 + lumpYearsR / 100);
  }

  // 7. Reqd. Lump Sum Investment Amount
  const calculatedLumpAmtP = lumpAmtFv / Math.pow(1 + lumpAmtR / 100, lumpAmtY);

  // 8. Reqd. Rate of Return in Lump Sum
  let calculatedLumpRate = 0;
  if (lumpRateY > 0 && lumpRateP > 0) {
    calculatedLumpRate = (Math.pow(lumpRateFv / lumpRateP, 1 / lumpRateY) - 1) * 100;
  }

  // --- Lead Form Integration (Consistent with other calculators) ---
  const [isFormOpened, setIsFormOpened] = useState(false);
  const [isFormModalOpen, setIsFormModalOpen] = useState(false);

  const handleDownloadClick = () => {
    if (!isFormOpened) {
      setIsFormModalOpen(true);
    } else {
      triggerCsvDownload();
    }
  };

  const triggerCsvDownload = () => {
    const htmlContent = `
<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40">
<head>
<!--[if gte mso 9]>
<xml>
<x:ExcelWorkbook>
<x:ExcelWorksheets>
<x:ExcelWorksheet>
<x:Name>PAT Quick Calculations</x:Name>
<x:WorksheetOptions>
<x:DisplayGridlines/>
<x:ProtectContents>True</x:ProtectContents>
</x:WorksheetOptions>
</x:ExcelWorksheet>
</x:ExcelWorksheets>
</x:ExcelWorkbook>
</xml>
<![endif]-->
<meta charset="utf-8">
<style>
  table { border-collapse: collapse; font-family: 'Segoe UI', Arial, sans-serif; }
  th, td { border: 1px solid #CBD5E1; padding: 10px; font-size: 11pt; mso-protection: locked hidden; }
  
  .title-cell { font-size: 16pt; font-weight: bold; color: #004a99; padding: 15px; border: none; text-align: center; mso-protection: locked hidden; }
  
  .header-sip { background-color: #004a99; color: #FFFFFF; font-weight: bold; font-size: 12pt; text-align: left; mso-protection: locked hidden; }
  .header-lump { background-color: #00a29b; color: #FFFFFF; font-weight: bold; font-size: 12pt; text-align: left; mso-protection: locked hidden; }
  
  .label-cell { color: #334155; font-weight: 500; background-color: #F8FAFC; mso-protection: locked hidden; }
  .value-cell { text-align: right; font-weight: bold; color: #020617; mso-protection: locked hidden; }
  .input-cell { text-align: right; font-weight: bold; color: #020617; background-color: #FFFFD0; mso-protection: unlocked; border: 1px solid #94A3B8; }
  
  .result-label-sip { font-weight: bold; color: #004a99; background-color: #EFF6FF; border: 1px solid #93C5FD; mso-protection: locked hidden; }
  .result-value-sip { font-weight: bold; color: #004a99; background-color: #DBEAFE; text-align: right; border: 1px solid #93C5FD; mso-protection: locked hidden; }
  
  .result-label-lump { font-weight: bold; color: #00a29b; background-color: #F0FDFA; border: 1px solid #5EEAD4; mso-protection: locked hidden; }
  .result-value-lump { font-weight: bold; color: #00a29b; background-color: #CCFBF1; text-align: right; border: 1px solid #5EEAD4; mso-protection: locked hidden; }
  
  .empty-cell { background-color: #FFFFFF; border: none; width: 40px; mso-protection: locked hidden; }
</style>
</head>
<body>
  <table>
    <tr>
      <td class="title-cell" colspan="5">PAT FINANCIALS - QUICK CALCULATION PLANS</td>
    </tr>
    <tr><td colspan="5" style="border: none; height: 10px;"></td></tr>

    <!-- SECTION 1: SIP FUTURE VALUE vs LUMP SUM FUTURE VALUE -->
    <tr>
      <td class="header-sip" colspan="2">SIP FUTURE VALUE</td>
      <td class="empty-cell"></td>
      <td class="header-lump" colspan="2">LUMP SUM FUTURE VALUE</td>
    </tr>
    <tr>
      <td class="label-cell">SIP investment amount (per month)</td>
      <td class="input-cell">${sipFvP}</td>
      <td class="empty-cell"></td>
      <td class="label-cell">Lump sum investment amount</td>
      <td class="input-cell">${lumpFvP}</td>
    </tr>
    <tr>
      <td class="label-cell">SIP tenure (no. of years)</td>
      <td class="input-cell">${sipFvY}</td>
      <td class="empty-cell"></td>
      <td class="label-cell">Investment tenure (no. of years)</td>
      <td class="input-cell">${lumpFvY}</td>
    </tr>
    <tr>
      <td class="label-cell">Expected return from SIP investment (%)</td>
      <td class="input-cell">${sipFvR}</td>
      <td class="empty-cell"></td>
      <td class="label-cell">Expected return from SIP investment (%)</td>
      <td class="input-cell">${lumpFvR}</td>
    </tr>
    <tr>
      <td class="result-label-sip">EXPECTED FUTURE VALUE</td>
      <td class="result-value-sip">=ROUND(IF(((1+B6/100)^(1/12)-1)=0, B4*B5*12, B4*(((1+B6/100)^B5-1)/((1+B6/100)^(1/12)-1))*(1+B6/100)^(1/12)), 0)</td>
      <td class="empty-cell"></td>
      <td class="result-label-lump">EXPECTED FUTURE VALUE</td>
      <td class="result-value-lump">=ROUND(E4*(1+E6/100)^E5, 0)</td>
    </tr>

    <tr><td colspan="5" style="border: none; height: 15px;"></td></tr>

    <!-- SECTION 2: NO. OF YEARS REQD. IN SIP INVESTMENT vs NO. OF YEARS REQD. IN LUMP SUM INVESTMENT -->
    <tr>
      <td class="header-sip" colspan="2">NO. OF YEARS REQD. IN SIP INVESTMENT</td>
      <td class="empty-cell"></td>
      <td class="header-lump" colspan="2">NO. OF YEARS REQD. IN LUMP SUM INVESTMENT</td>
    </tr>
    <tr>
      <td class="label-cell">SIP investment amount (per month)</td>
      <td class="input-cell">${sipYearsP}</td>
      <td class="empty-cell"></td>
      <td class="label-cell">Lump sum investment amount</td>
      <td class="input-cell">${lumpYearsP}</td>
    </tr>
    <tr>
      <td class="label-cell">Target amount of future value</td>
      <td class="input-cell">${sipYearsFv}</td>
      <td class="empty-cell"></td>
      <td class="label-cell">Target amount of future value</td>
      <td class="input-cell">${lumpYearsFv}</td>
    </tr>
    <tr>
      <td class="label-cell">Expected return from SIP investment (%)</td>
      <td class="input-cell">${sipYearsR}</td>
      <td class="empty-cell"></td>
      <td class="label-cell">Expected return from lump sum inv. (%)</td>
      <td class="input-cell">${lumpYearsR}</td>
    </tr>
    <tr>
      <td class="result-label-sip">NO. OF YEARS REQUIRED</td>
      <td class="result-value-sip">=IF(AND(B10>0, B12>0), ROUND(LN((B11*((1+B12/100)^(1/12)-1))/(B10*(1+B12/100)^(1/12))+1)/LN(1+B12/100), 2), IF(B10>0, ROUND(B11/(B10*12), 2), 0))</td>
      <td class="empty-cell"></td>
      <td class="result-label-lump">NO. OF YEARS REQUIRED</td>
      <td class="result-value-lump">=IF(AND(E12>0, E10>0, E11>E10), ROUND(LN(E11/E10)/LN(1+E12/100), 2), 0)</td>
    </tr>

    <tr><td colspan="5" style="border: none; height: 15px;"></td></tr>

    <!-- SECTION 3: REQD. SIP INVESTMENT AMOUNT vs REQD. LUMP SUM INVESTMENT AMOUNT -->
    <tr>
      <td class="header-sip" colspan="2">REQD. SIP INVESTMENT AMOUNT</td>
      <td class="empty-cell"></td>
      <td class="header-lump" colspan="2">REQD. LUMP SUM INVESTMENT AMOUNT</td>
    </tr>
    <tr>
      <td class="label-cell">Target amount of future value</td>
      <td class="input-cell">${sipAmtFv}</td>
      <td class="empty-cell"></td>
      <td class="label-cell">Target amount of future value</td>
      <td class="input-cell">${lumpAmtFv}</td>
    </tr>
    <tr>
      <td class="label-cell">SIP tenure (no. of years)</td>
      <td class="input-cell">${sipAmtY}</td>
      <td class="empty-cell"></td>
      <td class="label-cell">Investment tenure (no. of years)</td>
      <td class="input-cell">${lumpAmtY}</td>
    </tr>
    <tr>
      <td class="label-cell">Expected return from SIP investment (%)</td>
      <td class="input-cell">${sipAmtR}</td>
      <td class="empty-cell"></td>
      <td class="label-cell">Expected return from lump sum inv. (%)</td>
      <td class="input-cell">${lumpAmtR}</td>
    </tr>
    <tr>
      <td class="result-label-sip">REQUIRED SIP INVESTMENT</td>
      <td class="result-value-sip">=IF(B17>0, ROUND(IF(B18>0, B16 / ((((1+B18/100)^B17 - 1) / ((1+B18/100)^(1/12) - 1)) * (1+B18/100)^(1/12)), B16 / (B17*12)), 0), 0)</td>
      <td class="empty-cell"></td>
      <td class="result-label-lump">REQUIRED LUMP SUM INVESTMENT</td>
      <td class="result-value-lump">=IF(E17>=0, ROUND(E16 / (1+E18/100)^E17, 0), 0)</td>
    </tr>

    <tr><td colspan="5" style="border: none; height: 15px;"></td></tr>

    <!-- SECTION 4: REQD. RATE OF RETURN IN SIP INVESTMENT vs REQD. RATE OF RETURN IN LUMP SUM INVESTMENT -->
    <tr>
      <td class="header-sip" colspan="2">REQD. RATE OF RETURN IN SIP INVESTMENT</td>
      <td class="empty-cell"></td>
      <td class="header-lump" colspan="2">REQD. RATE OF RETURN IN LUMP SUM INVESTMENT</td>
    </tr>
    <tr>
      <td class="label-cell">SIP investment amount (per month)</td>
      <td class="input-cell">${sipRateP}</td>
      <td class="empty-cell"></td>
      <td class="label-cell">Lump sum investment amount</td>
      <td class="input-cell">${lumpRateP}</td>
    </tr>
    <tr>
      <td class="label-cell">Target amount of future value</td>
      <td class="input-cell">${sipRateFv}</td>
      <td class="empty-cell"></td>
      <td class="label-cell">Target amount of future value</td>
      <td class="input-cell">${lumpRateFv}</td>
    </tr>
    <tr>
      <td class="label-cell">SIP tenure (no. of years)</td>
      <td class="input-cell">${sipRateY}</td>
      <td class="empty-cell"></td>
      <td class="label-cell">Investment tenure (no. of years)</td>
      <td class="input-cell">${lumpRateY}</td>
    </tr>
    <tr>
      <td class="result-label-sip">REQUIRED RATE OF RETURN</td>
      <td class="result-value-sip">=IF(AND(B24>0, B22>0, B23>B22*B24*12), ROUND(((1 + RATE(B24*12, -B22, 0, B23, 1))^12 - 1) * 100, 2), 0)</td>
      <td class="empty-cell"></td>
      <td class="result-label-lump">REQUIRED RATE OF RETURN</td>
      <td class="result-value-lump">=IF(AND(E24>0, E22>0), ROUND(((E23/E22)^(1/E24) - 1)*100, 2), 0)</td>
    </tr>
  </table>
</body>
</html>
`;

    const blob = new Blob([htmlContent], { type: 'application/vnd.ms-excel;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', 'PAT_Financials_Quick_Calculations.xls');
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // --- Subcomponents within scope ---

  // 1. SIP Future Value Card
  const renderSipFV = () => (
    <CalcCard title="SIP FUTURE VALUE">
      <Row label="SIP investment amount (per month)" value={sipFvP} onChange={setSipFvP} isCurrency />
      <Row label="SIP tenure (no. of years)" value={sipFvY} onChange={setSipFvY} />
      <Row label="Expected return from SIP investment (%)" value={sipFvR} onChange={setSipFvR} isPercent />
      <ResultRow label="EXPECTED FUTURE VALUE" value={formatCurrency(calculatedSipFv)} />
    </CalcCard>
  );

  // 2. No. of Years Reqd in SIP Card
  const renderSipYears = () => (
    <CalcCard title="NO. OF YEARS REQD. IN SIP INVESTMENT">
      <Row label="SIP investment amount (per month)" value={sipYearsP} onChange={setSipYearsP} isCurrency />
      <Row label="Target amount of future value" value={sipYearsFv} onChange={setSipYearsFv} isCurrency />
      <Row label="Expected return from SIP investment (%)" value={sipYearsR} onChange={setSipYearsR} isPercent />
      <ResultRow label="NO. OF YEARS REQUIRED" value={formatNumber(calculatedSipYears)} />
    </CalcCard>
  );

  // 3. Reqd. SIP Investment Amount Card
  const renderSipReqdAmount = () => (
    <CalcCard title="REQD. SIP INVESTMENT AMOUNT">
      <Row label="Target amount of future value" value={sipAmtFv} onChange={setSipAmtFv} isCurrency />
      <Row label="SIP tenure (no. of years)" value={sipAmtY} onChange={setSipAmtY} />
      <Row label="Expected return from SIP investment (%)" value={sipAmtR} onChange={setSipAmtR} isPercent />
      <ResultRow label="REQUIRED SIP INVESTMENT" value={formatCurrency(calculatedSipAmtP)} />
    </CalcCard>
  );

  // 4. Reqd. Rate of Return in SIP Card
  const renderSipReqdRate = () => (
    <CalcCard title="REQD. RATE OF RETURN IN SIP INVESTMENT">
      <Row label="SIP investment amount (per month)" value={sipRateP} onChange={setSipRateP} isCurrency />
      <Row label="Target amount of future value" value={sipRateFv} onChange={setSipRateFv} isCurrency />
      <Row label="SIP tenure (no. of years)" value={sipRateY} onChange={setSipRateY} />
      <ResultRow label="REQUIRED RATE OF RETURN (%)" value={`${formatNumber(calculatedSipRate)}%`} />
    </CalcCard>
  );

  // 5. Lump Sum Future Value Card
  const renderLumpSumFV = () => (
    <CalcCard title="LUMP SUM FUTURE VALUE">
      <Row label="Lump sum investment amount" value={lumpFvP} onChange={setLumpFvP} isCurrency />
      <Row label="Investment tenure (no. of years)" value={lumpFvY} onChange={setLumpFvY} />
      <Row label="Expected return from lump sum inv. (%)" value={lumpFvR} onChange={setLumpFvR} isPercent />
      <ResultRow label="EXPECTED FUTURE VALUE" value={formatCurrency(calculatedLumpFv)} />
    </CalcCard>
  );

  // 6. No. of Years Reqd in Lump Sum Card
  const renderLumpSumYears = () => (
    <CalcCard title="NO. OF YEARS REQD. IN LUMP SUM INVESTMENT">
      <Row label="Lump sum investment amount" value={lumpYearsP} onChange={setLumpYearsP} isCurrency />
      <Row label="Target amount of future value" value={lumpYearsFv} onChange={setLumpYearsFv} isCurrency />
      <Row label="Expected return from lump sum inv. (%)" value={lumpYearsR} onChange={setLumpYearsR} isPercent />
      <ResultRow label="NO. OF YEARS REQUIRED" value={formatNumber(calculatedLumpYears)} />
    </CalcCard>
  );

  // 7. Reqd. Lump Sum Investment Amount Card
  const renderLumpSumReqdAmount = () => (
    <CalcCard title="REQD. LUMP SUM INVESTMENT AMOUNT">
      <Row label="Target amount of future value" value={lumpAmtFv} onChange={setLumpAmtFv} isCurrency />
      <Row label="Investment tenure (no. of years)" value={lumpAmtY} onChange={setLumpAmtY} />
      <Row label="Expected return from lump sum inv. (%)" value={lumpAmtR} onChange={setLumpAmtR} isPercent />
      <ResultRow label="REQUIRED LUMP SUM INVESTMENT" value={formatCurrency(calculatedLumpAmtP)} />
    </CalcCard>
  );

  // 8. Reqd. Rate of Return in Lump Sum Card
  const renderLumpSumReqdRate = () => (
    <CalcCard title="REQD. RATE OF RETURN IN LUMP SUM INVESTMENT">
      <Row label="Lump sum investment amount" value={lumpRateP} onChange={setLumpRateP} isCurrency />
      <Row label="Target amount of future value" value={lumpRateFv} onChange={setLumpRateFv} isCurrency />
      <Row label="Investment tenure (no. of years)" value={lumpRateY} onChange={setLumpRateY} />
      <ResultRow label="REQUIRED RATE OF RETURN (%)" value={`${formatNumber(calculatedLumpRate)}%`} />
    </CalcCard>
  );

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[9999] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm overflow-hidden">
      <div className="absolute inset-0 pointer-events-auto" onClick={onClose} />
      
      <motion.div 
        initial={{ opacity: 0, scale: 0.95, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 20 }}
        transition={{ duration: 0.3 }}
        className="relative bg-[#FAFAFA] w-full max-w-7xl h-[90vh] flex flex-col rounded-3xl shadow-2xl overflow-hidden border border-slate-200"
      >
        {/* Header */}
        <div className="flex flex-wrap items-center justify-between p-6 bg-brand-primary text-white border-b border-white/20 gap-4 shrink-0">
          <div className="flex items-center gap-3">
            <div className="bg-white/20 p-2.5 rounded-xl">
              <Zap className="w-6 h-6 text-brand-secondary animate-pulse" />
            </div>
            <div>
              <h2 className="text-xl font-bold tracking-tight">Quick Calci</h2>
              <p className="text-xs text-blue-100">Instant SIP and Lump Sum mathematical answers</p>
            </div>
          </div>
          <div className="flex items-center gap-3 ml-auto">
            <button
              onClick={handleDownloadClick}
              className={`flex items-center gap-2 ${isFormOpened ? 'bg-sky-600 hover:bg-sky-700' : 'bg-[#3B82F6] hover:bg-[#1D4ED8]'} text-white px-4 py-2 rounded-xl transition-colors font-semibold text-sm shadow-sm`}
            >
              <Download className="w-4 h-4" />
              {isFormOpened ? 'Download Excel Sheet' : 'Fill Form & Download'}
            </button>
            <LeadFormModal
              isOpen={isFormModalOpen}
              onClose={() => setIsFormModalOpen(false)}
              onSubmitAndDownload={() => {
                localStorage.setItem('pat_form_submitted', 'true');
                setIsFormOpened(true);
                setIsFormModalOpen(false);
                triggerCsvDownload();
              }}
            />
            <button onClick={onClose} className="p-2.5 bg-white/10 hover:bg-white/20 rounded-xl transition-colors text-white">
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>
        {/* Content */}
        <div data-lenis-prevent="true" className="flex-1 overflow-y-auto p-4 sm:p-8 bg-[#FAFAFA]">
          <div className="grid grid-cols-1 xl:grid-cols-2 gap-6 sm:gap-8">
            {/* SIP Column */}
            <div className="flex flex-col gap-6 sm:gap-8">
              <h3 className="text-xl font-bold text-slate-800 flex items-center gap-2">
                <span className="w-2 h-6 bg-brand-primary rounded-full animate-pulse"></span>
                SIP Calculations
              </h3>
              {renderSipFV()}
              {renderSipYears()}
              {renderSipReqdAmount()}
              {renderSipReqdRate()}

              {/* Bottom Download Banner SIP */}
              <div className="flex flex-col sm:flex-row items-center justify-between gap-4 p-6 bg-white rounded-2xl border border-slate-200 mt-2 shadow-sm">
                <div className="text-left">
                  <h4 className="font-bold text-slate-800 text-sm">Download Premium Excel Model</h4>
                  <p className="text-xs text-slate-500 font-medium">Get a fully unlocked model with dynamic formulas and schedules.</p>
                </div>
                <button
                  onClick={handleDownloadClick}
                  className={`flex items-center gap-2 px-5 py-2.5 rounded-xl text-white font-bold text-sm shadow-md transition-all shrink-0 ${isFormOpened ? 'bg-sky-600 hover:bg-sky-700 shadow-sky-100' : 'bg-brand-primary hover:bg-brand-primary/90 shadow-brand-primary/10'}`}
                >
                  <Download className="w-4 h-4" />
                  {isFormOpened ? 'Download Excel Sheet' : 'Fill Form & Download'}
                </button>
              </div>
            </div>

            {/* Lump Sum Column */}
            <div className="flex flex-col gap-6 sm:gap-8">
              <h3 className="text-xl font-bold text-slate-800 flex items-center gap-2 xl:mt-0 mt-4">
                <span className="w-2 h-6 bg-brand-secondary rounded-full animate-pulse"></span>
                Lump Sum Calculations
              </h3>
              {renderLumpSumFV()}
              {renderLumpSumYears()}
              {renderLumpSumReqdAmount()}
              {renderLumpSumReqdRate()}

              {/* Bottom Download Banner Lump Sum */}
              <div className="flex flex-col sm:flex-row items-center justify-between gap-4 p-6 bg-white rounded-2xl border border-slate-200 mt-2 shadow-sm">
                <div className="text-left">
                  <h4 className="font-bold text-slate-800 text-sm">Download Premium Excel Model</h4>
                  <p className="text-xs text-slate-500 font-medium font-medium">Includes decision matrices, visual estimates, and comparative sheets.</p>
                </div>
                <button
                  onClick={handleDownloadClick}
                  className={`flex items-center gap-2 px-5 py-2.5 rounded-xl text-white font-bold text-sm shadow-md transition-all shrink-0 ${isFormOpened ? 'bg-sky-600 hover:bg-sky-700 shadow-sky-100' : 'bg-brand-primary hover:bg-brand-primary/90 shadow-brand-primary/10'}`}
                >
                  <Download className="w-4 h-4" />
                  {isFormOpened ? 'Download Excel Sheet' : 'Fill Form & Download'}
                </button>
              </div>
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
};

// UI Helpers

function CalcCard({ title, children }: { title: string, children: React.ReactNode }) {
  return (
    <div className="bg-white text-sm sm:text-base border border-slate-200 rounded-2xl overflow-hidden shadow-sm hover:shadow-md transition-all duration-300">
      <div className="bg-slate-50 px-5 py-4 border-b border-slate-200 flex items-center justify-center">
        <h4 className="font-bold text-slate-800 text-sm tracking-wide uppercase">{title}</h4>
      </div>
      <div className="flex flex-col p-2 space-y-2">
        {children}
      </div>
    </div>
  );
}

function Row({ label, value, onChange, isCurrency, isPercent }: { label: string, value: number, onChange: (v: number) => void, isCurrency?: boolean, isPercent?: boolean }) {
  // Format value to readable Indian words
  const formatValueToIndianWords = (num: number) => {
    if (!num || isNaN(num) || !isFinite(num)) return '';
    if (num < 1000) return `₹${num}`;
    
    if (num >= 10000000) {
      const cr = num / 10000000;
      return `₹${cr.toFixed(2).replace(/\.00$/, '')} Crore`;
    }
    if (num >= 100000) {
      const lakhs = num / 100000;
      return `₹${lakhs.toFixed(2).replace(/\.00$/, '')} Lakh`;
    }
    return `₹${new Intl.NumberFormat('en-IN').format(num)}`;
  };

  return (
    <div className="flex flex-col sm:flex-row sm:items-center justify-between p-3 sm:px-4 sm:py-3 rounded-xl hover:bg-slate-50 transition-colors gap-3 sm:gap-4 group">
      <div className="flex flex-col flex-1">
        <span className="text-slate-600 font-semibold text-sm sm:text-base">{label}</span>
        {isCurrency && value > 0 && (
          <span className="text-xs text-sky-600 font-bold mt-0.5">
            {formatValueToIndianWords(value)}
          </span>
        )}
      </div>
      <div className="w-full sm:w-[160px] relative shrink-0">
        <input 
          type="number"
          step="any"
          value={value || ''}
          onChange={e => {
            const val = e.target.value;
            onChange(val === '' ? 0 : Number(val));
          }}
          className="w-full bg-white text-right px-4 py-2.5 border border-slate-200 rounded-lg focus:ring-2 focus:ring-brand-primary/20 focus:border-brand-primary outline-none font-bold text-slate-800 text-sm sm:text-base transition-all group-hover:border-slate-300"
        />
        {isPercent && <span className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400 font-bold text-sm sm:text-base">%</span>}
      </div>
    </div>
  );
}

function ResultRow({ label, value }: { label: string, value: string }) {
  return (
    <div className="flex flex-col sm:flex-row sm:items-center justify-between p-4 sm:px-5 sm:py-4 mt-2 bg-brand-primary rounded-xl">
      <div className="text-white flex-1 font-bold text-sm sm:text-base tracking-wide">
        {label}
      </div>
      <div className="w-full sm:w-auto flex items-center sm:justify-end text-white font-black text-xl sm:text-2xl mt-1 sm:mt-0 drop-shadow-md">
        {value}
      </div>
    </div>
  );
}
