import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, RefreshCw, Calculator, TrendingUp, Landmark, Calendar, ChevronRight, HelpCircle, ArrowUpRight, Check, DollarSign, Download, ArrowRight, ShieldCheck, Percent, Layers, Sparkles } from 'lucide-react';
import { LeadFormModal } from './LeadFormModal';

interface AmortizationRow {
  month: number;
  year: number;
  begAmount: number;
  emi: number;
  addDeposit: number;
  principal: number;
  interest: number;
  interestRateMonthly: number;
  endBalance: number;
  cumulativeInterest: number;
}

interface OriginalRow {
  month: number;
  begAmount: number;
  emi: number;
  principal: number;
  interest: number;
  endBalance: number;
  cumulativeInterest: number;
}

interface InvestmentRow {
  month: number;
  begAmount: number;
  growth: number;
  endAmount: number;
  loanOutstanding: number;
  canClose: boolean;
}

interface EarlyLoanClosureLumpSumCalculatorProps {
  isOpen: boolean;
  onClose: () => void;
}

export const EarlyLoanClosureLumpSumCalculator: React.FC<EarlyLoanClosureLumpSumCalculatorProps> = ({ isOpen, onClose }) => {
  // Input parameters
  const [loanAmount, setLoanAmount] = useState<number>(5000000); // 50 Lakhs default
  const [interestRate, setInterestRate] = useState<number>(8.50); // 8.5% default
  const [loanTenureYears, setLoanTenureYears] = useState<number>(20); // 20 years
  const [investmentRate, setInvestmentRate] = useState<number>(12.00); // 12% expected mutual fund returns
  const [lumpSumAmount, setLumpSumAmount] = useState<number>(500000); // 5 Lakhs default
  const [emiPaidMonths, setEmiPaidMonths] = useState<number>(24); // 24 months paid so far

  // Computed Outputs
  const [originalEMI, setOriginalEMI] = useState<number>(0);
  const [originalTotalInterest, setOriginalTotalInterest] = useState<number>(0);
  
  // Strategy A (Prepayment) results
  const [prepaySchedule, setPrepaySchedule] = useState<AmortizationRow[]>([]);
  const [prepayNewTenureMonths, setPrepayNewTenureMonths] = useState<number>(0);
  const [prepayTotalInterest, setPrepayTotalInterest] = useState<number>(0);
  const [prepayInterestSaved, setPrepayInterestSaved] = useState<number>(0);
  const [prepayTenureSavedMonths, setPrepayTenureSavedMonths] = useState<number>(0);

  // Strategy B (Investment) results
  const [investSchedule, setInvestSchedule] = useState<InvestmentRow[]>([]);
  const [earlyClosureMonth, setEarlyClosureMonth] = useState<number>(-1);
  const [surplusWealthAtClosure, setSurplusWealthAtClosure] = useState<number>(0);
  const [investmentValueAtEnd, setInvestmentValueAtEnd] = useState<number>(0);
  const [investTotalInvested, setInvestTotalInvested] = useState<number>(0);
  const [investTotalReturns, setInvestTotalReturns] = useState<number>(0);
  const [investLumpSumFutureValue, setInvestLumpSumFutureValue] = useState<number>(0);
  const [investLumpSumReturns, setInvestLumpSumReturns] = useState<number>(0);
  const [lumpSumTenureLabel, setLumpSumTenureLabel] = useState<string>('');
  const [lumpSumTenureDesc, setLumpSumTenureDesc] = useState<string>('');

  // Form & Lead Modal
  const [isFormOpened, setIsFormOpened] = useState(false);
  const [isFormModalOpen, setIsFormModalOpen] = useState(false);

  // Active Tab: 'summary' | 'schedule' | 'comparison'
  const [activeTab, setActiveTab] = useState<'summary' | 'schedule' | 'comparison'>('summary');

  // Format utility
  const formatCurrency = (val: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0
    }).format(val);
  };

  // Run calculations whenever parameters change
  useEffect(() => {
    calculateResults();
  }, [loanAmount, interestRate, loanTenureYears, investmentRate, lumpSumAmount, emiPaidMonths]);

  const calculateResults = () => {
    const P = loanAmount;
    const r = (interestRate / 100) / 12;
    const n = loanTenureYears * 12;

    if (P <= 0 || r <= 0 || n <= 0) return;

    // 1. Calculate Original EMI
    const origEmi = P * (r * Math.pow(1 + r, n)) / (Math.pow(1 + r, n) - 1);
    setOriginalEMI(origEmi);

    // 2. Generate Original Amortization Schedule
    const origSchedule: OriginalRow[] = [];
    let origBalance = P;
    let origCumInterest = 0;

    for (let m = 1; m <= n; m++) {
      const interest = origBalance * r;
      const principal = Math.min(origBalance, origEmi - interest);
      origCumInterest += interest;
      const endBalance = Math.max(0, origBalance - principal);
      
      origSchedule.push({
        month: m,
        begAmount: origBalance,
        emi: origBalance > 0 ? origEmi : 0,
        principal,
        interest,
        endBalance,
        cumulativeInterest: origCumInterest
      });

      origBalance = endBalance;
    }
    const origTotalInt = origCumInterest;
    setOriginalTotalInterest(origTotalInt);

    // 3. Generate Strategy A: Prepayment Schedule
    const prepaySched: AmortizationRow[] = [];
    let prepBalance = P;
    let prepCumInterest = 0;
    let finalPrepayMonth = n;
    let hasClosed = false;

    for (let m = 1; m <= n; m++) {
      if (prepBalance <= 0) {
        if (!hasClosed) {
          finalPrepayMonth = m - 1;
          hasClosed = true;
        }
        prepaySched.push({
          month: m,
          year: Math.ceil(m / 12),
          begAmount: 0,
          emi: 0,
          addDeposit: 0,
          principal: 0,
          interest: 0,
          interestRateMonthly: r * 100,
          endBalance: 0,
          cumulativeInterest: prepCumInterest
        });
        continue;
      }

      const interest = prepBalance * r;
      
      // Determine additional deposit for this month
      const addDep = m === (emiPaidMonths + 1) ? lumpSumAmount : 0;

      const normalEmiPayment = Math.min(prepBalance + interest, origEmi);
      const principalFromEmi = Math.max(0, normalEmiPayment - interest);
      
      // Total principal repaid this month including prepayments
      const totalPrincipalRepaid = Math.min(prepBalance, principalFromEmi + addDep);
      prepCumInterest += interest;
      
      const endBalance = Math.max(0, prepBalance - totalPrincipalRepaid);

      prepaySched.push({
        month: m,
        year: Math.ceil(m / 12),
        begAmount: prepBalance,
        emi: normalEmiPayment,
        addDeposit: addDep,
        principal: totalPrincipalRepaid,
        interest,
        interestRateMonthly: r * 100,
        endBalance,
        cumulativeInterest: prepCumInterest
      });

      prepBalance = endBalance;
    }

    if (!hasClosed) {
      finalPrepayMonth = n;
    }

    setPrepaySchedule(prepaySched);
    setPrepayNewTenureMonths(finalPrepayMonth);
    setPrepayTotalInterest(prepCumInterest);
    setPrepayInterestSaved(Math.max(0, origTotalInt - prepCumInterest));
    setPrepayTenureSavedMonths(Math.max(0, n - finalPrepayMonth));

    // 4. Generate Strategy B: Investment Growth comparison
    const investSched: InvestmentRow[] = [];
    const r_inv = (investmentRate / 100) / 12;
    let currentInvestVal = 0;
    let closureMonthIndex = -1;
    let surplus = 0;
    let totalInvestedUptoClosure = 0;
    let totalGrowthUptoClosure = 0;
    let hasReachedClosure = false;

    for (let m = 1; m <= n; m++) {
      const origOutstanding = origSchedule[m - 1]?.endBalance ?? 0;
      const startVal = currentInvestVal;
      const growth = startVal * r_inv;
      const addDep = m === (emiPaidMonths + 1) ? lumpSumAmount : 0;
      const endVal = startVal + growth + addDep;

      const canClose = endVal >= origOutstanding;
      if (canClose && closureMonthIndex === -1 && origOutstanding > 0 && m > emiPaidMonths) {
        closureMonthIndex = m;
        surplus = endVal - origOutstanding;
        hasReachedClosure = true;
      }

      if (!hasReachedClosure) {
        totalInvestedUptoClosure += addDep;
        totalGrowthUptoClosure += growth;
      } else if (m === closureMonthIndex) {
        totalInvestedUptoClosure += addDep;
        totalGrowthUptoClosure += growth;
      }

      investSched.push({
        month: m,
        begAmount: startVal,
        growth,
        endAmount: endVal,
        loanOutstanding: origOutstanding,
        canClose
      });

      currentInvestVal = endVal;
    }

    if (!hasReachedClosure) {
      totalInvestedUptoClosure = lumpSumAmount;
      totalGrowthUptoClosure = investSched.reduce((sum, row) => sum + row.growth, 0);
    }

    setInvestSchedule(investSched);
    setEarlyClosureMonth(closureMonthIndex);
    setSurplusWealthAtClosure(surplus);
    setInvestmentValueAtEnd(currentInvestVal);
    setInvestTotalInvested(totalInvestedUptoClosure);
    setInvestTotalReturns(totalGrowthUptoClosure);

    // Calculate lumpsum return at loan tenure end for Case 2
    let lumpsumFV = 0;
    let lumpsumTenureLabel = `${loanTenureYears} Yrs`;
    let lumpsumTenureDescriptionText = `the original ${loanTenureYears} Year loan tenure`;

    if (lumpSumAmount > 0 && emiPaidMonths < n) {
        const remainingMonths = n - emiPaidMonths;
        const remainingYears = remainingMonths / 12;
        lumpsumFV = lumpSumAmount * Math.pow(1 + (investmentRate / 100), remainingYears);
        
        const wholeYears = Math.floor(remainingMonths / 12);
        const remainingMos = remainingMonths % 12;
        let label = "";
        if (wholeYears > 0 && remainingMos > 0) {
          label = `${wholeYears} Yrs ${remainingMos} Mos`;
        } else if (wholeYears > 0) {
          label = `${wholeYears} Yrs`;
        } else {
          label = `${remainingMos} Mos`;
        }
        
        lumpsumTenureLabel = label;
        lumpsumTenureDescriptionText = `the remaining ${label}`;
    }

    const lumpsumGrowth = Math.max(0, lumpsumFV - lumpSumAmount);
    setInvestLumpSumFutureValue(lumpsumFV);
    setInvestLumpSumReturns(lumpsumGrowth);
    setLumpSumTenureLabel(lumpsumTenureLabel);
    setLumpSumTenureDesc(lumpsumTenureDescriptionText);
  };

  const exportToExcel = () => {
    if (prepaySchedule.length === 0) return;

    const htmlContent = `
<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40">
<head>
<!--[if gte mso 9]>
<xml>
<x:ExcelWorkbook>
<x:ExcelWorksheets>
<x:ExcelWorksheet>
<x:Name>LumpSum Loan Closure</x:Name>
<x:WorksheetOptions>
<x:DisplayGridlines/>
<x:ProtectContents>True</x:ProtectContents>
</x:WorksheetOptions>
</x:ExcelWorksheet>
</x:ExcelWorksheets>
</x:ExcelWorkbook>
</xml>
<![endif]-->
<meta charset="utf-8">
<style>
  table { border-collapse: collapse; font-family: 'Segoe UI', Arial, sans-serif; }
  th, td { border: 1px solid #CBD5E1; padding: 10px; font-size: 11pt; mso-protection: locked hidden; }
  
  .title-cell { font-size: 16pt; font-weight: bold; color: #FFFFFF; background-color: #0F172A; padding: 15px; border: none; text-align: center; mso-protection: locked hidden; }
  
  .section-header { background-color: #334155; color: #FFFFFF; font-weight: bold; font-size: 12pt; text-align: left; padding: 10px; mso-protection: locked hidden; }
  .grid-header { background-color: #1E293B; color: #FFFFFF; font-weight: bold; font-size: 11pt; text-align: center; mso-protection: locked hidden; }
  
  .label-cell { color: #334155; font-weight: 500; background-color: #F8FAFC; mso-protection: locked hidden; }
  .value-cell { text-align: right; font-weight: bold; color: #020617; mso-protection: locked hidden; }
  .input-cell { text-align: right; font-weight: bold; color: #020617; background-color: #FFFFD0; mso-protection: unlocked; border: 1px solid #94A3B8; }
  
  .result-label { font-weight: bold; color: #0EA5E9; background-color: #F0F9FF; border: 1px solid #BAE6FD; mso-protection: locked hidden; }
  .result-value { font-weight: bold; color: #0369A1; background-color: #E0F2FE; text-align: right; border: 1px solid #BAE6FD; mso-protection: locked hidden; }
  
  .schedule-row-even { background-color: #F8FAFC; }
  .schedule-row-odd { background-color: #FFFFFF; }
  
  .currency-cell { text-align: right; mso-protection: locked hidden; }
  .center-cell { text-align: center; mso-protection: locked hidden; }
  .empty-cell { background-color: #FFFFFF; border: none; mso-protection: locked hidden; }
</style>
</head>
<body>
  <table>
    <tr>
      <td class="title-cell" colspan="8">PAT FINANCIALS - EARLY LOAN CLOSURE (LUMP SUM) REPORT</td>
    </tr>
    <tr><td colspan="8" style="border: none; height: 10px;"></td></tr>

    <tr><td class="section-header" colspan="8">INPUTS &amp; ASSUMPTIONS</td></tr>
    <tr>
      <td class="label-cell" colspan="2">Loan Amount</td>
      <td class="input-cell" colspan="2">${loanAmount}</td>
      <td class="empty-cell"></td>
      <td class="label-cell" colspan="2">Interest Rate (% p.a.)</td>
      <td class="input-cell">${interestRate}</td>
    </tr>
    <tr>
      <td class="label-cell" colspan="2">Loan Tenure (Years)</td>
      <td class="input-cell" colspan="2">${loanTenureYears}</td>
      <td class="empty-cell"></td>
      <td class="label-cell" colspan="2">Total Lump Sum Prepayment</td>
      <td class="input-cell">${lumpSumAmount}</td>
    </tr>
    <tr>
      <td class="label-cell" colspan="2">Investment Return Rate (%)</td>
      <td class="input-cell" colspan="2">${investmentRate}</td>
      <td class="empty-cell"></td>
      <td class="label-cell" colspan="2">EMI Paid So Far (Months)</td>
      <td class="input-cell">${emiPaidMonths}</td>
    </tr>

    <tr><td colspan="8" style="border: none; height: 15px;"></td></tr>

    <tr><td class="section-header" colspan="8">PREPAYMENT STRATEGY SUMMARY (CASE 1)</td></tr>
    <tr>
      <td class="result-label" colspan="2">Original Total Interest Paid</td>
      <td class="result-value" colspan="2">=ROUND(PMT(H4/12/100, C5*12, -C4)*C5*12-C4, 0)</td>
      <td class="empty-cell"></td>
      <td class="result-label" colspan="2">Prepayment Total Interest Paid</td>
      <td class="result-value" id="prepay-total-interest-formula">=ROUND(SUM(G23:G${22 + prepaySchedule.length}), 0)</td>
    </tr>
    <tr>
      <td class="result-label" colspan="2">Net Interest Saved</td>
      <td class="result-value" colspan="2" style="color: #0ea5e9;">=ROUND(C9-H9, 0)</td>
      <td class="empty-cell"></td>
      <td class="result-label" colspan="2">New Tenure (Months)</td>
      <td class="result-value">=COUNTIF(C23:C${22 + prepaySchedule.length}, ">0")</td>
    </tr>
    <tr>
      <td class="result-label" colspan="2">Months Saved</td>
      <td class="result-value" colspan="2" style="color: #0ea5e9;">=(C5*12)-H10</td>
      <td class="empty-cell" colspan="4"></td>
    </tr>

    <tr><td colspan="8" style="border: none; height: 15px;"></td></tr>

    <tr><td class="section-header" colspan="8">INVESTMENT STRATEGY SUMMARY (CASE 2)</td></tr>
    <tr>
      <td class="result-label" colspan="2">Invested Amount</td>
      <td class="result-value" colspan="2">=$H$5</td>
      <td class="empty-cell"></td>
      <td class="result-label" colspan="2">Investment Returns Rate</td>
      <td class="result-value">=$C$6</td>
    </tr>
    <tr>
      <td class="result-label" colspan="2">Total Corpus Generated</td>
      <td class="result-value" colspan="2">=ROUND(C14*(1+H14/100)^((C5*12-H6)/12), 0)</td>
      <td class="empty-cell"></td>
      <td class="result-label" colspan="2">Total Gain</td>
      <td class="result-value">=ROUND(C15-C14, 0)</td>
    </tr>

    <tr><td colspan="8" style="border: none; height: 15px;"></td></tr>

    <tr><td class="section-header" colspan="8">STRATEGIC COMPARISON &amp; DECISION SURPLUS</td></tr>
    <tr>
      <td class="result-label" colspan="2">Net Surplus Wealth (vs Prepaying)</td>
      <td class="result-value" colspan="2" style="color: #10B981; background-color: #ECFDF5; border-color: #A7F3D0;">=ROUND(H15-C10, 0)</td>
      <td class="empty-cell" colspan="4"></td>
    </tr>

    <tr><td colspan="8" style="border: none; height: 15px;"></td></tr>

    <tr><td class="section-header" colspan="8">MONTHLY PREPAYMENT SCHEDULE</td></tr>
    <tr>
      <td class="grid-header">Month</td>
      <td class="grid-header">Year</td>
      <td class="grid-header">Beg. Balance</td>
      <td class="grid-header">EMI</td>
      <td class="grid-header">Addl. Deposit</td>
      <td class="grid-header">Principal</td>
      <td class="grid-header">Interest</td>
      <td class="grid-header">End Balance</td>
    </tr>
    ${prepaySchedule.map((row, idx) => {
      const rowClass = idx % 2 === 0 ? 'schedule-row-even' : 'schedule-row-odd';
      const r = 23 + idx; // Excel row index starts at 23 for schedule Month 1
      
      const begBalanceFormula = idx === 0 ? '=$C$4' : `=IF(H${r-1}>0, H${r-1}, 0)`;
      const emiFormula = `=IF(C${r}>0, MIN(C${r}+G${r}, ROUND(PMT($H$4/12/100, $C$5*12, -$C$4), 2)), 0)`;
      const addDepFormula = `=IF(A${r}=$H$6+1, MIN(MAX(0, C${r}-D${r}+G${r}), $H$5), 0)`;
      const principalFormula = `=IF(C${r}>0, MIN(C${r}, D${r}-G${r}+E${r}), 0)`;
      const interestFormula = `=ROUND(C${r}*($H$4/12/100), 2)`;
      const endBalanceFormula = `=ROUND(MAX(0, C${r}-F${r}), 2)`;

      return `
      <tr class="${rowClass}">
        <td class="center-cell">${row.month}</td>
        <td class="center-cell">${row.year}</td>
        <td class="currency-cell">${begBalanceFormula}</td>
        <td class="currency-cell">${emiFormula}</td>
        <td class="currency-cell" style="background-color: #FFFFD0; mso-protection: unlocked;">${addDepFormula}</td>
        <td class="currency-cell">${principalFormula}</td>
        <td class="currency-cell">${interestFormula}</td>
        <td class="currency-cell" style="font-weight: bold;">${endBalanceFormula}</td>
      </tr>
      `;
    }).join('')}
  </table>
</body>
</html>
`;

    const blob = new Blob([htmlContent], { type: 'application/vnd.ms-excel;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `early_loan_closure_lumpsum_${new Date().toISOString().split('T')[0]}.xls`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm overflow-hidden">
        <motion.div 
          initial={{ opacity: 0, scale: 0.95, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 20 }}
          transition={{ duration: 0.3 }}
          className="relative w-full max-w-6xl h-[90vh] bg-white rounded-3xl shadow-2xl flex flex-col overflow-hidden border border-slate-100"
          id="early-closure-modal"
          data-lenis-prevent=""
        >
          <style>{`
            .custom-table-container::-webkit-scrollbar {
              width: 8px;
              height: 8px;
            }
            .custom-table-container::-webkit-scrollbar-track {
              background: #f1f5f9;
              border-radius: 4px;
            }
            .custom-table-container::-webkit-scrollbar-thumb {
              background: #cbd5e1;
              border-radius: 4px;
            }
            .custom-table-container::-webkit-scrollbar-thumb:hover {
              background: #94a3b8;
            }
            
            .custom-sidebar-container::-webkit-scrollbar {
              width: 6px;
            }
            .custom-sidebar-container::-webkit-scrollbar-track {
              background: #f8fafc;
            }
            .custom-sidebar-container::-webkit-scrollbar-thumb {
              background: #e2e8f0;
              border-radius: 3px;
            }
            .custom-sidebar-container::-webkit-scrollbar-thumb:hover {
              background: #cbd5e1;
            }

            .custom-tab-panel::-webkit-scrollbar {
              width: 8px;
              height: 8px;
            }
            .custom-tab-panel::-webkit-scrollbar-track {
              background: #f8fafc;
            }
            .custom-tab-panel::-webkit-scrollbar-thumb {
              background: #cbd5e1;
              border-radius: 4px;
            }
            .custom-tab-panel::-webkit-scrollbar-thumb:hover {
              background: #94a3b8;
            }
          `}</style>
          {/* Header */}
        <div className="flex flex-wrap items-center justify-between p-6 bg-brand-primary text-white border-b border-white/20 gap-4 shrink-0">
          <div className="flex items-center gap-3">
            <div className="bg-white/20 p-2.5 rounded-xl">
              <Calculator className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-xl font-bold tracking-tight">Early Loan Closure - Lump Sum</h2>
              <p className="text-xs text-blue-100">Test direct prepayment vs investing mutual funds side-by-side</p>
            </div>
          </div>
          <div className="flex items-center gap-3 ml-auto">
            <button
              onClick={() => {
                if (!isFormOpened) {
                  setIsFormModalOpen(true);
                } else {
                  exportToExcel();
                }
              }}
              className={`flex items-center gap-2 ${isFormOpened ? 'bg-sky-600 hover:bg-sky-700' : 'bg-[#3B82F6] hover:bg-[#1D4ED8]'} text-white px-4 py-2 rounded-xl transition-colors font-semibold text-sm shadow-sm`}
            >
              <Download className="w-4 h-4" />
              {isFormOpened ? 'Download Excel Sheet' : 'Fill Form & Download'}
            </button>
            <LeadFormModal
              isOpen={isFormModalOpen}
              onClose={() => setIsFormModalOpen(false)}
              onSubmitAndDownload={() => {
                setIsFormOpened(true);
                setIsFormModalOpen(false);
                exportToExcel();
              }}
            />
            <button onClick={onClose} className="p-2.5 bg-white/10 hover:bg-white/20 rounded-xl transition-colors text-white">
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>
        <div className="flex-grow flex flex-col lg:flex-row min-h-0 bg-slate-50/40">
            {/* Input Controls */}
            <div className="w-full lg:w-80 border-r border-slate-100 bg-white p-6 overflow-y-auto shrink-0 space-y-6 custom-sidebar-container">
              <div className="flex items-center justify-between">
                <span className="text-sm font-semibold text-slate-400 uppercase tracking-wider">Inputs & Assumptions</span>
                <button 
                  onClick={() => {
                    setLoanAmount(5000000);
                    setInterestRate(8.5);
                    setLoanTenureYears(20);
                    setInvestmentRate(12);
                    setLumpSumAmount(500000);
                    setEmiPaidMonths(24);
                  }}
                  className="p-1.5 text-slate-400 hover:text-sky-500 hover:bg-slate-50 rounded-lg transition-colors"
                  title="Reset Defaults"
                >
                  <RefreshCw className="w-4 h-4" />
                </button>
              </div>

              {/* Case 1: Loan Prepayment */}
              <div className="pt-2 pb-1 border-b border-slate-100">
                <span className="text-[11px] font-bold text-sky-600 uppercase tracking-widest">Case 1: Loan Details</span>
              </div>

              {/* Loan Amount */}
              <div className="space-y-2">
                <div className="flex flex-col gap-1">
                  <label className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Loan Amount (₹)</label>
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-slate-400">₹</span>
                    <input 
                      type="number" 
                      value={loanAmount}
                      onChange={(e) => setLoanAmount(Math.max(0, Number(e.target.value)))}
                      onWheel={(e) => e.currentTarget.blur()}
                      className="w-full text-sm font-extrabold text-slate-800 bg-slate-50 border border-slate-200 rounded-xl px-3 py-1.5 focus:outline-none focus:ring-2 focus:ring-sky-500/20 focus:border-sky-500 transition-all [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none"
                    />
                  </div>
                  <span className="text-[10px] text-right font-medium text-sky-600 mt-0.5">{formatCurrency(loanAmount)}</span>
                </div>
                <input 
                  type="range" 
                  min="100000" 
                  max="100000000" 
                  step="50000" 
                  value={loanAmount}
                  onChange={(e) => setLoanAmount(Number(e.target.value))}
                  className="w-full accent-sky-500 h-1.5 bg-slate-100 rounded-lg appearance-none cursor-pointer"
                />
                <div className="flex justify-between text-[10px] text-slate-400">
                  <span>1 L</span>
                  <span>10 Cr</span>
                </div>
              </div>

              {/* Interest Rate */}
              <div className="space-y-2">
                <div className="flex flex-col gap-1">
                  <label className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Loan Interest Rate (% p.a.)</label>
                  <div className="flex items-center gap-2">
                    <input 
                      type="number" 
                      step="0.01"
                      value={interestRate}
                      onChange={(e) => setInterestRate(Math.max(0, Number(e.target.value)))}
                      onWheel={(e) => e.currentTarget.blur()}
                      className="w-full text-sm font-extrabold text-slate-800 bg-slate-50 border border-slate-200 rounded-xl px-3 py-1.5 focus:outline-none focus:ring-2 focus:ring-sky-500/20 focus:border-sky-500 transition-all"
                    />
                    <span className="text-xs font-bold text-slate-400">%</span>
                  </div>
                </div>
                <input 
                  type="range" 
                  min="3" 
                  max="25" 
                  step="0.05" 
                  value={interestRate}
                  onChange={(e) => setInterestRate(Number(e.target.value))}
                  className="w-full accent-sky-500 h-1.5 bg-slate-100 rounded-lg appearance-none cursor-pointer"
                />
                <div className="flex justify-between text-[10px] text-slate-400">
                  <span>3%</span>
                  <span>25%</span>
                </div>
              </div>

              {/* Loan Tenure */}
              <div className="space-y-2">
                <div className="flex flex-col gap-1">
                  <label className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Loan Tenure (Years)</label>
                  <div className="flex items-center gap-2">
                    <input 
                      type="number" 
                      value={loanTenureYears}
                      onChange={(e) => setLoanTenureYears(Math.max(1, Number(e.target.value)))}
                      onWheel={(e) => e.currentTarget.blur()}
                      className="w-full text-sm font-extrabold text-slate-800 bg-slate-50 border border-slate-200 rounded-xl px-3 py-1.5 focus:outline-none focus:ring-2 focus:ring-sky-500/20 focus:border-sky-500 transition-all"
                    />
                    <span className="text-xs font-bold text-slate-400">Yrs</span>
                  </div>
                  <span className="text-[10px] text-right font-medium text-sky-600 mt-0.5">{loanTenureYears * 12} Months</span>
                </div>
                <input 
                  type="range" 
                  min="1" 
                  max="30" 
                  step="1" 
                  value={loanTenureYears}
                  onChange={(e) => setLoanTenureYears(Number(e.target.value))}
                  className="w-full accent-sky-500 h-1.5 bg-slate-100 rounded-lg appearance-none cursor-pointer"
                />
                <div className="flex justify-between text-[10px] text-slate-400">
                  <span>1 Yr</span>
                  <span>30 Yrs</span>
                </div>
              </div>

              {/* EMI Paid So Far */}
              <div className="space-y-2">
                <div className="flex flex-col gap-1">
                  <label className="text-xs font-semibold text-slate-500 uppercase tracking-wider">EMI Paid So Far (Months)</label>
                  <div className="flex items-center gap-2">
                    <input 
                      type="number" 
                      value={emiPaidMonths}
                      onChange={(e) => setEmiPaidMonths(Math.max(0, Math.min(loanTenureYears * 12, Number(e.target.value))))}
                      onWheel={(e) => e.currentTarget.blur()}
                      className="w-full text-sm font-extrabold text-slate-800 bg-slate-50 border border-slate-200 rounded-xl px-3 py-1.5 focus:outline-none focus:ring-2 focus:ring-sky-500/20 focus:border-sky-500 transition-all"
                    />
                    <span className="text-xs font-bold text-slate-400">Mos</span>
                  </div>
                  <span className="text-[10px] text-right font-medium text-sky-600 mt-0.5">
                    {Math.floor(emiPaidMonths / 12)} Yrs {emiPaidMonths % 12} Mos
                  </span>
                </div>
                <input 
                  type="range" 
                  min="0" 
                  max={loanTenureYears * 12} 
                  step="1" 
                  value={emiPaidMonths}
                  onChange={(e) => setEmiPaidMonths(Number(e.target.value))}
                  className="w-full accent-sky-500 h-1.5 bg-slate-100 rounded-lg appearance-none cursor-pointer"
                />
                <div className="flex justify-between text-[10px] text-slate-400">
                  <span>0 Mos</span>
                  <span>{loanTenureYears * 12} Mos</span>
                </div>
              </div>

              {/* Lump Sum Prepayment */}
              <div className="space-y-2 mt-4 pt-4 border-t border-slate-100">
                <div className="flex flex-col gap-1">
                  <label className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Total Lump Sum Deposit (₹)</label>
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-slate-400">₹</span>
                    <input 
                      type="number" 
                      value={lumpSumAmount}
                      onChange={(e) => setLumpSumAmount(Math.max(0, Number(e.target.value)))}
                      onWheel={(e) => e.currentTarget.blur()}
                      className="w-full text-sm font-extrabold text-slate-800 bg-slate-50 border border-slate-200 rounded-xl px-3 py-1.5 focus:outline-none focus:ring-2 focus:ring-sky-500/20 focus:border-sky-500 transition-all [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none"
                    />
                  </div>
                  <span className="text-[10px] text-right font-medium text-sky-600 mt-0.5">{formatCurrency(lumpSumAmount)}</span>
                </div>
                <input 
                  type="range" 
                  min="0" 
                  max={loanAmount} 
                  step="10000" 
                  value={lumpSumAmount}
                  onChange={(e) => setLumpSumAmount(Number(e.target.value))}
                  className="w-full accent-sky-500 h-1.5 bg-slate-100 rounded-lg appearance-none cursor-pointer"
                />
                <div className="flex justify-between text-[10px] text-slate-400">
                  <span>0</span>
                  <span>Max Loan</span>
                </div>
              </div>

              {/* Case 2: Investment Option */}
              <div className="pt-4 pb-1 border-b border-slate-100">
                <span className="text-[11px] font-bold text-blue-600 uppercase tracking-widest">Case 2: Investment Details</span>
              </div>

              {/* Mutual Fund Return Rate */}
              <div className="space-y-2 mt-4">
                <div className="flex flex-col gap-1">
                  <label className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Rate of Return (% p.a.)</label>
                  <div className="flex items-center gap-2">
                    <input 
                      type="number" 
                      step="0.1"
                      value={investmentRate}
                      onChange={(e) => setInvestmentRate(Math.max(0, Number(e.target.value)))}
                      onWheel={(e) => e.currentTarget.blur()}
                      className="w-full text-sm font-extrabold text-blue-600 bg-blue-50/20 border border-blue-200 rounded-xl px-3 py-1.5 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all"
                    />
                    <span className="text-xs font-bold text-blue-400">%</span>
                  </div>
                </div>
                <input 
                  type="range" 
                  min="3" 
                  max="30" 
                  step="0.25" 
                  value={investmentRate}
                  onChange={(e) => setInvestmentRate(Number(e.target.value))}
                  className="w-full accent-blue-500 h-1.5 bg-slate-100 rounded-lg appearance-none cursor-pointer"
                />
                <div className="flex justify-between text-[10px] text-slate-400">
                  <span>3%</span>
                  <span>30%</span>
                </div>
              </div>
            </div>

            {/* Calculations & Visualization Section */}
            <div className="flex-grow flex flex-col overflow-hidden">
              {/* Tab Bar */}
              <div className="flex border-b border-slate-100 bg-white px-8 py-3 gap-6 shrink-0">
                <button 
                  onClick={() => setActiveTab('summary')}
                  className={`pb-2 px-1 font-bold text-sm tracking-wide border-b-2 transition-colors ${activeTab === 'summary' ? 'border-sky-500 text-sky-600' : 'border-transparent text-slate-400 hover:text-slate-600'}`}
                >
                  Overview &amp; Strategies
                </button>
                <button 
                  onClick={() => setActiveTab('schedule')}
                  className={`pb-2 px-1 font-bold text-sm tracking-wide border-b-2 transition-colors ${activeTab === 'schedule' ? 'border-sky-500 text-sky-600' : 'border-transparent text-slate-400 hover:text-slate-600'}`}
                >
                  Interactive Schedule Table
                </button>
                <button 
                  onClick={() => setActiveTab('comparison')}
                  className={`pb-2 px-1 font-bold text-sm tracking-wide border-b-2 transition-colors ${activeTab === 'comparison' ? 'border-sky-500 text-sky-600' : 'border-transparent text-slate-400 hover:text-slate-600'}`}
                >
                  Side-By-Side Comparison
                </button>
              </div>

              {/* Tab Content Panels */}
              <div className="flex-grow overflow-y-auto p-4 md:p-5 min-h-0 space-y-4 custom-tab-panel">
                
                {activeTab === 'summary' && (
                  <div className="space-y-4">
                    {/* Key Core Metrics */}
                    <div className="space-y-4">
                      {/* Case 1 Boxes */}
                      <div className="bg-sky-50/50 p-4 rounded-2xl border border-sky-100 space-y-3">
                        <div className="flex items-center gap-2 border-b border-sky-100 pb-1.5">
                          <ShieldCheck className="w-4.5 h-4.5 text-sky-600" />
                          <h3 className="font-bold text-sky-800 tracking-tight text-sm">Case 1: Prepayment</h3>
                        </div>
                        
                        <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                          <div className="bg-white p-3 rounded-xl border border-sky-50/80 shadow-sm flex flex-col justify-between min-h-[68px]">
                            <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block leading-tight">Initial Interest</span>
                            <h4 className="text-base font-extrabold text-slate-700 mt-1">{formatCurrency(originalTotalInterest)}</h4>
                          </div>
                          
                          <div className="bg-white p-3 rounded-xl border border-sky-50/80 shadow-sm flex flex-col justify-between min-h-[68px]">
                            <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block leading-tight">Interest After Deposit</span>
                            <h4 className="text-base font-extrabold text-slate-700 mt-1">{formatCurrency(prepayTotalInterest)}</h4>
                          </div>
                          
                          <div className="bg-gradient-to-br from-sky-500 to-sky-600 p-3 rounded-xl border border-sky-400/30 shadow-sm text-white flex flex-col justify-between min-h-[68px]">
                            <span className="text-[10px] font-bold text-sky-50 uppercase tracking-wider block leading-tight">Interest Save</span>
                            <h4 className="text-base font-extrabold text-white mt-1">{formatCurrency(prepayInterestSaved)}</h4>
                          </div>

                          <div className="bg-white p-3 rounded-xl border border-sky-50/80 shadow-sm flex flex-col justify-between min-h-[68px]">
                            <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block leading-tight">Original Tenure</span>
                            <h4 className="text-base font-extrabold text-slate-700 mt-1">{loanTenureYears} Yrs</h4>
                          </div>
                          
                          <div className="bg-white p-3 rounded-xl border border-sky-50/80 shadow-sm flex flex-col justify-between min-h-[68px]">
                            <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block leading-tight">Tenure After Deposit</span>
                            <h4 className="text-base font-extrabold text-slate-700 mt-1">{Math.floor(prepayNewTenureMonths / 12)} Yrs {prepayNewTenureMonths % 12} Mos</h4>
                          </div>
                          
                          <div className="bg-gradient-to-br from-sky-500 to-sky-600 p-3 rounded-xl border border-sky-400/30 shadow-sm text-white flex flex-col justify-between min-h-[68px]">
                            <span className="text-[10px] font-bold text-sky-50 uppercase tracking-wider block leading-tight">Period Saved</span>
                            <h4 className="text-base font-extrabold text-white mt-1">{Math.floor(prepayTenureSavedMonths / 12)} Yrs {prepayTenureSavedMonths % 12} Mos</h4>
                          </div>
                        </div>
                      </div>

                      {/* Case 2 Boxes */}
                      <div className="bg-blue-50/50 p-4 rounded-2xl border border-blue-100 space-y-3">
                        <div className="flex items-center gap-2 border-b border-blue-100 pb-1.5">
                          <TrendingUp className="w-4.5 h-4.5 text-blue-600" />
                          <h3 className="font-bold text-blue-800 tracking-tight text-sm">Case 2: Investment Option</h3>
                        </div>
                        
                        <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                          <div className="bg-white p-3 rounded-xl border border-blue-50/80 shadow-sm flex flex-col justify-between min-h-[68px]">
                            <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block leading-tight">Invested Amount</span>
                            <h4 className="text-base font-extrabold text-slate-700 mt-1">{formatCurrency(lumpSumAmount)}</h4>
                          </div>

                          <div className="bg-white p-3 rounded-xl border border-blue-50/80 shadow-sm flex flex-col justify-between min-h-[68px]">
                            <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block leading-tight">Rate of Return</span>
                            <h4 className="text-base font-extrabold text-slate-700 mt-1">{investmentRate}% <span className="text-xs font-normal text-slate-400">p.a.</span></h4>
                          </div>

                          <div className="bg-white p-3 rounded-xl border border-blue-50/80 shadow-sm flex flex-col justify-between min-h-[68px] col-span-2 md:col-span-1">
                            <div className="leading-tight">
                              <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block truncate">Total Corpus Generated</span>
                              <span className="text-[9px] text-slate-400 block mt-0.5">(After {lumpSumTenureLabel})</span>
                            </div>
                            <h4 className="text-base font-extrabold text-blue-600 mt-1">{formatCurrency(investLumpSumFutureValue)}</h4>
                          </div>

                          <div className="bg-gradient-to-br from-blue-500 to-blue-600 p-3 rounded-xl border border-blue-400/30 shadow-sm text-white flex flex-col justify-between min-h-[68px]">
                            <span className="text-[10px] font-bold text-blue-50 uppercase tracking-wider block leading-tight">Total Gain</span>
                            <h4 className="text-base font-extrabold text-white mt-1">+{formatCurrency(investLumpSumReturns)}</h4>
                          </div>

                          <div className="bg-gradient-to-br from-emerald-500 to-teal-600 p-3 rounded-xl border border-emerald-400/30 shadow-sm text-white flex flex-col justify-between min-h-[68px] col-span-1 md:col-span-2">
                            <div className="leading-tight">
                              <span className="text-[10px] font-bold text-emerald-50 uppercase tracking-wider block truncate">Net Surplus Wealth</span>
                              <span className="text-[9px] text-emerald-100 block mt-0.5">(vs Prepaying)</span>
                            </div>
                            <h4 className="text-base font-extrabold text-white mt-1">
                              {investLumpSumReturns - prepayInterestSaved >= 0 ? '+' : ''}
                              {formatCurrency(investLumpSumReturns - prepayInterestSaved)}
                            </h4>
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Creative Decision Matrix */}
                    <div className="bg-slate-900 text-white p-8 rounded-3xl relative overflow-hidden shadow-lg">
                      <div className="absolute right-0 top-0 w-80 h-80 bg-sky-500/10 rounded-full blur-3xl pointer-events-none" />
                      
                      <div className="max-w-2xl">
                        <span className="px-3 py-1 bg-sky-500/20 text-sky-400 border border-sky-500/30 rounded-full text-xs font-bold uppercase tracking-wider">
                          Strategic Advisor Recommendation
                        </span>
                        <h4 className="text-2xl font-bold mt-4 mb-2 tracking-tight">Direct Prepayment vs Investing: Which is better?</h4>
                        <p className="text-slate-300 text-sm leading-relaxed mb-6">
                          Making a prepayment instantly saves you guaranteed interest at the loan rate of <strong className="text-white">{interestRate}% p.a.</strong> By investing the same lump sum of <strong className="text-sky-400">{formatCurrency(lumpSumAmount)}</strong> at an expected mutual fund return rate of <strong className="text-blue-400">{investmentRate}% p.a.</strong>, you could achieve early closure even faster!
                        </p>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-4 border-t border-slate-800">
                        <div className="space-y-2">
                          <h5 className="font-semibold text-sky-400 flex items-center gap-1.5">
                            <Check className="w-5 h-5" /> Strategy A: Direct Prepayment
                          </h5>
                          <p className="text-xs text-slate-400 leading-relaxed">
                            Prepaying the loan immediately reduces your remaining tenure to <strong>{Math.floor(prepayNewTenureMonths / 12)} Years</strong>, saving a guaranteed <strong>{formatCurrency(prepayInterestSaved)}</strong> in total out-of-pocket interest. Perfect for risk-averse planners.
                          </p>
                        </div>
                        <div className="space-y-2">
                          <h5 className="font-semibold text-blue-400 flex items-center gap-1.5">
                            <TrendingUp className="w-5 h-5" /> Strategy B: Mutual Fund Investment
                          </h5>
                          <p className="text-xs text-slate-400 leading-relaxed">
                            Investing the total lump sum of <strong>{formatCurrency(lumpSumAmount)}</strong> at <strong>{investmentRate}% p.a.</strong> over <strong>{lumpSumTenureDesc}</strong> results in a final corpus of <strong>{formatCurrency(investLumpSumFutureValue)}</strong>. This yields a Net Surplus Wealth of <strong>{formatCurrency(investLumpSumReturns - prepayInterestSaved)}</strong> compared to prepaying!
                          </p>
                        </div>
                      </div>
                    </div>

                    {/* Bottom Download Banner */}
                    <div className="flex flex-col sm:flex-row items-center justify-between gap-4 p-6 bg-slate-50 rounded-2xl border border-slate-100 mt-6">
                      <div className="text-left">
                        <h4 className="font-bold text-slate-800 text-sm">Download Complete Comparative Report</h4>
                        <p className="text-xs text-slate-500">Get a fully unlocked premium Excel sheet containing side-by-side repayment calculations.</p>
                      </div>
                      <button
                        onClick={() => {
                          if (!isFormOpened) {
                            setIsFormModalOpen(true);
                          } else {
                            exportToExcel();
                          }
                        }}
                        className={`flex items-center gap-2 px-5 py-2.5 rounded-xl text-white font-bold text-sm shadow-md transition-all shrink-0 ${isFormOpened ? 'bg-sky-600 hover:bg-sky-700 shadow-sky-100' : 'bg-[#1E293B] hover:bg-slate-800 shadow-slate-100'}`}
                      >
                        <Download className="w-4 h-4" />
                        {isFormOpened ? 'Download Excel Sheet' : 'Fill Form & Download'}
                      </button>
                    </div>

                  </div>
                )}

                {activeTab === 'schedule' && (
                  <div className="bg-white rounded-2xl border border-slate-100 shadow-sm overflow-hidden flex flex-col">
                    <div className="p-5 border-b border-slate-100 bg-slate-50/50 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                      <div>
                        <h4 className="font-bold text-slate-800">Monthly Prepayment Schedule &amp; Calculator</h4>
                        <p className="text-xs text-slate-500 mt-0.5">Complete Amortization Schedule including original EMI and your manual deposits.</p>
                      </div>
                      
                      <div className="flex items-center gap-4 self-start sm:self-auto">
                        
                      </div>
                    </div>

                    <div className="overflow-x-auto overflow-y-auto max-h-[520px] border border-slate-100 rounded-xl custom-table-container" data-lenis-prevent="">
                      <table className="w-full text-left border-collapse text-sm relative">
                        <thead>
                          <tr className="bg-slate-900 text-slate-200 border-b border-slate-800 font-semibold sticky top-0 z-10 shadow-sm">
                            <th className="py-3 px-4 text-center bg-slate-900 sticky top-0 z-10">Month</th>
                            <th className="py-3 px-4 text-center bg-slate-900 sticky top-0 z-10">Year</th>
                            <th className="py-3 px-4 text-right bg-slate-900 sticky top-0 z-10">Beg. Balance</th>
                            <th className="py-3 px-4 text-right bg-slate-900 sticky top-0 z-10">EMI</th>
                            <th className="py-3 px-4 text-right bg-slate-900 sticky top-0 z-10">Deposit</th>
                            <th className="py-3 px-4 text-right bg-slate-900 sticky top-0 z-10">Principal</th>
                            <th className="py-3 px-4 text-right bg-slate-900 sticky top-0 z-10">Interest</th>
                            <th className="py-3 px-4 text-right bg-slate-900 sticky top-0 z-10">End Balance</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100">
                          {prepaySchedule.map((row, idx) => {
                            if (row.begAmount <= 0) return null; // Show whole amortization until paid off
                            
                            return (
                              <tr key={row.month} className={`hover:bg-slate-50/70 transition-colors ${idx % 2 === 0 ? 'bg-white' : 'bg-slate-50/20'}`}>
                                <td className="py-3 px-4 text-center font-medium text-slate-500">{row.month}</td>
                                <td className="py-3 px-4 text-center text-slate-500">Yr {row.year}</td>
                                <td className="py-3 px-4 text-right text-slate-700 font-medium">{formatCurrency(row.begAmount)}</td>
                                <td className="py-3 px-4 text-right text-slate-700">{formatCurrency(row.emi)}</td>
                                
                                <td className={`py-3 px-4 text-right font-medium ${row.addDeposit > 0 ? 'text-sky-600 bg-sky-50/30' : 'text-slate-400'}`}>
                                  {row.addDeposit > 0 ? formatCurrency(row.addDeposit) : '—'}
                                </td>
 
                                <td className="py-3 px-4 text-right text-slate-700">{formatCurrency(row.principal)}</td>
                                <td className="py-3 px-4 text-right text-slate-700">{formatCurrency(row.interest)}</td>
                                <td className="py-3 px-4 text-right text-slate-900 font-bold">{formatCurrency(row.endBalance)}</td>
                              </tr>
                            );
                          })}
                        </tbody>
                      </table>
                    </div>

                    {/* Bottom Download Banner */}
                    <div className="flex flex-col sm:flex-row items-center justify-between gap-4 p-6 bg-slate-50 rounded-b-2xl border-t border-slate-100">
                      <div className="text-left">
                        <h4 className="font-bold text-slate-800 text-sm">Download Premium Excel Sheet</h4>
                        <p className="text-xs text-slate-500">Includes the complete 240-month amortization schedule with dynamic formulas.</p>
                      </div>
                      <button
                        onClick={() => {
                          if (!isFormOpened) {
                            setIsFormModalOpen(true);
                          } else {
                            exportToExcel();
                          }
                        }}
                        className={`flex items-center gap-2 px-5 py-2.5 rounded-xl text-white font-bold text-sm shadow-md transition-all shrink-0 ${isFormOpened ? 'bg-sky-600 hover:bg-sky-700 shadow-sky-100' : 'bg-[#1E293B] hover:bg-slate-800 shadow-slate-100'}`}
                      >
                        <Download className="w-4 h-4" />
                        {isFormOpened ? 'Download Excel Sheet' : 'Fill Form & Download'}
                      </button>
                    </div>

                  </div>
                )}

                {activeTab === 'comparison' && (
                  <div className="space-y-8">
                    {/* Visual Progress comparisons */}
                    <div className="bg-white p-8 rounded-2xl border border-slate-100 shadow-sm space-y-6">
                      <h4 className="font-bold text-slate-800">Visual Summary: Prepayment Impact</h4>
                      
                      {/* Tenure blueuction visual progress bar */}
                      <div className="space-y-2">
                        <div className="flex justify-between items-center text-sm font-semibold">
                          <span className="text-slate-600">Loan Tenure Required</span>
                          <span className="text-sky-600">
                            {Math.floor(prepayNewTenureMonths / 12)} Years ({prepayNewTenureMonths} Mos) vs Original {loanTenureYears} Years
                          </span>
                        </div>
                        <div className="w-full bg-slate-100 rounded-full h-4 overflow-hidden relative">
                          <div 
                            className="bg-sky-500 h-full rounded-full transition-all duration-500"
                            style={{ width: `${(prepayNewTenureMonths / (loanTenureYears * 12)) * 100}%` }}
                          />
                        </div>
                        <div className="flex justify-between text-xs text-slate-400 font-medium">
                          <span>Month 1</span>
                          <span>Month {loanTenureYears * 12}</span>
                        </div>
                      </div>

                      {/* Cumulative Interest Paid Comparison */}
                      <div className="space-y-2 pt-4 border-t border-slate-100">
                        <div className="flex justify-between items-center text-sm font-semibold">
                          <span className="text-slate-600">Total Interest Paid</span>
                          <span className="text-blue-600">
                            {formatCurrency(prepayTotalInterest)} vs Original {formatCurrency(originalTotalInterest)}
                          </span>
                        </div>
                        <div className="w-full bg-slate-100 rounded-full h-4 overflow-hidden relative">
                          <div 
                            className="bg-blue-500 h-full rounded-full transition-all duration-500"
                            style={{ width: `${(prepayTotalInterest / originalTotalInterest) * 100}%` }}
                          />
                        </div>
                        <div className="flex justify-between text-xs text-slate-400 font-medium">
                          <span>₹0 Paid</span>
                          <span>Max Original {formatCurrency(originalTotalInterest)}</span>
                        </div>
                      </div>
                    </div>

                    {/* Side-by-Side Table Details */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      {/* Strategy A detail */}
                      <div className="bg-sky-50/40 p-6 rounded-2xl border border-sky-100">
                        <h4 className="font-bold text-sky-800 flex items-center gap-2 mb-4">
                          <Check className="w-5 h-5 text-sky-600" />
                          Strategy A Details
                        </h4>
                        <ul className="space-y-3 text-sm text-sky-950 font-medium">
                          <li className="flex justify-between py-1 border-b border-sky-100">
                            <span>Prepayment Amount:</span>
                            <span className="font-bold">{formatCurrency(lumpSumAmount)}</span>
                          </li>
                          <li className="flex justify-between py-1 border-b border-sky-100">
                            <span>Interest Saved:</span>
                            <span className="font-bold text-sky-600">{formatCurrency(prepayInterestSaved)}</span>
                          </li>
                          <li className="flex justify-between py-1 border-b border-sky-100">
                            <span>Effective New Tenure:</span>
                            <span className="font-bold">{Math.floor(prepayNewTenureMonths / 12)} Yrs {prepayNewTenureMonths % 12} Mos</span>
                          </li>
                          <li className="flex justify-between py-1 border-b border-sky-100">
                            <span>Total Out-of-pocket Costs:</span>
                            <span className="font-bold">{formatCurrency(loanAmount + prepayTotalInterest)}</span>
                          </li>
                        </ul>
                      </div>

                      {/* Strategy B detail */}
                      <div className="bg-blue-50/40 p-6 rounded-2xl border border-blue-100 shadow-sm">
                        <h4 className="font-bold text-blue-800 flex items-center gap-2 mb-4">
                          <TrendingUp className="w-5 h-5 text-blue-600" />
                          Strategy B Details (Investment Option)
                        </h4>
                        <ul className="space-y-3 text-sm text-blue-950 font-medium">
                          <li className="flex justify-between py-1 border-b border-blue-100">
                            <span>Lump Sum Invested:</span>
                            <span className="font-bold text-slate-800">{formatCurrency(lumpSumAmount)}</span>
                          </li>
                          <li className="flex justify-between py-1 border-b border-blue-100">
                            <span>Expected Growth Rate:</span>
                            <span className="font-bold text-slate-800">{investmentRate}% p.a.</span>
                          </li>
                          <li className="flex justify-between py-1 border-b border-blue-100">
                            <span>Lump Sum Return at {lumpSumTenureLabel}:</span>
                            <span className="font-bold text-blue-600">{formatCurrency(investLumpSumFutureValue)}</span>
                          </li>
                          <li className="flex justify-between py-1 border-b border-blue-100 text-slate-600">
                            <span>Growth Earned:</span>
                            <span className="font-bold">{formatCurrency(investLumpSumReturns)}</span>
                          </li>
                          <li className="flex justify-between py-2 border-b border-blue-100 text-blue-900 bg-blue-100/30 px-2 rounded-lg">
                            <span className="font-bold">NET SURPLUS WEALTH:</span>
                            <span className={`font-extrabold ${investLumpSumReturns - prepayInterestSaved >= 0 ? "text-sky-600" : "text-blue-600"}`}>
                              {formatCurrency(investLumpSumReturns - prepayInterestSaved)}
                            </span>
                          </li>
                        </ul>
                      </div>
                    </div>

                    {/* Bottom Download Banner */}
                    <div className="flex flex-col sm:flex-row items-center justify-between gap-4 p-6 bg-slate-50 rounded-2xl border border-slate-100 mt-6">
                      <div className="text-left">
                        <h4 className="font-bold text-slate-800 text-sm">Download Premium Excel Model</h4>
                        <p className="text-xs text-slate-500">Includes decision matrices, visual chart estimates, and detailed schedules.</p>
                      </div>
                      <button
                        onClick={() => {
                          if (!isFormOpened) {
                            setIsFormModalOpen(true);
                          } else {
                            exportToExcel();
                          }
                        }}
                        className={`flex items-center gap-2 px-5 py-2.5 rounded-xl text-white font-bold text-sm shadow-md transition-all shrink-0 ${isFormOpened ? 'bg-sky-600 hover:bg-sky-700 shadow-sky-100' : 'bg-[#1E293B] hover:bg-slate-800 shadow-slate-100'}`}
                      >
                        <Download className="w-4 h-4" />
                        {isFormOpened ? 'Download Excel Sheet' : 'Fill Form & Download'}
                      </button>
                    </div>

                  </div>
                )}

              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
