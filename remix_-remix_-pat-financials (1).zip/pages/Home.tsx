import React from 'react';
import { Hero } from '../components/Hero';
import { Stats } from '../components/Stats';
import { About } from '../components/About';
import { Services } from '../components/Services';
import { Process } from '../components/Process';
import { Philosophy } from '../components/Philosophy';
import { ReelsSection } from '../components/ReelsSection';
import { Resources } from '../components/Resources';
import { Videos } from '../components/Videos';
import { ValueProps } from '../components/ValueProps';
import { Testimonials } from '../components/Testimonials';
import { VideoTestimonials } from '../components/VideoTestimonials';
import { ContactCTA } from '../components/ContactCTA';
import { ScrollReveal } from '../components/ui/ScrollReveal';

export const Home: React.FC = () => {
  return (
    <>
      <Hero />
      <ScrollReveal><Stats /></ScrollReveal>
      <ScrollReveal><Testimonials /></ScrollReveal>
      <VideoTestimonials />
      <ScrollReveal><Resources /></ScrollReveal>
      <Services />
      <ScrollReveal><Videos /></ScrollReveal>
      <ValueProps />
      <ScrollReveal><ReelsSection /></ScrollReveal>
      <Process />
      <Philosophy />
      <ScrollReveal><About /></ScrollReveal>
      <ScrollReveal><ContactCTA /></ScrollReveal>
    </>
  );
};
