import React, { useState, useEffect } from 'react';
import { createPortal } from 'react-dom';
import { X, CheckSquare, Loader2, User, Phone, Mail, MapPin, Sparkles, CheckCircle2 } from 'lucide-react';
import { motion } from 'motion/react';

interface LeadFormModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmitAndDownload: () => void;
}

export const LeadFormModal: React.FC<LeadFormModalProps> = ({ isOpen, onClose, onSubmitAndDownload }) => {
  const [hasConfirmed, setHasConfirmed] = useState(() => {
    return typeof window !== 'undefined' && localStorage.getItem('pat_form_submitted') === 'true';
  });

  const [lastSubId, setLastSubId] = useState<string | null>(null);
  const [isChecking, setIsChecking] = useState(false);
  const [showNoSubmissionError, setShowNoSubmissionError] = useState(false);

  // Form Fields
  const [name, setName] = useState('');
  const [contact, setContact] = useState('');
  const [email, setEmail] = useState('');
  const [city, setCity] = useState('');

  const [errors, setErrors] = useState<{ name?: string; contact?: string }>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitSuccess, setSubmitSuccess] = useState(false);

  // Function to fetch the absolute latest submission ID for the specific form from Supabase
  const fetchLatestSubmissionId = async (): Promise<string | null> => {
    try {
      const response = await fetch(
        "https://shhilcjxcqtkifhikuvs.supabase.co/rest/v1/form_submissions?form_id=eq.f25eb511-6eff-4f89-9432-dd55988aeff8&order=submitted_at.desc&limit=1&select=id",
        {
          headers: {
            "apikey": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InNoaGlsY2p4Y3F0a2lmaGlrdXZzIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjQxMzk3MjAsImV4cCI6MjA3OTcxNTcyMH0.tJyUQyOxlMyuGv7XbG4R2Ue7lSX_5xLrpTkIno_CjbE",
            "Authorization": "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InNoaGlsY2p4Y3F0a2lmaGlrdXZzIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjQxMzk3MjAsImV4cCI6MjA3OTcxNTcyMH0.tJyUQyOxlMyuGv7XbG4R2Ue7lSX_5xLrpTkIno_CjbE"
          }
        }
      );
      if (!response.ok) return null;
      const data = await response.json();
      if (Array.isArray(data) && data.length > 0) {
        return data[0].id;
      }
    } catch (err) {
      console.error("Error checking Supabase submissions:", err);
    }
    return null;
  };

  // 1. Initial State Sync & Background Polling
  useEffect(() => {
    if (!isOpen || hasConfirmed) return;

    let isMounted = true;
    let intervalId: any;

    const setupSubmissionTracking = async () => {
      // 1. Fetch the absolute current latest submission ID as the baseline
      const initialId = await fetchLatestSubmissionId();
      if (!isMounted) return;

      const baselineId = initialId || 'none';
      setLastSubId(baselineId);

      // 2. Start checking every 3 seconds for any new submission
      intervalId = setInterval(async () => {
        const latestId = await fetchLatestSubmissionId();
        if (!isMounted) return;

        if (latestId && latestId !== baselineId) {
          // A new submission is detected!
          setHasConfirmed(true);
          localStorage.setItem('pat_form_submitted', 'true');
          clearInterval(intervalId);
        }
      }, 3000);
    };

    setupSubmissionTracking();

    return () => {
      isMounted = false;
      if (intervalId) clearInterval(intervalId);
    };
  }, [isOpen, hasConfirmed]);

  // Auto-trigger callback if already confirmed upon opening
  useEffect(() => {
    if (isOpen && hasConfirmed) {
      const timer = setTimeout(() => {
        onSubmitAndDownload();
      }, 1200);
      return () => clearTimeout(timer);
    }
  }, [isOpen, hasConfirmed, onSubmitAndDownload]);

  // 2. Message Event Fallback (in case postMessage is triggered)
  useEffect(() => {
    const handleMessage = (event: MessageEvent) => {
      try {
        let isSubmitted = false;
        if (event.data) {
          if (typeof event.data === 'string') {
            const dataLower = event.data.toLowerCase();
            if (dataLower.includes('submit') || dataLower.includes('success') || dataLower.includes('complete') || dataLower.includes('record')) {
              isSubmitted = true;
            }
          } else if (typeof event.data === 'object') {
            const strData = JSON.stringify(event.data).toLowerCase();
            if (
              event.data.type === 'FORM_SUBMITTED' || 
              event.data.event === 'form_submitted' ||
              strData.includes('submit') ||
              strData.includes('success') ||
              strData.includes('complete')
            ) {
              isSubmitted = true;
            }
          }
        }
        
        if (isSubmitted) {
          setHasConfirmed(true);
          localStorage.setItem('pat_form_submitted', 'true');
        }
      } catch (e) {
        console.error("Error processing form message:", e);
      }
    };
    window.addEventListener('message', handleMessage);
    return () => window.removeEventListener('message', handleMessage);
  }, []);

  // Manual Trigger to force instant verification check
  const handleManualVerify = async () => {
    if (isChecking) return;
    setIsChecking(true);
    setShowNoSubmissionError(false);

    const latestId = await fetchLatestSubmissionId();
    const baselineId = lastSubId || 'none';

    if (latestId && latestId !== baselineId) {
      setHasConfirmed(true);
      localStorage.setItem('pat_form_submitted', 'true');
    } else {
      setShowNoSubmissionError(true);
      // Automatically clear error after 4 seconds
      setTimeout(() => {
        setShowNoSubmissionError(false);
      }, 4000);
    }
    setIsChecking(false);
  };

  // Submission handler for native form
  const handleSubmitForm = async (e: React.FormEvent) => {
    e.preventDefault();
    const newErrors: { name?: string; contact?: string } = {};
    if (!name.trim()) {
      newErrors.name = 'Full Name is required';
    }
    const cleanPhone = contact.replace(/\D/g, '');
    if (!contact.trim()) {
      newErrors.contact = 'Contact Number is required';
    } else if (cleanPhone.length < 10) {
      newErrors.contact = 'Please enter a valid 10-digit mobile number';
    }

    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      return;
    }

    setErrors({});
    setIsSubmitting(true);

    try {
      // 1. Insert to form_submissions
      const subResponse = await fetch(
        "https://shhilcjxcqtkifhikuvs.supabase.co/rest/v1/form_submissions",
        {
          method: 'POST',
          headers: {
            "apikey": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InNoaGlsY2p4Y3F0a2lmaGlrdXZzIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjQxMzk3MjAsImV4cCI6MjA3OTcxNTcyMH0.tJyUQyOxlMyuGv7XbG4R2Ue7lSX_5xLrpTkIno_CjbE",
            "Authorization": "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InNoaGlsY2p4Y3F0a2lmaGlrdXZzIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjQxMzk3MjAsImV4cCI6MjA3OTcxNTcyMH0.tJyUQyOxlMyuGv7XbG4R2Ue7lSX_5xLrpTkIno_CjbE",
            "Content-Type": "application/json",
            "Prefer": "return=representation"
          },
          body: JSON.stringify({
            form_id: "f25eb511-6eff-4f89-9432-dd55988aeff8",
            status: "New"
          })
        }
      );

      if (!subResponse.ok) {
        throw new Error('Failed to create form submission');
      }

      const subData = await subResponse.json();
      const submissionId = Array.isArray(subData) ? subData[0]?.id : subData?.id;

      if (!submissionId) {
        throw new Error('Failed to retrieve submission ID');
      }

      // 2. Insert to form_answers
      const answersResponse = await fetch(
        "https://shhilcjxcqtkifhikuvs.supabase.co/rest/v1/form_answers",
        {
          method: 'POST',
          headers: {
            "apikey": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InNoaGlsY2p4Y3F0a2lmaGlrdXZzIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjQxMzk3MjAsImV4cCI6MjA3OTcxNTcyMH0.tJyUQyOxlMyuGv7XbG4R2Ue7lSX_5xLrpTkIno_CjbE",
            "Authorization": "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InNoaGlsY2p4Y3F0a2lmaGlrdXZzIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjQxMzk3MjAsImV4cCI6MjA3OTcxNTcyMH0.tJyUQyOxlMyuGv7XbG4R2Ue7lSX_5xLrpTkIno_CjbE",
            "Content-Type": "application/json"
          },
          body: JSON.stringify([
            {
              submission_id: submissionId,
              question_id: "6cc3da02-9b7c-4dac-8c4f-fec7a71a2991",
              answer_text: name.trim()
            },
            {
              submission_id: submissionId,
              question_id: "383eddaf-f206-4a6f-a736-063c2d402745",
              answer_text: cleanPhone
            }
          ])
        }
      );

      if (!answersResponse.ok) {
        throw new Error('Failed to submit form answers');
      }

      // 3. Auto-save as a client in Supabase Clients database
      try {
        await fetch(
          "https://shhilcjxcqtkifhikuvs.supabase.co/rest/v1/clients",
          {
            method: 'POST',
            headers: {
              "apikey": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InNoaGlsY2p4Y3F0a2lmaGlrdXZzIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjQxMzk3MjAsImV4cCI6MjA3OTcxNTcyMH0.tJyUQyOxlMyuGv7XbG4R2Ue7lSX_5xLrpTkIno_CjbE",
              "Authorization": "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InNoaGlsY2p4Y3F0a2lmaGlrdXZzIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjQxMzk3MjAsImV4cCI6MjA3OTcxNTcyMH0.tJyUQyOxlMyuGv7XbG4R2Ue7lSX_5xLrpTkIno_CjbE",
              "Content-Type": "application/json"
            },
            body: JSON.stringify({
              name: name.trim(),
              contact: cleanPhone,
              source: 'Calculator Verification Form',
              requirements: `Interested in calculators. Email: ${email.trim() || 'N/A'}, City: ${city.trim() || 'N/A'}`
            })
          }
        );
      } catch (err) {
        console.warn('Silent warning: Failed to auto-create client in CRM:', err);
      }

      setHasConfirmed(true);
      localStorage.setItem('pat_form_submitted', 'true');
      setSubmitSuccess(true);

      // Trigger automatic download and close modal after short delay
      setTimeout(() => {
        onSubmitAndDownload();
      }, 1500);

    } catch (err: any) {
      console.error(err);
      alert('Error submitting form: ' + err.message);
    } finally {
      setIsSubmitting(false);
    }
  };

  if (!isOpen) return null;

  return createPortal(
    <div className="fixed inset-0 z-[9999] flex items-center justify-center bg-slate-900/60 backdrop-blur-sm p-4">
      {/* Backdrop Close Click */}
      <div className="absolute inset-0" onClick={onClose} />

      <motion.div 
        initial={{ opacity: 0, scale: 0.95, y: 15 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 15 }}
        transition={{ duration: 0.2, ease: 'easeOut' }}
        className="relative w-full max-w-4xl h-[90vh] md:h-[85vh] bg-white rounded-2xl shadow-2xl flex flex-col overflow-hidden border border-slate-100 z-10"
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100 bg-slate-50">
          <div>
            <h3 className="text-lg font-bold text-slate-800">Complete Verification Form</h3>
            <p className="text-xs text-slate-500">Please fill out this quick form below. The system will automatically detect submission and enable your download.</p>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-full text-slate-400 hover:text-slate-600 hover:bg-slate-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Container */}
        <div className="flex-1 min-h-0 w-full bg-slate-50 overflow-y-auto">
          {submitSuccess || hasConfirmed ? (
            <div className="flex flex-col items-center justify-center text-center p-8 h-full space-y-4">
              <div className="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center animate-bounce">
                <CheckCircle2 className="w-10 h-10" />
              </div>
              <h4 className="text-2xl font-bold text-slate-800">Verification Successful!</h4>
              <p className="text-sm text-slate-500 max-w-md">
                Thank you for verifying your details. Your customized premium Excel download is starting automatically.
              </p>
              <div className="flex items-center gap-2 text-xs font-semibold text-emerald-600 bg-emerald-50 px-3 py-1.5 rounded-lg border border-emerald-100">
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping" />
                Preparing download...
              </div>
            </div>
          ) : (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-0 h-full">
              {/* Left Column: Why Verify Info (40%) */}
              <div className="lg:col-span-5 bg-gradient-to-br from-slate-900 via-[#1E293B] to-slate-900 text-white p-8 flex flex-col justify-between">
                <div className="space-y-6">
                  <div className="inline-flex items-center gap-2 px-3 py-1 bg-white/10 rounded-full text-xs font-medium text-sky-300">
                    <Sparkles className="w-3.5 h-3.5" />
                    Premium Access Enabled
                  </div>
                  
                  <div className="space-y-2">
                    <h4 className="text-xl font-bold tracking-tight">Unlock Professional Tools</h4>
                    <p className="text-xs text-slate-300 leading-relaxed">
                      Complete this quick contact verification once to permanently unlock premium spreadsheet downloads across all PAT Financials calculators.
                    </p>
                  </div>

                  <div className="space-y-4 pt-2">
                    <div className="flex gap-3">
                      <div className="w-5 h-5 bg-sky-500/20 text-sky-400 rounded-full flex items-center justify-center shrink-0 mt-0.5">
                        <CheckSquare className="w-3 h-3" />
                      </div>
                      <div>
                        <p className="text-xs font-semibold text-slate-100">Dynamic Excel Reports</p>
                        <p className="text-[11px] text-slate-400">Fully unlocked sheets containing real live formulas and comparison graphs.</p>
                      </div>
                    </div>

                    <div className="flex gap-3">
                      <div className="w-5 h-5 bg-sky-500/20 text-sky-400 rounded-full flex items-center justify-center shrink-0 mt-0.5">
                        <CheckSquare className="w-3 h-3" />
                      </div>
                      <div>
                        <p className="text-xs font-semibold text-slate-100">Side-by-Side Scenarios</p>
                        <p className="text-[11px] text-slate-400">Run multiple calculations matching your real home loans and investments.</p>
                      </div>
                    </div>

                    <div className="flex gap-3">
                      <div className="w-5 h-5 bg-sky-500/20 text-sky-400 rounded-full flex items-center justify-center shrink-0 mt-0.5">
                        <CheckSquare className="w-3 h-3" />
                      </div>
                      <div>
                        <p className="text-xs font-semibold text-slate-100">Expert Financial Plan Consultation</p>
                        <p className="text-[11px] text-slate-400">Receive a complimentary review call with our certified financial advisors.</p>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="text-[10px] text-slate-400 border-t border-slate-800 pt-4 mt-6">
                  🔒 Securely stored. PAT Financials is committed to protecting your privacy and security.
                </div>
              </div>

              {/* Right Column: Dynamic Form (60%) */}
              <form onSubmit={handleSubmitForm} className="lg:col-span-7 bg-white p-8 flex flex-col justify-center space-y-5 overflow-y-auto">
                <div className="space-y-1">
                  <h4 className="text-lg font-extrabold text-slate-800">Verification Details</h4>
                  <p className="text-xs text-slate-500">Provide your name and contact details to proceed with your premium download.</p>
                </div>

                <div className="space-y-4">
                  {/* Full Name */}
                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-slate-500 uppercase tracking-wider block">Full Name *</label>
                    <div className="relative">
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                        <User className="w-4 h-4" />
                      </div>
                      <input
                        type="text"
                        required
                        placeholder="Enter your full name"
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        className={`w-full pl-10 pr-4 py-2.5 bg-slate-50 border ${errors.name ? 'border-rose-300 focus:ring-rose-500/20 focus:border-rose-500' : 'border-slate-200 focus:ring-sky-500/20 focus:border-sky-500'} rounded-xl text-sm text-slate-800 focus:outline-none focus:ring-2 transition-all`}
                      />
                    </div>
                    {errors.name && (
                      <p className="text-[11px] font-medium text-rose-500 mt-1">{errors.name}</p>
                    )}
                  </div>

                  {/* Contact Number */}
                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-slate-500 uppercase tracking-wider block">Mobile Number *</label>
                    <div className="relative">
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                        <Phone className="w-4 h-4" />
                      </div>
                      <input
                        type="tel"
                        required
                        placeholder="Enter 10-digit phone number"
                        value={contact}
                        onChange={(e) => setContact(e.target.value)}
                        className={`w-full pl-10 pr-4 py-2.5 bg-slate-50 border ${errors.contact ? 'border-rose-300 focus:ring-rose-500/20 focus:border-rose-500' : 'border-slate-200 focus:ring-sky-500/20 focus:border-sky-500'} rounded-xl text-sm text-slate-800 focus:outline-none focus:ring-2 transition-all`}
                      />
                    </div>
                    {errors.contact && (
                      <p className="text-[11px] font-medium text-rose-500 mt-1">{errors.contact}</p>
                    )}
                  </div>

                  {/* Email (Optional) */}
                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-slate-500 uppercase tracking-wider block">Email Address (Optional)</label>
                    <div className="relative">
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                        <Mail className="w-4 h-4" />
                      </div>
                      <input
                        type="email"
                        placeholder="yourname@example.com"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        className="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm text-slate-800 focus:outline-none focus:ring-2 focus:ring-sky-500/20 focus:border-sky-500 transition-all"
                      />
                    </div>
                  </div>

                  {/* City (Optional) */}
                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-slate-500 uppercase tracking-wider block">City / Location (Optional)</label>
                    <div className="relative">
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                        <MapPin className="w-4 h-4" />
                      </div>
                      <input
                        type="text"
                        placeholder="e.g. Mumbai, Bengaluru"
                        value={city}
                        onChange={(e) => setCity(e.target.value)}
                        className="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm text-slate-800 focus:outline-none focus:ring-2 focus:ring-sky-500/20 focus:border-sky-500 transition-all"
                      />
                    </div>
                  </div>
                </div>

                <div className="pt-2">
                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="w-full bg-sky-600 hover:bg-sky-700 text-white font-bold text-sm py-3 px-4 rounded-xl shadow-lg shadow-sky-200 hover:shadow-xl hover:scale-[1.01] active:scale-[0.99] transition-all flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    {isSubmitting ? (
                      <>
                        <Loader2 className="w-4 h-4 animate-spin" />
                        Verifying details...
                      </>
                    ) : (
                      <>
                        <Sparkles className="w-4 h-4" /> Submit Details & Download
                      </>
                    )}
                  </button>
                </div>
              </form>
            </div>
          )}
        </div>

        {/* Footer actions */}
        <div className="px-6 py-4 border-t border-slate-100 bg-slate-50 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div className="flex items-center gap-3">
            {hasConfirmed ? (
              <div className="flex items-center gap-2 px-3 py-1.5 bg-emerald-50 border border-emerald-200 rounded-lg text-emerald-700 text-sm font-medium">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
                Form Submission Verified ✅
              </div>
            ) : (
              <div className="flex flex-col sm:flex-row sm:items-center gap-3">
                <div className="flex items-center gap-2 px-3 py-1.5 bg-amber-50 border border-amber-200 rounded-lg text-amber-700 text-sm font-medium">
                  <span className="w-2.5 h-2.5 rounded-full bg-amber-500 animate-pulse" />
                  Awaiting Form Submission
                </div>
                
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={handleManualVerify}
                    disabled={isChecking}
                    className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-sky-600 bg-sky-50 border border-sky-200 hover:bg-sky-100 active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed rounded-lg transition-all"
                  >
                    {isChecking ? (
                      <Loader2 className="w-3.5 h-3.5 animate-spin" />
                    ) : null}
                    Verify Submission Status
                  </button>
                  
                  {showNoSubmissionError && (
                    <span className="text-xs text-rose-600 animate-pulse">
                      No new response detected yet.
                    </span>
                  )}
                </div>
              </div>
            )}
          </div>
          <div className="flex items-center gap-3 self-end sm:self-auto">
            <button
              onClick={onClose}
              className="px-4 py-2 text-sm font-semibold text-slate-600 hover:text-slate-800 bg-white border border-slate-200 rounded-xl hover:bg-slate-50 transition-all active:scale-95"
            >
              Cancel
            </button>
            <button
              onClick={onSubmitAndDownload}
              disabled={!hasConfirmed}
              className={`flex items-center justify-center gap-2 px-6 py-2 text-white text-sm font-bold rounded-xl transition-all ${
                hasConfirmed 
                  ? 'bg-sky-600 hover:bg-sky-700 shadow-md shadow-sky-200 hover:scale-[1.02] active:scale-[0.98]' 
                  : 'bg-slate-300 cursor-not-allowed opacity-60'
              }`}
            >
              <CheckSquare className="w-4 h-4" /> Download Excel
            </button>
          </div>
        </div>
      </motion.div>
    </div>,
    document.body
  );
};


