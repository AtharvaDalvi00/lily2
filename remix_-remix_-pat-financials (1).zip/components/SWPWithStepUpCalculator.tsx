import React, { useState, useEffect } from 'react';
import { X, Calculator, Download, RefreshCw } from 'lucide-react';
import * as XLSX from 'xlsx';
import { LeadFormModal } from './LeadFormModal';

interface CalculationRow {
  year: number;
  monthly: number;
  annualRegular: number;
  additional: number;
  balanceBeforeInterest: number;
  closingBalance: number;
}

interface SWPWithStepUpCalculatorProps {
  isOpen: boolean;
  onClose: () => void;
}

export const SWPWithStepUpCalculator: React.FC<SWPWithStepUpCalculatorProps> = ({ isOpen, onClose }) => {
  const [corpus, setCorpus] = useState(11000000);
  const [monthlyWithdrawal, setMonthlyWithdrawal] = useState(50000);
  const [stepUp, setStepUp] = useState(6);
  const [duration, setDuration] = useState(30);
  const [rate, setRate] = useState(12);
  const [additionalWithdrawals, setAdditionalWithdrawals] = useState<{[key: number]: number}>({});
  const [results, setResults] = useState<CalculationRow[]>([]);
  const [isFormOpened, setIsFormOpened] = useState(false);
  const [isFormModalOpen, setIsFormModalOpen] = useState(false);
  const formURL = "https://task-flow-pro-23-01.vercel.app/#/p/b8241986-9abe-4e33-974b-63f48dfcf893";

  const calculate = () => {
    let currentCorpus = corpus;
    let currentMonthly = monthlyWithdrawal;
    const newResults: CalculationRow[] = [];

    for (let year = 1; year <= duration; year++) {
      const annualRegular = currentMonthly * 12;
      const additional = additionalWithdrawals[year] || 0;
      
      let balanceBeforeInterest = currentCorpus - annualRegular - additional;
      if (balanceBeforeInterest < 0) balanceBeforeInterest = 0; // Prevent negative balance for interest calculation

      const interest = balanceBeforeInterest * (rate / 100);
      const closingBalance = balanceBeforeInterest + interest;

      newResults.push({
        year,
        monthly: Math.round(currentMonthly),
        annualRegular: Math.round(annualRegular),
        additional,
        balanceBeforeInterest: Math.round(balanceBeforeInterest),
        closingBalance: Math.round(closingBalance)
      });

      currentCorpus = closingBalance;
      currentMonthly = currentMonthly * (1 + stepUp / 100);
    }
    setResults(newResults);
  };

  useEffect(() => {
    if (isOpen) calculate();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [corpus, monthlyWithdrawal, stepUp, duration, rate, additionalWithdrawals, isOpen]);

  const handleAdditionalChange = (year: number, value: string) => {
    const val = parseInt(value) || 0;
    setAdditionalWithdrawals(prev => ({ ...prev, [year]: val }));
  };

  const formatNumber = (val: number) => {
    return new Intl.NumberFormat('en-IN', {
      maximumFractionDigits: 2
    }).format(val);
  };

  const formatCurrency = (val: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0
    }).format(val);
  };

  const downloadCSV = () => {
    const totalWithdrawn = results.reduce((acc, r) => acc + r.annualRegular + r.additional, 0);
    const finalCorpus = Math.max(0, results[results.length - 1]?.closingBalance || 0);

    const htmlContent = `
<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40">
<head>
<!--[if gte mso 9]>
<xml>
<x:ExcelWorkbook>
<x:ExcelWorksheets>
<x:ExcelWorksheet>
<x:Name>SWP Step Up Plan</x:Name>
<x:WorksheetOptions>
<x:DisplayGridlines/>
<x:ProtectContents>True</x:ProtectContents>
</x:WorksheetOptions>
</x:ExcelWorksheet>
</x:ExcelWorksheets>
</x:ExcelWorkbook>
</xml>
<![endif]-->
<meta charset="utf-8">
<style>
  table { border-collapse: collapse; font-family: 'Segoe UI', Arial, sans-serif; }
  th, td { border: 1px solid #CBD5E1; padding: 10px; font-size: 11pt; mso-protection: locked hidden; }
  
  .title-cell { font-size: 16pt; font-weight: bold; color: #FFFFFF; background-color: #0284C7; padding: 15px; border: none; text-align: center; mso-protection: locked hidden; }
  
  .section-header { background-color: #0EA5E9; color: #FFFFFF; font-weight: bold; font-size: 12pt; text-align: left; padding: 10px; mso-protection: locked hidden; }
  .grid-header { background-color: #1E293B; color: #FFFFFF; font-weight: bold; font-size: 11pt; text-align: center; mso-protection: locked hidden; }
  
  .label-cell { color: #334155; font-weight: 500; background-color: #F8FAFC; mso-protection: locked hidden; }
  .value-cell { text-align: right; font-weight: bold; color: #020617; mso-protection: locked hidden; }
  .input-cell { text-align: right; font-weight: bold; color: #020617; background-color: #FFFFD0; mso-protection: unlocked; border: 1px solid #94A3B8; }
  
  .result-label { font-weight: bold; color: #0369A1; background-color: #F0F9FF; border: 1px solid #BAE6FD; mso-protection: locked hidden; }
  .result-value { font-weight: bold; color: #0369A1; background-color: #E0F2FE; text-align: right; border: 1px solid #BAE6FD; mso-protection: locked hidden; }
  
  .schedule-row-even { background-color: #F8FAFC; }
  .schedule-row-odd { background-color: #FFFFFF; }
  
  .currency-cell { text-align: right; mso-protection: locked hidden; }
  .center-cell { text-align: center; mso-protection: locked hidden; }
  .empty-cell { background-color: #FFFFFF; border: none; mso-protection: locked hidden; }
</style>
</head>
<body>
  <table>
    <tr>
      <td class="title-cell" colspan="6">PAT FINANCIALS - SWP WITH STEP-UP PLANNER REPORT</td>
    </tr>
    <tr><td colspan="6" style="border: none; height: 10px;"></td></tr>

    <tr><td class="section-header" colspan="6">INPUTS &amp; ASSUMPTIONS</td></tr>
    <tr>
      <td class="label-cell" colspan="2">Initial Corpus</td>
      <td class="input-cell" colspan="1">${corpus}</td>
      <td class="empty-cell" style="border: none;"></td>
      <td class="label-cell" colspan="1">Expected Return</td>
      <td class="input-cell" colspan="1">${rate}</td>
    </tr>
    <tr>
      <td class="label-cell" colspan="2">First Year Monthly Withdrawal</td>
      <td class="input-cell" colspan="1">${monthlyWithdrawal}</td>
      <td class="empty-cell" style="border: none;"></td>
      <td class="label-cell" colspan="1">Annual Step-Up</td>
      <td class="input-cell" colspan="1">${stepUp}</td>
    </tr>
    <tr>
      <td class="label-cell" colspan="2">Duration (Years)</td>
      <td class="input-cell" colspan="1">${duration}</td>
      <td class="empty-cell" style="border: none;" colspan="3"></td>
    </tr>

    <tr><td colspan="6" style="border: none; height: 15px;"></td></tr>

    <tr><td class="section-header" colspan="6">PLAN SUMMARY OUTCOMES (LIVE FORMULAS)</td></tr>
    <tr>
      <td class="result-label" colspan="3">Total Amount Withdrawn</td>
      <td class="result-value" colspan="3">=SUM(C14:C${13 + results.length}) + SUM(D14:D${13 + results.length})</td>
    </tr>
    <tr>
      <td class="result-label" colspan="3">Final Corpus Value</td>
      <td class="result-value" colspan="3">=F${13 + results.length}</td>
    </tr>

    <tr><td colspan="6" style="border: none; height: 15px;"></td></tr>

    <tr><td class="section-header" colspan="6">ANNUAL WITHDRAWAL &amp; CORPUS BALANCE SCHEDULE</td></tr>
    <tr>
      <td class="grid-header">YEAR</td>
      <td class="grid-header">MONTHLY SWP</td>
      <td class="grid-header">ANNUAL SWP</td>
      <td class="grid-header">ADDITIONAL W/D</td>
      <td class="grid-header">BAL. BEFORE INTEREST</td>
      <td class="grid-header">CLOSING BALANCE</td>
    </tr>
    ${results.map((row, idx) => {
      const rowClass = idx % 2 === 0 ? 'schedule-row-even' : 'schedule-row-odd';
      const r = 14 + idx; // Excel row index
      const monthlyFormula = idx === 0 ? '=$C$5' : `=B${r - 1}*(1+$F$5/100)`;
      const prevClosingFormula = idx === 0 ? '$C$4' : `F${r - 1}`;
      return `
      <tr class="${rowClass}">
        <td class="center-cell" style="font-weight: bold;">Year ${row.year}</td>
        <td class="currency-cell">${monthlyFormula}</td>
        <td class="currency-cell">=B${r}*12</td>
        <td class="currency-cell" style="color: #0284C7;">${row.additional}</td>
        <td class="currency-cell">=MAX(0, ${prevClosingFormula}-C${r}-D${r})</td>
        <td class="currency-cell" style="font-weight: bold; color: #0284C7;">=IF(E${r}>0, ROUND(E${r}*(1+$F$4/100), 0), 0)</td>
      </tr>
      `;
    }).join('')}
  </table>
</body>
</html>
`;

    const blob = new Blob([htmlContent], { type: 'application/vnd.ms-excel;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `swp_step_up_report_${new Date().toISOString().split('T')[0]}.xls`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 sm:p-6">
      <div className="absolute inset-0 bg-brand-dark/80 backdrop-blur-sm pointer-events-auto" onClick={onClose} />
      
      <div className="relative bg-white w-full max-w-6xl rounded-2xl shadow-2xl max-h-full sm:max-h-[90vh] flex flex-col overflow-hidden">
        {/* Header */}
        <div className="flex flex-wrap items-center justify-between p-6 bg-brand-primary text-white border-b border-white/20 gap-4 shrink-0">
          <div className="flex items-center gap-3">
            <div className="bg-white/20 p-2.5 rounded-xl">
              <Calculator className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-xl font-bold tracking-tight">SWP with Step-Up Planner</h2>
              <p className="text-xs text-blue-100">Plan your retirement withdrawals combating inflation</p>
            </div>
          </div>
          <div className="flex items-center gap-3 ml-auto">
            <button
              onClick={() => {
                if (!isFormOpened) {
                  setIsFormModalOpen(true);
                } else {
                  downloadCSV();
                }
              }}
              className={`flex items-center gap-2 ${isFormOpened ? 'bg-sky-600 hover:bg-sky-700' : 'bg-[#3B82F6] hover:bg-[#1D4ED8]'} text-white px-4 py-2 rounded-xl transition-colors font-semibold text-sm shadow-sm`}
            >
              <Download className="w-4 h-4" />
              {isFormOpened ? 'Download Excel Sheet' : 'Fill Form & Download'}
            </button>
            <LeadFormModal
              isOpen={isFormModalOpen}
              onClose={() => setIsFormModalOpen(false)}
              onSubmitAndDownload={() => {
                setIsFormOpened(true);
                setIsFormModalOpen(false);
                downloadCSV();
              }}
            />
            <button onClick={onClose} className="p-2.5 bg-white/10 hover:bg-white/20 rounded-xl transition-colors text-white">
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>
        <div className="flex flex-col lg:flex-row flex-1 overflow-hidden min-h-0">
        {/* Inputs Panel */}
           <div data-lenis-prevent="true" className="w-full lg:w-1/3 p-6 bg-slate-50 border-r border-slate-200 overflow-y-auto">
              <div className="space-y-6">
                 <div>
                    <label className="block text-sm font-semibold text-slate-700 mb-2">Initial Corpus (₹)</label>
                    <input 
                      type="number" 
                      value={corpus || ''} 
                      onChange={(e) => setCorpus(Number(e.target.value))}
                      className="w-full p-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-sky-500 focus:border-transparent"
                    />
                    <input type="range" min="100000" max="100000000" step="100000" value={corpus} onChange={(e)=>setCorpus(Number(e.target.value))} className="w-full mt-2 accent-sky-600"/>
                 </div>

                 <div>
                    <label className="block text-sm font-semibold text-slate-700 mb-2">First Year Monthly Withdrawal (₹)</label>
                    <input 
                      type="number" 
                      value={monthlyWithdrawal || ''} 
                      onChange={(e) => setMonthlyWithdrawal(Number(e.target.value))}
                      className="w-full p-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-sky-500 focus:border-transparent"
                    />
                    <input type="range" min="1000" max="500000" step="1000" value={monthlyWithdrawal} onChange={(e)=>setMonthlyWithdrawal(Number(e.target.value))} className="w-full mt-2 accent-sky-600"/>
                 </div>

                 <div>
                    <label className="block text-sm font-semibold text-slate-700 mb-2">Annual Step-Up (%)</label>
                    <input 
                      type="number" 
                      value={stepUp || ''} 
                      onChange={(e) => setStepUp(Number(e.target.value))}
                      className="w-full p-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-sky-500 focus:border-transparent"
                    />
                    <input type="range" min="0" max="20" step="1" value={stepUp} onChange={(e)=>setStepUp(Number(e.target.value))} className="w-full mt-2 accent-sky-600"/>
                 </div>

                 <div>
                    <label className="block text-sm font-semibold text-slate-700 mb-2">Expected Return (% p.a)</label>
                    <input 
                      type="number" 
                      value={rate || ''} 
                      onChange={(e) => setRate(Number(e.target.value))}
                      className="w-full p-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-sky-500 focus:border-transparent"
                    />
                    <input type="range" min="1" max="20" step="0.5" value={rate} onChange={(e)=>setRate(Number(e.target.value))} className="w-full mt-2 accent-sky-600"/>
                 </div>

                 <div>
                    <label className="block text-sm font-semibold text-slate-700 mb-2">Duration (Years)</label>
                    <input 
                      type="number" 
                      value={duration || ''} 
                      onChange={(e) => setDuration(Number(e.target.value))}
                      className="w-full p-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-sky-500 focus:border-transparent"
                    />
                    <input type="range" min="1" max="60" step="1" value={duration} onChange={(e)=>setDuration(Number(e.target.value))} className="w-full mt-2 accent-sky-600"/>
                 </div>
                 
                 <div className="pt-4 border-t border-slate-200">
                   <p className="text-xs text-slate-500 text-center">Add custom ad-hoc withdrawals (e.g., for vacations, medical expenses) in the highlighted column on the right.</p>
                 </div>
              </div>
           </div>

           {/* Results Panel */}
           <div className="w-full lg:w-2/3 flex flex-col bg-white">
              <div className="p-6 grid grid-cols-2 gap-4 bg-sky-50/50 border-b border-slate-100">
                 <div>
                    <p className="text-sm text-slate-500">Total Amount Withdrawn</p>
                    <p className="text-2xl font-bold text-slate-800">
                      {results.length > 0 && formatCurrency(results.reduce((acc, r) => acc + r.annualRegular + r.additional, 0))}
                    </p>
                 </div>
                 <div>
                    <p className="text-sm text-slate-500">Final Corpus Value</p>
                    <p className="text-2xl font-bold text-sky-600">{results.length > 0 && formatCurrency(Math.max(0, results[results.length-1].closingBalance))}</p>
                 </div>
              </div>

              <div data-lenis-prevent="true" className="flex-1 overflow-auto">
                 <table className="w-full text-left border-collapse">
                    <thead className="bg-slate-100 sticky top-0 z-10">
                       <tr>
                          <th className="p-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Year</th>
                          <th className="p-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Monthly SWP</th>
                          <th className="p-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Annual SWP</th>
                          <th className="p-4 text-xs font-bold text-slate-500 uppercase tracking-wider bg-blue-50 w-32 border-l border-blue-100">Addn. W/D</th>
                          <th className="p-4 text-xs font-bold text-slate-500 uppercase tracking-wider border-l border-slate-200">Ending Balance</th>
                       </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                       {results.map((row) => (
                          <tr key={row.year} className={`transition-colors ${row.closingBalance <= 0 ? 'bg-blue-50/50' : 'hover:bg-slate-50'}`}>
                             <td className="p-4 text-sm font-medium text-slate-900">{row.year}</td>
                             <td className="p-4 text-sm text-slate-600">{formatCurrency(row.monthly)}</td>
                             <td className="p-4 text-sm font-medium text-slate-800">{formatCurrency(row.annualRegular)}</td>
                             <td className="p-2 bg-blue-50/30 border-l border-blue-100">
                                <input 
                                  type="number" 
                                  placeholder="0"
                                  value={additionalWithdrawals[row.year] || ''}
                                  onChange={(e) => handleAdditionalChange(row.year, e.target.value)}
                                  className="w-full p-2 text-sm border border-blue-200 rounded focus:ring-1 focus:ring-blue-400 focus:border-blue-400 bg-white"
                                />
                             </td>
                             <td className={`p-4 text-sm font-bold border-l border-slate-100 ${row.closingBalance <= 0 ? 'text-blue-600' : 'text-sky-600'}`}>
                               {formatCurrency(Math.max(0, row.closingBalance))}
                               {row.closingBalance <= 0 && <span className="ml-2 text-xs font-normal text-blue-500">(Corpus Depleted)</span>}
                             </td>
                          </tr>
                       ))}
                    </tbody>
                 </table>
              </div>
              <div className="p-4 border-t border-slate-100 flex justify-end gap-3 bg-white">
                 <button onClick={()=>setAdditionalWithdrawals({})} className="flex items-center gap-2 px-4 py-2 text-sm font-medium text-slate-600 hover:text-sky-600">
                    <RefreshCw className="w-4 h-4" /> Reset Additional
                 </button>
                 <button 
                    onClick={() => {
                       if (!isFormOpened) {
                         setIsFormModalOpen(true);
                       } else {
                         downloadCSV();
                       }
                    }}
                    className={`flex items-center gap-2 px-4 py-2 ${isFormOpened ? 'bg-sky-600' : 'bg-brand-dark'} text-white text-sm font-semibold rounded-lg hover:bg-slate-800 transition-colors`}
                 >
                    <Download className="w-4 h-4" /> {isFormOpened ? 'Download Excel Sheet' : 'Fill Form & Download'}
                 </button>
                 <LeadFormModal 
                    isOpen={isFormModalOpen}
                    onClose={() => setIsFormModalOpen(false)}
                    onSubmitAndDownload={() => {
                       setIsFormOpened(true);
                       setIsFormModalOpen(false);
                       downloadCSV();
                    }}
                 />
              </div>
           </div>
        </div>
      </div>
    </div>
  );
};
