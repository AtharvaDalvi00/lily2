import React, { useEffect } from 'react';
import { ScrollReveal } from '../components/ui/ScrollReveal';
import { Link } from 'react-router-dom';
import { Target, Search, BarChart3, Fingerprint, Activity, Scale, ArrowLeft } from 'lucide-react';
import { ContactCTA } from '../components/ContactCTA';

export const RiskProfilingDetails: React.FC = () => {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  return (
    <>
      <ScrollReveal>
      <section className="py-20 bg-brand-light relative overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img src="https://images.unsplash.com/photo-1633158829585-23ba8f7c8caf?w=1600&q=80" alt="Background" className="w-full h-full object-cover opacity-[0.06] mix-blend-multiply" />
        </div>
        <div className="absolute top-0 right-0 w-64 h-64 bg-brand-primary/10 rounded-full blur-3xl"></div>
        <div className="absolute bottom-0 left-0 w-64 h-64 bg-brand-secondary/10 rounded-full blur-3xl"></div>
        
        <div className="container mx-auto px-4 md:px-6 relative z-10 text-center max-w-4xl pt-16">
          
          <Link to="/" className="inline-flex items-center gap-2 px-4 py-2 bg-white/50 hover:bg-white text-brand-primary font-medium rounded-full mb-8 backdrop-blur-sm border border-slate-200/50 hover:border-brand-primary/30 transition-all shadow-sm hover:shadow-md group">
            <ArrowLeft className="w-4 h-4 group-hover:-translate-x-1 transition-transform" /> Back to Home
          </Link>
          <h1 className="text-5xl md:text-6xl font-display font-bold text-brand-dark mb-6">Risk Profiling</h1>
          <p className="text-xl text-slate-600 mb-8 leading-relaxed">
            Understanding your appetite to tailor the perfect plan. We ensure your portfolio lets you sleep peacefully at night while working hard during the day.
          </p>
        </div>
      </section>
      </ScrollReveal>

      <ScrollReveal>
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4 md:px-6 max-w-4xl">
          <div className="pred pred-lg pred-slate max-w-none text-slate-600 space-y-6">
            <h2 className="text-3xl font-display font-bold text-brand-dark">Why is Risk Profiling the Foundation?</h2>
            <p>
              Investing without understanding your risk profile is like navigating a ship blindfolded. The "best" investment for one person might be a nightmare for another. Risk profiling is the scientific and psychological assessment of how much volatility you can withstand, ensuring we never cross the line between healthy growth and painful anxiety.
            </p>
            
            <h3 className="text-2xl font-display font-bold text-brand-dark mt-12 mb-4">Our Approach</h3>
            
            <div className="grid md:grid-cols-3 gap-8 my-8">
              <div className="bg-slate-50 p-6 rounded-2xl border border-slate-100 shadow-sm">
                <Fingerprint className="w-10 h-10 text-brand-primary mb-4" />
                <h4 className="text-lg font-bold text-brand-dark mb-2">Psychological Tolerance</h4>
                <p className="text-sm">Through structured questionnaires and conversations, we gauge your emotional reaction to market downturns and temporary losses.</p>
              </div>
              
              <div className="bg-slate-50 p-6 rounded-2xl border border-slate-100 shadow-sm">
                <Activity className="w-10 h-10 text-brand-primary mb-4" />
                <h4 className="text-lg font-bold text-brand-dark mb-2">Financial Capacity</h4>
                <p className="text-sm">We objectively assess your ability to take risks based on your age, income stability, liabilities, and investment horizon.</p>
              </div>
              
              <div className="bg-slate-50 p-6 rounded-2xl border border-slate-100 shadow-sm">
                <Scale className="w-10 h-10 text-brand-primary mb-4" />
                <h4 className="text-lg font-bold text-brand-dark mb-2">Alignment</h4>
                <p className="text-sm">We bridge the gap between the risk you *need* to take to achieve your goals and the risk you are *comfortable* taking.</p>
              </div>
            </div>

            <h3 className="text-2xl font-display font-bold text-brand-dark mt-12 mb-4">The Result</h3>
            <p>
              A tailor-made investment mandate. When markets invariably correct, you remain steadfast and grounded, because your portfolio was built distinctly around your unique emotional and financial boundaries.
            </p>
          </div>
        </div>
      </section>
      </ScrollReveal>
      
      <ContactCTA />
    </>
  );
};
