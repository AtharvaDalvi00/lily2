import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { TrendingUp, ArrowRightLeft, Landmark, Calculator, ArrowRight, Sparkles, FileSpreadsheet, Zap, HeartHandshake } from 'lucide-react';
import { StepUpSIPCalculator } from '../components/StepUpSIPCalculator';
import { SIPSWPCalculator } from '../components/SIPSWPCalculator';
import { SWPWithStepUpCalculator } from '../components/SWPWithStepUpCalculator';
import { AmortizationScheduleCalculator } from '../components/AmortizationScheduleCalculator';
import { LumpSumCalculator } from '../components/LumpSumCalculator';
import { QuickCalculationsCalculator } from '../components/QuickCalculationsCalculator';
import { RetirementCalculator } from '../components/RetirementCalculator';
import { TenureIncreaseCalculator } from '../components/TenureIncreaseCalculator';
import { EarlyLoanClosureLumpSumCalculator } from '../components/EarlyLoanClosureLumpSumCalculator';
import { PropertyCapitalGainsCalculator } from '../components/PropertyCapitalGainsCalculator';

const calculators = [
  {
    id: 'retirement-calc',
    name: 'Retirement Calculator',
    description: 'Plan your retirement corpus, life expectancy analysis, and required investments.',
    icon: HeartHandshake,
    color: 'from-blue-500 to-blue-600',
    bgColor: 'bg-blue-50',
    iconColor: 'text-blue-600',
  },
  {
    id: 'sip-swp',
    name: 'SIP & SWP Calculator',
    description: 'Plan your wealth accumulation and withdrawal phases seamlessly.',
    icon: ArrowRightLeft,
    color: 'from-sky-500 to-sky-600',
    bgColor: 'bg-sky-50',
    iconColor: 'text-sky-600',
  },
  {
    id: 'swp-step-up',
    name: 'SWP with Step Up',
    description: 'Manage systematic withdrawals with an annual step-up to combat inflation.',
    icon: Landmark,
    color: 'from-blue-500 to-blue-600',
    bgColor: 'bg-blue-50',
    iconColor: 'text-blue-600',
  },
  {
    id: 'amortization',
    name: 'EMI Calculator',
    description: 'Calculate your loan EMI, track balance and interest payments, and simulate prepayments.',
    icon: FileSpreadsheet,
    color: 'from-blue-500 to-sky-600',
    bgColor: 'bg-blue-50',
    iconColor: 'text-blue-600',
  },
  {
    id: 'step-up',
    name: 'Step Up SIP Calculator',
    description: 'Grow your wealth with increasing monthly contributions to beat inflation.',
    icon: TrendingUp,
    color: 'from-blue-500 to-blue-600',
    bgColor: 'bg-blue-50',
    iconColor: 'text-blue-600',
  },
  {
    id: 'lump-sum',
    name: 'LumpSum Calculator',
    description: 'Calculate the potential growth of your one-time investments.',
    icon: Calculator,
    color: 'from-blue-500 to-blue-600',
    bgColor: 'bg-blue-50',
    iconColor: 'text-blue-600',
  },
  {
    id: 'tenure-increase',
    name: 'Early Loan Closure',
    description: 'Build immense passive wealth by increasing loan tenure and investing the EMI savings.',
    icon: Landmark,
    color: 'from-sky-500 to-sky-600',
    bgColor: 'bg-sky-50',
    iconColor: 'text-sky-600',
  },
  {
    id: 'early-closure-lumpsum',
    name: 'Early Loan Closure - Lump Sum',
    description: 'Calculate interest savings and early payoff options with lump sum prepayments.',
    icon: Calculator,
    color: 'from-blue-500 to-blue-600',
    bgColor: 'bg-blue-50',
    iconColor: 'text-blue-600',
  },
  {
    id: 'quick-calculations',
    name: 'Quick Calci',
    description: 'Instant answers for your SIP and Lump Sum future values, required years, rates, and amounts.',
    icon: Zap,
    color: 'from-sky-500 to-sky-600',
    bgColor: 'bg-sky-50',
    iconColor: 'text-sky-600',
  },
  {
    id: 'property-gains',
    name: 'Property Capital Gains',
    description: 'Compare 12.5% flat tax vs 20% indexed tax, and optimize reinvestment under Section 54EC.',
    icon: Landmark,
    color: 'from-blue-600 to-emerald-600',
    bgColor: 'bg-emerald-50',
    iconColor: 'text-emerald-600',
  }
];

export const CalculatorsPage: React.FC = () => {
  const [activeCalculator, setActiveCalculator] = useState<string | null>(null);

  useEffect(() => {
    if (activeCalculator) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'auto'; // or 'unset'
    }
    return () => {
      document.body.style.overflow = 'auto';
    };
  }, [activeCalculator]);

  return (
    <div className="min-h-screen pt-32 pb-24 overflow-hidden relative bg-[#FAFAFA]">
      {/* Abstract Background Elements */}
      <div className="absolute top-0 left-0 w-full h-[500px] overflow-hidden -z-10 pointer-events-none">
        <div className="absolute -top-[10%] -left-[10%] w-[50%] h-[500px] bg-brand-primary/10 rounded-full blur-[120px]" />
        <div className="absolute top-[20%] -right-[10%] w-[50%] h-[600px] bg-brand-secondary/10 rounded-full blur-[120px]" />
      </div>

      <div className="container mx-auto px-4 md:px-6 relative z-10">
        {/* Header Section */}
        <div className="max-w-3xl mx-auto text-center mb-20">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, ease: "easeOut" }}
          >
            <div className="inline-flex items-center justify-center p-4 bg-white shadow-xl shadow-brand-primary/10 rounded-2xl text-brand-primary mb-8 ring-1 ring-gray-100">
              <Calculator className="w-8 h-8" />
            </div>
            <h1 className="text-4xl md:text-6xl font-display font-bold text-slate-900 mb-6 tracking-tight">
              Financial <span className="text-transparent bg-clip-text bg-gradient-to-r from-brand-primary to-brand-secondary">Toolkit</span>
            </h1>
            <p className="text-lg md:text-xl text-slate-600 max-w-2xl mx-auto leading-relaxed">
              Empower your financial decisions. Use our suite of advanced calculators to visualize your wealth creation journey and plan for a secure future.
            </p>
          </motion.div>
        </div>

        {/* Calculator Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 max-w-7xl mx-auto">
          {calculators.map((calc, index) => {
            const Icon = calc.icon;
            return (
              <div key={calc.id} className="[perspective:1000px] h-full"> 
                <motion.div
                  initial={{ opacity: 0, y: 40, scale: 0.95 }}
                  animate={{ opacity: 1, y: 0, scale: 1 }}
                  whileHover={{ 
                    scale: 1.05, 
                    rotateY: 5, 
                    rotateX: -5,
                    boxShadow: "0 25px 50px -12px rgba(0, 0, 0, 0.25)"
                  }}
                  whileTap={{ scale: 0.98 }}
                  transition={{ 
                    duration: 0.5, 
                    delay: index * 0.1,
                    type: "spring", 
                    stiffness: 100,
                    damping: 15
                  }}
                  className="group relative bg-white border border-slate-100 rounded-3xl p-6 shadow-xl shadow-slate-200/40 transition-all duration-500 overflow-hidden flex flex-col items-start h-full cursor-pointer"
                  onClick={() => setActiveCalculator(calc.id)}
                >
                  {/* Decorative background glow */}
                  <div className={`absolute -inset-x-20 -top-20 h-48 bg-gradient-to-b ${calc.color} opacity-0 group-hover:opacity-10 transition-opacity duration-700 pointer-events-none`} />
                  <motion.div
                    className="absolute inset-0 border-2 border-transparent group-hover:border-brand-primary/20 rounded-3xl pointer-events-none transition-colors duration-500"
                  />
                  
                  <div className="relative z-10 w-full flex flex-col h-full [transform-style:preserve-3d]">
                    <motion.div 
                      whileHover={{ rotate: 10, scale: 1.1 }}
                      transition={{ type: "spring", stiffness: 300, damping: 10 }}
                      className={`p-3 w-12 h-12 rounded-xl mb-4 ${calc.bgColor} ${calc.iconColor} ring-1 ring-black/5 flex items-center justify-center`}
                    >
                      <Icon className="w-6 h-6" />
                    </motion.div>
                    
                    <h3 className="text-xl font-bold text-slate-800 mb-2 group-hover:text-brand-primary transition-colors duration-300">
                      {calc.name}
                    </h3>
                    
                    <p className="text-slate-500 text-sm mb-4 leading-relaxed flex-grow group-hover:text-slate-600 transition-colors duration-300">
                      {calc.description}
                    </p>
                    
                    <div className="mt-auto w-full flex items-center justify-end">
                      <div className="w-8 h-8 rounded-full bg-slate-100 group-hover:bg-brand-primary text-slate-600 group-hover:text-white flex items-center justify-center transition-all duration-300 shadow-sm">
                        <ArrowRight className="w-4 h-4 group-hover:translate-x-0.5 transition-transform" />
                      </div>
                    </div>
                  </div>
                </motion.div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Render Modals */}
      <AnimatePresence>
        {activeCalculator === 'step-up' && (
          <StepUpSIPCalculator isOpen={true} onClose={() => setActiveCalculator(null)} />
        )}
        {activeCalculator === 'sip-swp' && (
          <SIPSWPCalculator isOpen={true} onClose={() => setActiveCalculator(null)} />
        )}
        {activeCalculator === 'swp-step-up' && (
          <SWPWithStepUpCalculator isOpen={true} onClose={() => setActiveCalculator(null)} />
        )}
        {activeCalculator === 'amortization' && (
          <AmortizationScheduleCalculator isOpen={true} onClose={() => setActiveCalculator(null)} />
        )}
        {activeCalculator === 'quick-calculations' && (
          <QuickCalculationsCalculator isOpen={true} onClose={() => setActiveCalculator(null)} />
        )}
        {activeCalculator === 'retirement-calc' && (
          <RetirementCalculator isOpen={true} onClose={() => setActiveCalculator(null)} />
        )}
        {activeCalculator === 'lump-sum' && (
          <LumpSumCalculator isOpen={true} onClose={() => setActiveCalculator(null)} />
        )}
        {activeCalculator === 'tenure-increase' && (
          <TenureIncreaseCalculator isOpen={true} onClose={() => setActiveCalculator(null)} />
        )}
        {activeCalculator === 'early-closure-lumpsum' && (
          <EarlyLoanClosureLumpSumCalculator isOpen={true} onClose={() => setActiveCalculator(null)} />
        )}
        {activeCalculator === 'property-gains' && (
          <PropertyCapitalGainsCalculator isOpen={true} onClose={() => setActiveCalculator(null)} />
        )}
      </AnimatePresence>
    </div>
  );
};
