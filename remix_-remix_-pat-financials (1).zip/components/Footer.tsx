import React from 'react';
import { Hexagon, Facebook, Youtube, Linkedin, Instagram } from 'lucide-react';
import { Link } from 'react-router-dom';
import { ScrollReveal } from './ui/ScrollReveal';

export const Footer: React.FC = () => {
  return (
    <ScrollReveal>
    <footer className="bg-brand-light pt-20 pb-10 border-t border-slate-200">
      <div className="container mx-auto px-4 md:px-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-12 mb-12">
          
          {/* Brand Column */}
          <div className="lg:col-span-2">
            <div className="flex items-center gap-2 mb-6">
              <img src="https://pradnyatamhane.com/media/images/logo-pat.jpg" alt="PAT Financials" className="h-16 md:h-20 object-contain" />
            </div>
            <p className="text-slate-500 leading-relaxed mb-6 max-w-sm">
              Helping families build, manage, and preserve wealth for generations. Your trusted partner in financial freedom.
            </p>
            <div className="flex gap-4">
              {[
                { Icon: Facebook, href: 'https://facebook.com', label: 'Facebook' },
                { Icon: Youtube, href: 'https://www.youtube.com/@cfppradnya.', label: 'Youtube' },
                { Icon: Linkedin, href: 'https://linkedin.com', label: 'LinkedIn' },
                { Icon: Instagram, href: 'https://www.instagram.com/cfppradnya_pat?igsh=MTdsN2JldzVtY3h4cg==', label: 'Instagram' }
              ].map(({ Icon, href, label }, i) => (
                <a key={i} href={href} target="_blank" rel="noopener noreferrer" aria-label={label} className="w-10 h-10 rounded-full bg-white border border-slate-200 flex items-center justify-center text-slate-500 hover:bg-brand-primary hover:text-white hover:border-brand-primary transition-all">
                  <Icon className="w-5 h-5" />
                </a>
              ))}
            </div>
          </div>

          {/* Links Column 1 */}
          <div>
            <h4 className="font-bold text-brand-dark mb-6">Services</h4>
            <ul className="space-y-4">
              {[
                { label: 'Financial Structuring', path: '/financial-planning' },
                { label: 'Wealth Distributor', path: '/wealth-management' },
                { label: 'NRI Solutions', path: '/nri-solutions' },
                { label: 'Retirement Roadmap', path: '/retirement-planning' },
                { label: 'Amortisation Schedule', path: '/amortisation-schedule' },
                { label: 'Investment Portfolio', path: '/investment-portfolio' }
              ].map(item => (
                <li key={item.label}><Link to={item.path} className="text-slate-500 hover:text-brand-primary transition-colors text-sm">{item.label}</Link></li>
              ))}
            </ul>
          </div>

          {/* Links Column 2 */}
          <div>
            <h4 className="font-bold text-brand-dark mb-6">Company</h4>
            <ul className="space-y-4">
              {['About Us', 'Our Philosophy', 'Team', 'Careers', 'Contact'].map(item => (
                <li key={item}><a href="#" className="text-slate-500 hover:text-brand-primary transition-colors text-sm">{item}</a></li>
              ))}
            </ul>
          </div>

          {/* Links Column 3 */}
          <div>
            <h4 className="font-bold text-brand-dark mb-6">Legal</h4>
            <ul className="space-y-4">
              {['Privacy Policy', 'Terms of Service', 'Disclaimer', 'SEBI Disclosure', 'Sitemap'].map(item => (
                <li key={item}><a href="#" className="text-slate-500 hover:text-brand-primary transition-colors text-sm">{item}</a></li>
              ))}
            </ul>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="pt-8 border-t border-slate-200 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-slate-500 text-sm">© {new Date().getFullYear()} PAT Financials. All rights reserved.</p>
          <div className="text-xs text-slate-400">
             Designed with <span className="text-blue-500">♥</span> for Financial Freedom
          </div>
        </div>
      </div>
    </footer>
    </ScrollReveal>
  );
};