import React, { useEffect, useState, useRef } from 'react';
import { StatItem } from '../types';

interface ExtendedStatItem extends StatItem {
  endValue: number;
  prefix: string;
  suffix: string;
}

const stats: ExtendedStatItem[] = [
  { label: 'Years Experience', value: '15+', endValue: 15, prefix: '', suffix: '+' },
  { label: 'Families Served', value: '2,100+', endValue: 2100, prefix: '', suffix: '+' },
  { label: 'Assets Managed', value: '₹360 Cr+', endValue: 360, prefix: '₹', suffix: ' Cr+' },
  { label: 'NRI Portfolios', value: '350+', endValue: 350, prefix: '', suffix: '+' },
];

const CountUp: React.FC<{
  end: number;
  duration?: number;
  prefix?: string;
  suffix?: string;
}> = ({ end, duration = 2000, prefix = '', suffix = '' }) => {
  const [count, setCount] = useState(0);
  const countRef = useRef<HTMLSpanElement>(null);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.1 }
    );

    if (countRef.current) {
      observer.observe(countRef.current);
    }

    return () => {
      observer.disconnect();
    };
  }, []);

  useEffect(() => {
    if (!isVisible) return;

    let startTime: number | null = null;
    let animationFrame: number;

    const animate = (timestamp: number) => {
      if (!startTime) startTime = timestamp;
      const progress = timestamp - startTime;
      const percentage = Math.min(progress / duration, 1);
      
      const easeOut = 1 - Math.pow(1 - percentage, 4);
      setCount(Math.floor(end * easeOut));

      if (progress < duration) {
        animationFrame = requestAnimationFrame(animate);
      } else {
        setCount(end);
      }
    };

    animationFrame = requestAnimationFrame(animate);

    return () => cancelAnimationFrame(animationFrame);
  }, [end, duration, isVisible]);

  const formattedCount = count.toLocaleString('en-IN');

  return (
    <span ref={countRef}>
      {prefix}{formattedCount}{suffix}
    </span>
  );
};

export const Stats: React.FC = () => {
  return (
    <section className="bg-gradient-to-r from-brand-primary to-brand-secondary py-16 relative overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-full bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-10"></div>
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center relative z-10">
          {stats.map((stat, index) => (
            <div key={index} className="space-y-1">
              <p className="text-4xl md:text-5xl font-display font-bold text-white tracking-tight">
                <CountUp end={stat.endValue} prefix={stat.prefix} suffix={stat.suffix} />
              </p>
              <p className="text-white/70 text-sm font-medium uppercase tracking-wider">{stat.label}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};