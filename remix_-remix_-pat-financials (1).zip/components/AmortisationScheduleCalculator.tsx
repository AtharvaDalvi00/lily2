import React, { useState } from 'react';
import { X, Calculator } from 'lucide-react';

interface AmortisationScheduleModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AmortisationScheduleModal: React.FC<AmortisationScheduleModalProps> = ({ isOpen, onClose }) => {
    const [corpus, setCorpus] = useState(8248637);
    const [rate, setRate] = useState(12);
    const [annualWithdrawal, setAnnualWithdrawal] = useState(480000);
    const [years, setYears] = useState(30);

    const calculateSchedule = () => {
        let balance = corpus;
        const schedule = [];
        for (let i = 1; i <= years; i++) {
            const interest = balance * (rate / 100);
            const balanceBeforeWithdrawal = balance + interest;
            const closingBalance = balanceBeforeWithdrawal - annualWithdrawal;
            
            schedule.push({
                year: i,
                openingBalance: balance,
                interest: interest,
                withdrawal: annualWithdrawal,
                closingBalance: closingBalance
            });
            balance = closingBalance;
        }
        return schedule;
    };

    const schedule = calculateSchedule();

    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-brand-dark/80 backdrop-blur-sm">
            <div className="bg-white w-full max-w-5xl rounded-2xl shadow-2xl max-h-[90vh] overflow-hidden flex flex-col">
                <div className="p-6 bg-brand-primary text-white flex justify-between items-center">
                    <h2 className="text-2xl font-bold flex items-center gap-3">
                        <Calculator /> EMI Calculator
                    </h2>
                    <button onClick={onClose} className="hover:bg-white/20 p-2 rounded-full transition-colors"><X className="w-6 h-6" /></button>
                </div>
                <div className="p-8 overflow-y-auto">
                    <div className="grid md:grid-cols-4 gap-6 mb-8">
                        <div>
                            <label className="block text-sm font-semibold text-slate-600 mb-2">Initial Corpus</label>
                            <input type="number" value={corpus} onChange={(e) => setCorpus(Number(e.target.value))} className="w-full p-3 rounded-xl border border-slate-200" />
                        </div>
                        <div>
                            <label className="block text-sm font-semibold text-slate-600 mb-2">Rate (%)</label>
                            <input type="number" value={rate} onChange={(e) => setRate(Number(e.target.value))} className="w-full p-3 rounded-xl border border-slate-200" />
                        </div>
                        <div>
                            <label className="block text-sm font-semibold text-slate-600 mb-2">Annual Withdrawal</label>
                            <input type="number" value={annualWithdrawal} onChange={(e) => setAnnualWithdrawal(Number(e.target.value))} className="w-full p-3 rounded-xl border border-slate-200" />
                        </div>
                        <div>
                            <label className="block text-sm font-semibold text-slate-600 mb-2">Years</label>
                            <input type="number" value={years} onChange={(e) => setYears(Number(e.target.value))} className="w-full p-3 rounded-xl border border-slate-200" />
                        </div>
                    </div>
                    
                    <div className="overflow-x-auto">
                        <table className="w-full border-collapse">
                            <thead>
                                <tr className="bg-slate-50">
                                    <th className="p-4 text-left">Year</th>
                                    <th className="p-4 text-left">Opening Balance</th>
                                    <th className="p-4 text-left">Interest</th>
                                    <th className="p-4 text-left">Withdrawal</th>
                                    <th className="p-4 text-left">Closing Balance</th>
                                </tr>
                            </thead>
                            <tbody>
                                {schedule.map((row) => (
                                    <tr key={row.year} className="border-b border-slate-100">
                                        <td className="p-4">{row.year}</td>
                                        <td className="p-4">₹{row.openingBalance.toLocaleString('en-IN', {maximumFractionDigits: 0})}</td>
                                        <td className="p-4">₹{row.interest.toLocaleString('en-IN', {maximumFractionDigits: 0})}</td>
                                        <td className="p-4">₹{row.withdrawal.toLocaleString('en-IN', {maximumFractionDigits: 0})}</td>
                                        <td className="p-4 font-semibold">₹{row.closingBalance.toLocaleString('en-IN', {maximumFractionDigits: 0})}</td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    );
};
