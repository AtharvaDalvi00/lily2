import React, { useEffect } from 'react';
import { ScrollReveal } from '../components/ui/ScrollReveal';
import { Link } from 'react-router-dom';
import { ShieldAlert, HeartPulse, Home, ArrowLeft } from 'lucide-react';
import { ContactCTA } from '../components/ContactCTA';

export const InsurancePlanningDetails: React.FC = () => {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  return (
    <>
      <ScrollReveal>
      <section className="py-20 bg-brand-light relative overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img src="https://images.unsplash.com/photo-1450101499163-c8848c66ca85?w=1600&q=80" alt="Background" className="w-full h-full object-cover opacity-[0.06] mix-blend-multiply" />
        </div>
        <div className="absolute top-0 right-0 w-64 h-64 bg-brand-primary/10 rounded-full blur-3xl"></div>
        <div className="absolute bottom-0 left-0 w-64 h-64 bg-brand-secondary/10 rounded-full blur-3xl"></div>
        
        <div className="container mx-auto px-4 md:px-6 relative z-10 text-center max-w-4xl pt-16">
          
          <Link to="/" className="inline-flex items-center gap-2 px-4 py-2 bg-white/50 hover:bg-white text-brand-primary font-medium rounded-full mb-8 backdrop-blur-sm border border-slate-200/50 hover:border-brand-primary/30 transition-all shadow-sm hover:shadow-md group">
            <ArrowLeft className="w-4 h-4 group-hover:-translate-x-1 transition-transform" /> Back to Home
          </Link>
          <h1 className="text-5xl md:text-6xl font-display font-bold text-brand-dark mb-6">Insurance Planning</h1>
          <p className="text-xl text-slate-600 mb-8 leading-relaxed">
            Protecting your family and assets against uncertainties. A robust financial plan is incomplete without an impenetrable safety net.
          </p>
        </div>
      </section>
      </ScrollReveal>

      <ScrollReveal>
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4 md:px-6 max-w-4xl">
          <div className="pred pred-lg pred-slate max-w-none text-slate-600 space-y-6">
            <h2 className="text-3xl font-display font-bold text-brand-dark">Why Do You Need Insurance Planning?</h2>
            <p>
              Life is unpredictable. Without adequate insurance, a single medical emergency or unforeseen tragedy can wipe out years of savings and derail your family's future. Insurance planning ensures that your wealth creation journey is protected against life's worst-case scenarios. We view insurance strictly purely as protection, keeping it distinctly separate from investments.
            </p>
            
            <h3 className="text-2xl font-display font-bold text-brand-dark mt-12 mb-4">Our Approach</h3>
            
            <div className="grid md:grid-cols-3 gap-8 my-8">
              <div className="bg-slate-50 p-6 rounded-2xl border border-slate-100 shadow-sm">
                <ShieldAlert className="w-10 h-10 text-brand-primary mb-4" />
                <h4 className="text-lg font-bold text-brand-dark mb-2">Life Coverage</h4>
                <p className="text-sm">We calculate your Human Life Value (HLV) to recommend pure term insurance that adequately replaces your income for your dependents.</p>
              </div>
              
              <div className="bg-slate-50 p-6 rounded-2xl border border-slate-100 shadow-sm">
                <HeartPulse className="w-10 h-10 text-brand-primary mb-4" />
                <h4 className="text-lg font-bold text-brand-dark mb-2">Health & Critical Illness</h4>
                <p className="text-sm">Assessing the spiraling costs of healthcare, we structure comprehensive medi-claim and critical illness covers to protect your savings.</p>
              </div>
              
              <div className="bg-slate-50 p-6 rounded-2xl border border-slate-100 shadow-sm">
                <Home className="w-10 h-10 text-brand-primary mb-4" />
                <h4 className="text-lg font-bold text-brand-dark mb-2">Asset Protection</h4>
                <p className="text-sm">Securing your physical assets—homes, vehicles, and businesses—against natural calamities and man-made disasters.</p>
              </div>
            </div>

            <h3 className="text-2xl font-display font-bold text-brand-dark mt-12 mb-4">The Result</h3>
            <p>
              You build an iron-clad fortress around your finances. Your investments are left untouched to grow undisturbed, knowing that every conceivable risk has been transferred and adequately covered.
            </p>
          </div>
        </div>
      </section>
      </ScrollReveal>
      
      <ContactCTA />
    </>
  );
};
