import React, { useState, useEffect } from 'react';
import { X, Calculator, Download, RefreshCw } from 'lucide-react';
import * as XLSX from 'xlsx';
import { LeadFormModal } from './LeadFormModal';

interface CalculationRow {
  year: number;
  age: number;
  monthlySIP: number;
  additionalDeposit: number;
  totalInvested: number;
  currentValue: number;
  withdrawal: number;
}

interface StepUpSIPCalculatorProps {
  isOpen: boolean;
  onClose: () => void;
}

export const StepUpSIPCalculator: React.FC<StepUpSIPCalculatorProps> = ({ isOpen, onClose }) => {
  const [investment, setInvestment] = useState(10000);
  const [stepUp, setStepUp] = useState(10);
  const [duration, setDuration] = useState(30);
  const [rate, setRate] = useState(12);
  const [startingAge, setStartingAge] = useState(28);
  const [withdrawals, setWithdrawals] = useState<{[key: number]: number}>({});
  const [additionalDeposits, setAdditionalDeposits] = useState<{[key: number]: number}>({});
  const [results, setResults] = useState<CalculationRow[]>([]);
  const [isFormOpened, setIsFormOpened] = useState(false);
  const [isFormModalOpen, setIsFormModalOpen] = useState(false);
  const formURL = "https://task-flow-pro-23-01.vercel.app/#/p/b8241986-9abe-4e33-974b-63f48dfcf893";

  const calculate = () => {
    let currentMonthlySIP = investment;
    let totalInvested = 0;
    let accumulatedCorpus = 0;
    const newResults: CalculationRow[] = [];
    const monthlyRate = rate / 12 / 100;

    for (let year = 1; year <= duration; year++) {
      let yearInvested = 0;
      
      // Calculate for 12 months in the year
      for (let month = 1; month <= 12; month++) {
        // Investment happens at the beginning of the month
        accumulatedCorpus = (accumulatedCorpus + currentMonthlySIP) * (1 + monthlyRate);
        yearInvested += currentMonthlySIP;
      }
      
      const addDeposit = additionalDeposits[year] || 0;
      const withdrawalAmount = withdrawals[year] || 0;
      
      // Handle additional deposit and withdrawal at end of year
      yearInvested += addDeposit;
      totalInvested += yearInvested;
      
      accumulatedCorpus += addDeposit;
      accumulatedCorpus -= withdrawalAmount;
      if (accumulatedCorpus < 0) accumulatedCorpus = 0;

      newResults.push({
        year,
        age: startingAge + year - 1,
        monthlySIP: Math.round(currentMonthlySIP),
        additionalDeposit: addDeposit,
        totalInvested: Math.round(totalInvested),
        withdrawal: withdrawalAmount,
        currentValue: Math.round(accumulatedCorpus),
      });

      // Step up for next year
      currentMonthlySIP = currentMonthlySIP * (1 + stepUp / 100);
    }
    setResults(newResults);
  };

  useEffect(() => {
    if(isOpen) calculate();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [investment, stepUp, duration, rate, withdrawals, additionalDeposits, startingAge, isOpen]);

  const handleWithdrawalChange = (year: number, value: string) => {
    const val = parseInt(value) || 0;
    setWithdrawals(prev => ({ ...prev, [year]: val }));
  };

  const handleDepositChange = (year: number, value: string) => {
    const val = parseInt(value) || 0;
    setAdditionalDeposits(prev => ({ ...prev, [year]: val }));
  };

  if (!isOpen) return null;

  const formatNumber = (val: number) => {
    return new Intl.NumberFormat('en-IN', {
      maximumFractionDigits: 2
    }).format(val);
  };

  const formatCurrency = (val: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0
    }).format(val);
  };

  const downloadCSV = () => {
    const totalInvested = results[results.length - 1]?.totalInvested || 0;
    const finalValue = results[results.length - 1]?.currentValue || 0;

    const htmlContent = `
<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40">
<head>
<!--[if gte mso 9]>
<xml>
<x:ExcelWorkbook>
<x:ExcelWorksheets>
<x:ExcelWorksheet>
<x:Name>Step-Up SIP Plan</x:Name>
<x:WorksheetOptions>
<x:DisplayGridlines/>
<x:ProtectContents>True</x:ProtectContents>
</x:WorksheetOptions>
</x:ExcelWorksheet>
</x:ExcelWorksheets>
</x:ExcelWorkbook>
</xml>
<![endif]-->
<meta charset="utf-8">
<style>
  table { border-collapse: collapse; font-family: 'Segoe UI', Arial, sans-serif; }
  th, td { border: 1px solid #CBD5E1; padding: 10px; font-size: 11pt; mso-protection: locked hidden; }
  
  .title-cell { font-size: 16pt; font-weight: bold; color: #FFFFFF; background-color: #1D4ED8; padding: 15px; border: none; text-align: center; mso-protection: locked hidden; }
  
  .section-header { background-color: #3B82F6; color: #FFFFFF; font-weight: bold; font-size: 12pt; text-align: left; padding: 10px; mso-protection: locked hidden; }
  .grid-header { background-color: #1E293B; color: #FFFFFF; font-weight: bold; font-size: 11pt; text-align: center; mso-protection: locked hidden; }
  
  .label-cell { color: #334155; font-weight: 500; background-color: #F8FAFC; mso-protection: locked hidden; }
  .value-cell { text-align: right; font-weight: bold; color: #020617; mso-protection: locked hidden; }
  .input-cell { text-align: right; font-weight: bold; color: #020617; background-color: #FFFFD0; mso-protection: unlocked; border: 1px solid #94A3B8; }
  
  .result-label { font-weight: bold; color: #1D4ED8; background-color: #EFF6FF; border: 1px solid #BFDBFE; mso-protection: locked hidden; }
  .result-value { font-weight: bold; color: #1D4ED8; background-color: #DBEAFE; text-align: right; border: 1px solid #BFDBFE; mso-protection: locked hidden; }
  
  .schedule-row-even { background-color: #F8FAFC; }
  .schedule-row-odd { background-color: #FFFFFF; }
  
  .currency-cell { text-align: right; mso-protection: locked hidden; }
  .center-cell { text-align: center; mso-protection: locked hidden; }
  .empty-cell { background-color: #FFFFFF; border: none; mso-protection: locked hidden; }
</style>
</head>
<body>
  <table>
    <tr>
      <td class="title-cell" colspan="7">PAT FINANCIALS - STEP-UP SIP PLANNER REPORT</td>
    </tr>
    <tr><td colspan="7" style="border: none; height: 10px;"></td></tr>

    <tr><td class="section-header" colspan="7">INPUTS &amp; ASSUMPTIONS</td></tr>
    <tr>
      <td class="label-cell">Starting SIP Amount (Monthly)</td>
      <td class="input-cell">${investment}</td>
      <td class="empty-cell" style="border: none;"></td>
      <td class="label-cell">Expected Return Rate (% p.a.)</td>
      <td class="input-cell">${rate}</td>
    </tr>
    <tr>
      <td class="label-cell">Annual Step-Up Rate (%)</td>
      <td class="input-cell">${stepUp}</td>
      <td class="empty-cell" style="border: none;"></td>
      <td class="label-cell">Starting Age (Years)</td>
      <td class="input-cell">${startingAge}</td>
    </tr>
    <tr>
      <td class="label-cell">Investment Duration (Years)</td>
      <td class="input-cell">${duration}</td>
      <td class="empty-cell" style="border: none;"></td>
      <td class="label-cell">Monthly Return Rate</td>
      <td class="value-cell" style="color: #3B82F6;">=E4/12/100</td>
    </tr>

    <tr><td colspan="7" style="border: none; height: 15px;"></td></tr>

    <tr><td class="section-header" colspan="7">PLAN SUMMARY OUTCOMES (LIVE FORMULAS)</td></tr>
    <tr>
      <td class="result-label" colspan="4">Total Invested Amount</td>
      <td class="result-value" colspan="3">=E${13 + results.length}</td>
    </tr>
    <tr>
      <td class="result-label" colspan="4">Final Wealth/Valuation</td>
      <td class="result-value" colspan="3">=G${13 + results.length}</td>
    </tr>

    <tr><td colspan="7" style="border: none; height: 15px;"></td></tr>

    <tr><td class="section-header" colspan="7">YEARLY INVESTMENT &amp; GROWTH SCHEDULE</td></tr>
    <tr>
      <td class="grid-header">YEAR</td>
      <td class="grid-header">AGE</td>
      <td class="grid-header">MONTHLY SIP AMOUNT</td>
      <td class="grid-header">ADDITIONAL DEPOSIT</td>
      <td class="grid-header">TOTAL INVESTED (TO DATE)</td>
      <td class="grid-header">WITHDRAWALS</td>
      <td class="grid-header">CLOSING VALUE</td>
    </tr>
    ${results.map((row, idx) => {
      const rowClass = idx % 2 === 0 ? 'schedule-row-even' : 'schedule-row-odd';
      const r = 14 + idx; // Excel row index
      const monthlySIPFormula = idx === 0 ? '=$B$4' : `=C${r - 1}*(1+$B$5/100)`;
      const totalInvestedFormula = idx === 0 ? '=(C14*12)+D14' : `=E${r - 1}+(C${r}*12)+D${r}`;
      const prevClosingFormula = idx === 0 ? '0' : `G${r - 1}`;
      const closingValueFormula = `=MAX(0, ROUND((${prevClosingFormula}*(1+$E$6)^12 + C${r}*(((1+$E$6)^12-1)/$E$6)*(1+$E$6))+D${r}-F${r}, 0))`;
      return `
      <tr class="${rowClass}">
        <td class="center-cell">${row.year}</td>
        <td class="center-cell" style="font-weight: bold;">=$E$5+A${r}-1</td>
        <td class="currency-cell">${monthlySIPFormula}</td>
        <td class="currency-cell" style="color: #0284C7;">${row.additionalDeposit}</td>
        <td class="currency-cell">${totalInvestedFormula}</td>
        <td class="currency-cell" style="color: #2563EB;">${row.withdrawal}</td>
        <td class="currency-cell" style="font-weight: bold; color: #1D4ED8;">${closingValueFormula}</td>
      </tr>
      `;
    }).join('')}
  </table>
</body>
</html>
`;

    const blob = new Blob([htmlContent], { type: 'application/vnd.ms-excel;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `step_up_sip_report_${new Date().toISOString().split('T')[0]}.xls`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 sm:p-6">
      <div className="absolute inset-0 bg-brand-dark/80 backdrop-blur-sm pointer-events-auto" onClick={onClose} />
      
      <div className="relative bg-white w-full max-w-5xl rounded-2xl shadow-2xl max-h-full sm:max-h-[90vh] flex flex-col overflow-hidden">
        {/* Header */}
        <div className="flex flex-wrap items-center justify-between p-6 bg-brand-primary text-white border-b border-white/20 gap-4 shrink-0">
          <div className="flex items-center gap-3">
            <div className="bg-white/20 p-2.5 rounded-xl">
              <Calculator className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-xl font-bold tracking-tight">Smart SIP Planner</h2>
              <p className="text-xs text-blue-100">Plan your wealth with Step-Up & Withdrawals</p>
            </div>
          </div>
          <div className="flex items-center gap-3 ml-auto">
            <button
              onClick={() => {
                if (!isFormOpened) {
                  setIsFormModalOpen(true);
                } else {
                  downloadCSV();
                }
              }}
              className={`flex items-center gap-2 ${isFormOpened ? 'bg-sky-600 hover:bg-sky-700' : 'bg-[#3B82F6] hover:bg-[#1D4ED8]'} text-white px-4 py-2 rounded-xl transition-colors font-semibold text-sm shadow-sm`}
            >
              <Download className="w-4 h-4" />
              {isFormOpened ? 'Download Excel Sheet' : 'Fill Form & Download'}
            </button>
            <LeadFormModal
              isOpen={isFormModalOpen}
              onClose={() => setIsFormModalOpen(false)}
              onSubmitAndDownload={() => {
                setIsFormOpened(true);
                setIsFormModalOpen(false);
                downloadCSV();
              }}
            />
            <button onClick={onClose} className="p-2.5 bg-white/10 hover:bg-white/20 rounded-xl transition-colors text-white">
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>
        <div className="flex flex-col lg:flex-row flex-1 overflow-hidden min-h-0">
        {/* Inputs Panel */}
           <div data-lenis-prevent="true" className="w-full lg:w-1/3 p-6 bg-slate-50 border-r border-slate-200 overflow-y-auto">
              <div className="space-y-6">
                 <div>
                    <label className="block text-sm font-semibold text-slate-700 mb-2">Monthly Investment (₹)</label>
                    <input 
                      type="number" 
                      value={investment || ''} 
                      onChange={(e) => setInvestment(Number(e.target.value))}
                      className="w-full p-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-brand-primary focus:border-transparent"
                    />
                    <input type="range" min="500" max="100000" step="500" value={investment} onChange={(e)=>setInvestment(Number(e.target.value))} className="w-full mt-2 accent-brand-primary"/>
                 </div>

                 <div>
                    <label className="block text-sm font-semibold text-slate-700 mb-2">Annual Step-Up (%)</label>
                    <input 
                      type="number" 
                      value={stepUp || ''} 
                      onChange={(e) => setStepUp(Number(e.target.value))}
                      className="w-full p-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-brand-primary focus:border-transparent"
                    />
                    <input type="range" min="0" max="50" step="1" value={stepUp} onChange={(e)=>setStepUp(Number(e.target.value))} className="w-full mt-2 accent-brand-primary"/>
                 </div>

                 <div>
                    <label className="block text-sm font-semibold text-slate-700 mb-2">Duration (Years)</label>
                    <input 
                      type="number" 
                      value={duration || ''} 
                      onChange={(e) => setDuration(Number(e.target.value))}
                      className="w-full p-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-brand-primary focus:border-transparent"
                    />
                    <input type="range" min="1" max="30" step="1" value={duration} onChange={(e)=>setDuration(Number(e.target.value))} className="w-full mt-2 accent-brand-primary"/>
                 </div>

                 <div>
                    <label className="block text-sm font-semibold text-slate-700 mb-2">Starting Age</label>
                    <input 
                      type="number" 
                      value={startingAge || ''} 
                      onChange={(e) => setStartingAge(Number(e.target.value))}
                      className="w-full p-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-brand-primary focus:border-transparent"
                    />
                    <input type="range" min="1" max="100" step="1" value={startingAge} onChange={(e)=>setStartingAge(Number(e.target.value))} className="w-full mt-2 accent-brand-primary"/>
                 </div>

                 <div>
                    <label className="block text-sm font-semibold text-slate-700 mb-2">Expected Return (% p.a)</label>
                    <input 
                      type="number" 
                      value={rate || ''} 
                      onChange={(e) => setRate(Number(e.target.value))}
                      className="w-full p-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-brand-primary focus:border-transparent"
                    />
                    <input type="range" min="1" max="30" step="0.5" value={rate} onChange={(e)=>setRate(Number(e.target.value))} className="w-full mt-2 accent-brand-primary"/>
                 </div>
                 
                 <div className="pt-4 border-t border-slate-200">
                   <p className="text-xs text-slate-500 text-center">Enter withdrawal amounts directly in the table on the right to simulate cash flow needs.</p>
                 </div>
              </div>
           </div>

           {/* Results Panel */}
           <div className="w-full lg:w-2/3 flex flex-col bg-white">
              <div className="p-6 grid grid-cols-2 gap-4 bg-brand-light/50 border-b border-slate-100">
                 <div>
                    <p className="text-sm text-slate-500">Total Invested</p>
                    <p className="text-2xl font-bold text-slate-800">{results.length > 0 && formatCurrency(results[results.length-1].totalInvested)}</p>
                 </div>
                 <div>
                    <p className="text-sm text-slate-500">Final Corpus Value</p>
                    <p className="text-2xl font-bold text-brand-primary">{results.length > 0 && formatCurrency(results[results.length-1].currentValue)}</p>
                 </div>
              </div>

             <div data-lenis-prevent="true" className="flex-1 overflow-auto">
                 <table className="w-full text-left border-collapse">
                    <thead className="bg-slate-100 sticky top-0 z-10 shadow-sm">
                       <tr>
                          <th className="p-3 text-xs font-bold text-slate-500 uppercase tracking-wider whitespace-nowrap">Sr. No</th>
                          <th className="p-3 text-xs font-bold text-slate-500 uppercase tracking-wider whitespace-nowrap">Age</th>
                          <th className="p-3 text-xs font-bold text-slate-500 uppercase tracking-wider whitespace-nowrap">SIP Amount</th>
                          <th className="p-3 text-xs font-bold text-slate-500 uppercase tracking-wider whitespace-nowrap bg-blue-50 min-w-[140px]">Addl. Deposit</th>
                          <th className="p-3 text-xs font-bold text-slate-500 uppercase tracking-wider whitespace-nowrap">Valuations</th>
                          <th className="p-3 text-xs font-bold text-slate-500 uppercase tracking-wider whitespace-nowrap bg-blue-50 min-w-[140px]">Withdrawal</th>
                          <th className="p-3 text-xs font-bold text-slate-500 uppercase tracking-wider whitespace-nowrap">Closing Value</th>
                       </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                       {results.map((row) => (
                          <tr key={row.year} className="hover:bg-slate-50 transition-colors">
                             <td className="p-3 text-sm font-medium text-slate-900">{row.year}</td>
                             <td className="p-3 text-sm text-slate-600">{row.age}</td>
                             <td className="p-3 text-sm text-slate-600">{formatCurrency(row.monthlySIP)}</td>
                             <td className="p-2 bg-blue-50/50">
                                <input 
                                  type="number" 
                                  placeholder="0"
                                  value={additionalDeposits[row.year] || ''}
                                  onChange={(e) => handleDepositChange(row.year, e.target.value)}
                                  className="w-full p-2 text-sm border border-slate-200 rounded focus:ring-1 focus:ring-blue-400 focus:border-blue-400 bg-white"
                                />
                             </td>
                             <td className="p-3 text-sm text-slate-600 font-medium">{formatCurrency(row.totalInvested)}</td>
                             <td className="p-2 bg-blue-50/30">
                                <input 
                                  type="number" 
                                  placeholder="0"
                                  value={withdrawals[row.year] || ''}
                                  onChange={(e) => handleWithdrawalChange(row.year, e.target.value)}
                                  className="w-full p-2 text-sm border border-slate-200 rounded focus:ring-1 focus:ring-blue-400 focus:border-blue-400 bg-white"
                                />
                             </td>
                             <td className="p-3 text-sm font-bold text-brand-primary">{formatCurrency(row.currentValue)}</td>
                          </tr>
                       ))}
                    </tbody>
                 </table>
              </div>
              <div className="p-4 border-t border-slate-100 flex justify-end gap-3 bg-white flex-wrap">
                 <button onClick={()=>{setWithdrawals({}); setAdditionalDeposits({});}} className="flex items-center gap-2 px-4 py-2 text-sm font-medium text-slate-600 hover:text-brand-primary">
                    <RefreshCw className="w-4 h-4" /> Reset Table
                 </button>
                 <button 
                    onClick={() => {
                       if (!isFormOpened) {
                         setIsFormModalOpen(true);
                       } else {
                         downloadCSV();
                       }
                    }}
                    className={`flex items-center gap-2 px-4 py-2 ${isFormOpened ? 'bg-sky-600' : 'bg-brand-dark'} text-white text-sm font-semibold rounded-lg hover:bg-slate-800 transition-colors`}
                 >
                    <Download className="w-4 h-4" /> {isFormOpened ? 'Download Excel Sheet' : 'Fill Form & Download'}
                 </button>
                 <LeadFormModal 
                    isOpen={isFormModalOpen}
                    onClose={() => setIsFormModalOpen(false)}
                    onSubmitAndDownload={() => {
                       setIsFormOpened(true);
                       setIsFormModalOpen(false);
                       downloadCSV();
                    }}
                 />
              </div>
           </div>
        </div>
      </div>
    </div>
  );
};