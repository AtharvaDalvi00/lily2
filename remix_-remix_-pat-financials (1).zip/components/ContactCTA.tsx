import React from 'react';
import { Phone, Mail, MapPin, ArrowRight } from 'lucide-react';

export const ContactCTA: React.FC = () => {
  return (
    <section id="contact" className="py-16 bg-gradient-to-br from-slate-900 to-brand-dark text-white relative overflow-hidden">
      {/* Background decoration */}
      <div className="absolute top-0 left-0 w-full h-full overflow-hidden pointer-events-none">
        <div className="absolute -top-1/2 -left-1/2 w-full h-full bg-brand-primary/20 rounded-full blur-[150px]"></div>
        <div className="absolute top-1/2 right-0 w-1/2 h-full bg-brand-secondary/10 rounded-full blur-[100px]"></div>
      </div>

      <div className="container mx-auto px-4 md:px-6 relative z-10">
        <div className="bg-white/5 backdrop-blur-lg border border-white/10 rounded-[40px] p-8 md:p-16 text-center">
          <h2 className="text-4xl md:text-6xl font-display font-bold mb-6">Ready to Build Wealth?</h2>
          <p className="text-slate-300 text-lg md:text-xl max-w-2xl mx-auto mb-12">
            Schedule a 15-minute discovery call. No obligations, just clarity. Let's start your journey to financial freedom today.
          </p>
          
          <div className="flex flex-col gap-6 justify-center mb-16">
            <div className="max-w-4xl mx-auto w-full bg-white/5 p-2 md:p-4 rounded-[2rem] shadow-2xl backdrop-blur-xl border border-white/10">
              <div className="bg-white rounded-[1.5rem] overflow-hidden shadow-inner w-full">
                <iframe 
                  src="https://task-flow-pro-23-01.vercel.app/#/p/810e568d-1824-48cf-bbc8-6809d003ae08" 
                  width="100%" 
                  className="w-full h-[1200px] md:h-[900px] lg:h-[850px]"
                  style={{ border: 'none' }}
                  title="Book an Appointment"
                />
              </div>
            </div>
            
            <div className="flex justify-center mt-4">
              <button className="px-8 py-4 w-full sm:w-auto bg-white/10 hover:bg-white/20 text-white font-bold rounded-full transition-all backdrop-blur-md flex items-center justify-center gap-2">
                <Phone className="w-5 h-5" /> Or call us directly at +91 99204 02965
              </button>
            </div>
          </div>

          <div className="grid md:grid-cols-3 gap-8 text-left">
            <div className="flex items-start gap-4 p-6 rounded-2xl bg-white/5 border border-white/5 hover:bg-white/10 transition-colors">
              <div className="p-3 bg-brand-primary/20 rounded-lg">
                <Phone className="w-6 h-6 text-brand-primary" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm text-slate-400 mb-1">Call Us</p>
                <p className="text-lg font-bold break-words">+91 99204 02965</p>
                <p className ="text-lg font-bold break-words">+91 88286 87650 </p>
                <p className="text-xs text-slate-500 mt-1">Mon-Fri, 10am - 7pm</p>
              </div>
            </div>

            <div className="flex items-start gap-4 p-6 rounded-2xl bg-white/5 border border-white/5 hover:bg-white/10 transition-colors">
              <div className="p-3 bg-brand-secondary/20 rounded-lg">
                <Mail className="w-6 h-6 text-brand-secondary" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm text-slate-400 mb-1">Email Us</p>
                <p className="text-lg font-bold break-all sm:break-words">www.patfinancials.com@gmail.com</p>
                <p className="text-xs text-slate-500 mt-1">Response within 24 hrs</p>
              </div>
            </div>

            <a 
              href="https://share.google/O4VZYVHEwnuCA2R5o" 
              target="_blank" 
              rel="noopener noreferrer"
              className="flex items-start gap-4 p-6 rounded-2xl bg-white/5 border border-white/5 hover:bg-white/10 transition-colors cursor-pointer"
            >
              <div className="p-3 bg-brand-accent/20 rounded-lg">
                <MapPin className="w-6 h-6 text-brand-accent" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm text-slate-400 mb-1">Visit Office</p>
                <p className="text-lg font-bold break-words">407, MINT IndiaBulls, near HIRANANDANI MEADOWS, next to Hyde Park, Manpada, Thane West, Thane, Maharashtra 400610</p>
                <p className="text-xs text-slate-500 mt-1">Ghodbunder Road, 400607</p>
              </div>
            </a>
          </div>
        </div>
      </div>
    </section>
  );
};