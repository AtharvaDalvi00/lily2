import React from 'react';
import { Play, Instagram } from 'lucide-react';
import { motion } from 'motion/react';

const reels = [
  {
    id: '1',
    title: 'Future Security',
    thumbnail: 'https://lh3.googleusercontent.com/pw/AP1GczOV5VnMv-T9K-1UA1fIegOaeurTyRscRVG8RGiL0pUW7vGjQ-jc2OLIPhYFZhsLGz03GDcWEeZiWaRbvGNUEJt6o_SZM4iGqsxbSrYpm3bn_D1boJakQXMyULATSuJ6YbwRQAe-Kf6ELFrIpFti9f-A=w462-h572-s-no-gm?authuser=0',
    link: 'https://www.instagram.com/reel/DW_f119SO5D/?igsh=Zzg4d3RqN21obXdm'
  },
  {
    id: '2',
    title: 'Loan Basics',
    thumbnail: 'https://lh3.googleusercontent.com/pw/AP1GczOpS1Bt1UtnXopwZEqjTsHZJWVXFBrp6-10OKBu8UsgfRdzrHr6sMkmgwgjVNT-osjaeVGOt1LOwBXZ6iO6zn5qTiz4Zn8DF-PAzt5Rh0bfRxVCbcFMzpIUviUd3nyBw_KLr2bUJXMeSoyk5w-UNf1K=w442-h560-s-no-gm?authuser=0',
    link: 'https://www.instagram.com/p/DXt1DLUR4px/'
  },
  {
    id: '3',
    title: 'Smart Finances',
    thumbnail: 'https://lh3.googleusercontent.com/pw/AP1GczP-EWFycOXG8ukD3cKAcjInUOhhPE68qievF98q9fCXTA1Vzd1dAVQL0u_rc8MivhQx2Zm1hyMFwOudqCrjHsDiDlNb5YUHk7yw4wlU4OWl8DOz290N0R0AJtL4bCUlGb9yhoXP4sASLqs7YlWQz2_T=w461-h557-s-no-gm?authuser=0',
    link: 'https://www.instagram.com/p/DXtzYTzRpqf/'
  }
];

export const ReelsSection: React.FC = () => {
    return (
        <section className="py-10 bg-brand-dark text-white">
          <div className="container mx-auto px-4 md:px-6 max-w-5xl">
            <h2 className="text-3xl lg:text-4xl font-display font-bold mb-8 text-center">
              Financial Insights in <span className="text-brand-secondary">Bite-sized Reels</span>
            </h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
              {reels.map((reel) => (
                <motion.a
                  key={reel.id}
                  href={reel.link}
                  target="_blank"
                  rel="noopener noreferrer"
                  whileHover={{ y: -5 }}
                  className="relative block aspect-[9/16] rounded-xl overflow-hidden shadow-xl group cursor-pointer"
                >
                  <img src={reel.thumbnail} alt={reel.title} className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110" />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent flex flex-col justify-end p-6">
                    <Play className="w-12 h-12 text-white mb-4 bg-white/20 p-3 rounded-full backdrop-blur-sm" />
                    <h3 className="text-xl font-bold">{reel.title}</h3>
                  </div>
                </motion.a>
              ))}
            </div>
          </div>
        </section>
    );
};
