import React from 'react';
import { CheckCircle2, Quote } from 'lucide-react';

export const About: React.FC = () => {
  return (
    <section id="about" className="py-16 bg-white relative">
      <div className="container mx-auto px-4 md:px-6 space-y-24">
        {/* Founder 1: Pradnya Tamhane */}
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          {/* Image */}
          <div className="relative mx-auto w-full max-w-lg lg:max-w-none">
            <div className="absolute -inset-4 bg-brand-primary/5 rounded-[30px] lg:-rotate-2"></div>
            <img 
              src="https://lh3.googleusercontent.com/p/AF1QipMmwfQ_zBCtdBg5BTEh6NHilx5E60WNnAc2sOKA=s1360-w1360-h1020-rw" 
              alt="Pradnya Tamhane" 
              className="relative w-full aspect-[4/5] md:aspect-[3/4] lg:aspect-auto lg:h-[600px] rounded-[30px] shadow-2xl object-cover object-top"
            />
            {/* Badge */}
            <div className="absolute -bottom-6 left-1/2 -translate-x-1/2 md:bottom-10 md:-right-6 md:left-auto md:translate-x-0 bg-white p-4 rounded-xl shadow-glow border border-brand-light flex items-center gap-3 w-max min-w-[220px] z-10">
              <div className="bg-brand-accent/20 p-2 rounded-full">
                <span className="font-display font-bold text-brand-accent">CFP</span>
              </div>
              <div className="text-sm">
                <p className="font-bold text-slate-800">Certified Financial Planner</p>
                <p className="text-slate-500 text-xs">Global Standard</p>
              </div>
            </div>
          </div>

          {/* Content */}
          <div className="space-y-8">
            <div>
              <h4 className="text-brand-primary font-semibold tracking-wide uppercase mb-2">About The Founder</h4>
              <h2 className="text-4xl md:text-5xl font-display font-bold text-brand-dark mb-4">Pradnya Tamhane</h2>
              <h3 className="text-xl font-medium text-slate-500 mb-6 font-display">Founder & Chief Problem Solver</h3>
              <p className="text-slate-600 text-lg leading-relaxed mb-6">
                Pradnya Tamhane brings over 15 years of industry expertise, combining deep financial knowledge with a passion for helping families achieve financial freedom. 
              </p>
              <p className="text-slate-600 text-lg leading-relaxed">
                Starting from a humble background in technology, she pivoted to finance to solve the complex puzzle of wealth creation for the modern Indian family. Today, PAT Financials stands as a beacon of trust for over 2,100 families.
              </p>
            </div>

            <div className="bg-brand-light p-6 rounded-2xl border-l-4 border-brand-primary relative">
              <Quote className="absolute top-4 right-4 text-brand-primary/10 w-12 h-12" />
              <p className="text-slate-700 italic font-medium mb-4 relative z-10">
                "My background in tech taught me logic and precision; finance taught me empathy and patience. We combine both to build portfolios that sleep as well as you do."
              </p>
              <div className="font-bold text-brand-dark">– Pradnya Tamhane</div>
            </div>

            <div className="grid grid-cols-2 gap-4">
               {['SEBI Registered', 'Fiduciary Standard', 'Tech-Driven', 'Family Office Approach'].map(item => (
                 <div key={item} className="flex items-center gap-2 text-slate-700 font-medium">
                   <CheckCircle2 className="w-5 h-5 text-brand-secondary" />
                   {item}
                 </div>
               ))}
            </div>
          </div>
        </div>

        {/* Founder 2: Amit Mhatre */}
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          {/* Content */}
          <div className="space-y-8 order-2 lg:order-1">
            <div>
              <h4 className="text-brand-primary font-semibold tracking-wide uppercase mb-2">About The Co-Founder</h4>
              <h2 className="text-4xl md:text-5xl font-display font-bold text-brand-dark mb-4">Amit Mhatre</h2>
              <h3 className="text-xl font-medium text-slate-500 mb-6 font-display">Co-Founder & Investment Strategist</h3>
              <p className="text-slate-600 text-lg leading-relaxed mb-6">
                With 19 years of experience in Financial Product Distribution & Wealth Distributor, Amit Mhatre co-founded PAT Financials with a vision to simplify investing and build long-term financial confidence for families.
              </p>
              <p className="text-slate-600 text-lg leading-relaxed mb-6">
                Before entrepreneurship, he spent 17 years at Prudent Corporate Advisory Services Ltd as Cluster Head, managing distributor networks and a multi-product ecosystem of ₹8,000+ crore AUM.
              </p>
              <p className="text-slate-600 text-lg leading-relaxed">
                His expertise includes Mutual Funds, Insurance, PMS, AIFs, Bonds, FDs, and wealth planning, driven by a strong belief in trust, discipline, and long-term financial guidance.
              </p>
            </div>

            <div className="bg-brand-light p-6 rounded-2xl border-l-4 border-brand-secondary relative">
              <Quote className="absolute top-4 right-4 text-brand-secondary/10 w-12 h-12" />
              <p className="text-slate-700 italic font-medium mb-4 relative z-10">
                "True wealth is created when diligence meets patience. Our goal is to craft portfolios that weather storms and capture growth, providing our clients with absolute peace of mind."
              </p>
              <div className="font-bold text-brand-dark">– Amit Mhatre</div>
            </div>

            <div className="grid grid-cols-2 gap-4">
               {['Strategic Asset Allocation', 'Risk Management', 'Macroeconomic Insight', 'Long-term Focus'].map(item => (
                 <div key={item} className="flex items-center gap-2 text-slate-700 font-medium">
                   <CheckCircle2 className="w-5 h-5 text-brand-secondary" />
                   {item}
                 </div>
               ))}
            </div>
          </div>

          {/* Image */}
          <div className="relative mx-auto w-full max-w-lg lg:max-w-none order-1 lg:order-2">
            <div className="absolute -inset-4 bg-brand-secondary/5 rounded-[30px] lg:rotate-2"></div>
            <img 
              src="https://lh3.googleusercontent.com/pw/AP1GczNVMexpdqOLtPco0jfuzF5SLxaPYlmMNtA4pBBqOno3eq4YRC5jEb-H94t8O3FPHuj0tm-QfBYVT3-JJSYx2mB5gnlTI4YPmGg-_u7m-vaWWk1zy8bTiT5teMpzSHSJCYcPJ0pOdmBwC49jH3TsxjHl=w1216-h913-s-no-gm?authuser=0" 
              alt="Amit Mhatre" 
              className="relative w-full aspect-[4/5] md:aspect-[3/4] lg:aspect-auto lg:h-[600px] rounded-[30px] shadow-2xl object-cover object-top"
            />
            {/* Badge */}
            <div className="absolute -bottom-6 left-1/2 -translate-x-1/2 md:bottom-10 md:-left-6 md:translate-x-0 bg-white p-4 rounded-xl shadow-glow border border-brand-light flex items-center gap-3 w-max min-w-[220px] z-10">
              <div className="bg-brand-primary/20 p-2 rounded-full">
                <span className="font-display font-bold text-brand-primary">CFP</span>
              </div>
              <div className="text-sm">
                <p className="font-bold text-slate-800">Investment Strategy</p>
                <p className="text-slate-500 text-xs">Market Expertise</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};