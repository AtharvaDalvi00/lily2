import React, { useState, useEffect } from 'react';
import { X, Calculator, Download, RefreshCw } from 'lucide-react';
import * as XLSX from 'xlsx';
import { LeadFormModal } from './LeadFormModal';

interface CalculationRow {
  month: number;
  year: number;
  beginningBalance: number;
  emi: number;
  additionalDeposit: number;
  principalPaid: number;
  interestPaid: number;
  endingBalance: number;
}

interface AmortizationScheduleCalculatorProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AmortizationScheduleCalculator: React.FC<AmortizationScheduleCalculatorProps> = ({ isOpen, onClose }) => {
  const [loanAmount, setLoanAmount] = useState(5000000);
  const [rate, setRate] = useState(8.5);
  const [durationYears, setDurationYears] = useState(20);
  const [additionalDeposits, setAdditionalDeposits] = useState<{[key: number]: number}>({});
  const [results, setResults] = useState<CalculationRow[]>([]);
  const [summary, setSummary] = useState({ emi: 0, totalPrincipal: 0, totalInterest: 0, totalPayment: 0 });
  const [isFormOpened, setIsFormOpened] = useState(false);
  const [isFormModalOpen, setIsFormModalOpen] = useState(false);
  const formURL = "https://task-flow-pro-23-01.vercel.app/#/p/b8241986-9abe-4e33-974b-63f48dfcf893";

  const calculate = () => {
    const principal = loanAmount;
    const monthlyRate = rate / 12 / 100;
    const totalMonths = durationYears * 12;

    if (totalMonths <= 0 || monthlyRate <= 0 || principal <= 0) {
      setResults([]);
      setSummary({ emi: 0, totalPrincipal: 0, totalInterest: 0, totalPayment: 0 });
      return;
    }

    const emi = (principal * monthlyRate * Math.pow(1 + monthlyRate, totalMonths)) / (Math.pow(1 + monthlyRate, totalMonths) - 1);
    
    let balance = principal;
    let totalInterest = 0;
    const newResults: CalculationRow[] = [];

    for (let month = 1; month <= totalMonths; month++) {
      if (balance <= 0) break;

      const interestForMonth = balance * monthlyRate;
      let actualEmi = emi;
      const addDeposit = additionalDeposits[month] || 0;
      let actualAdditionalDeposit = addDeposit;
      let principalForMonth = (emi - interestForMonth) + addDeposit;

      // Handle the last month exactly to bring balance to 0
      if (balance < principalForMonth) {
        principalForMonth = balance;
        if (balance <= (emi - interestForMonth)) {
          actualEmi = balance + interestForMonth;
          actualAdditionalDeposit = 0;
        } else {
          actualAdditionalDeposit = balance - (emi - interestForMonth);
        }
      }

      const endingBalance = balance - principalForMonth;
      totalInterest += interestForMonth;

      newResults.push({
        month,
        year: Math.ceil(month / 12),
        beginningBalance: balance,
        emi: actualEmi,
        additionalDeposit: actualAdditionalDeposit,
        principalPaid: principalForMonth,
        interestPaid: interestForMonth,
        endingBalance: Math.max(0, endingBalance),
      });

      balance = endingBalance;
    }

    setResults(newResults);
    setSummary({
      emi: Math.round(emi),
      totalPrincipal: Math.round(principal),
      totalInterest: Math.round(totalInterest),
      totalPayment: Math.round(principal + totalInterest)
    });
  };

  useEffect(() => {
    if(isOpen) calculate();
  }, [loanAmount, rate, durationYears, additionalDeposits, isOpen]);

  if (!isOpen) return null;

  const handleDepositChange = (month: number, value: string) => {
    const val = parseInt(value) || 0;
    setAdditionalDeposits(prev => ({ ...prev, [month]: val }));
  };

  const formatCurrency = (val: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0
    }).format(Math.round(val));
  };

  const formatNumber = (val: number) => {
    return new Intl.NumberFormat('en-IN', {
      maximumFractionDigits: 2
    }).format(Math.round(val));
  };

  const handleDownloadExcel = () => {
    const htmlContent = `
<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40">
<head>
<!--[if gte mso 9]>
<xml>
<x:ExcelWorkbook>
<x:ExcelWorksheets>
<x:ExcelWorksheet>
<x:Name>Amortization Schedule</x:Name>
<x:WorksheetOptions>
<x:DisplayGridlines/>
<x:ProtectContents>True</x:ProtectContents>
</x:WorksheetOptions>
</x:ExcelWorksheet>
</x:ExcelWorksheets>
</x:ExcelWorkbook>
</xml>
<![endif]-->
<meta charset="utf-8">
<style>
  table { border-collapse: collapse; font-family: 'Segoe UI', Arial, sans-serif; }
  th, td { border: 1px solid #CBD5E1; padding: 10px; font-size: 11pt; mso-protection: locked hidden; }
  
  .title-cell { font-size: 16pt; font-weight: bold; color: #FFFFFF; background-color: #2563EB; padding: 15px; border: none; text-align: center; mso-protection: locked hidden; }
  
  .section-header { background-color: #3B82F6; color: #FFFFFF; font-weight: bold; font-size: 12pt; text-align: left; padding: 10px; mso-protection: locked hidden; }
  .grid-header { background-color: #1E293B; color: #FFFFFF; font-weight: bold; font-size: 11pt; text-align: center; mso-protection: locked hidden; }
  
  .label-cell { color: #334155; font-weight: 500; background-color: #F8FAFC; mso-protection: locked hidden; }
  .value-cell { text-align: right; font-weight: bold; color: #020617; mso-protection: locked hidden; }
  .input-cell { text-align: right; font-weight: bold; color: #020617; background-color: #FFFFD0; mso-protection: unlocked; border: 1px solid #94A3B8; }
  
  .result-label { font-weight: bold; color: #1D4ED8; background-color: #EFF6FF; border: 1px solid #BFDBFE; mso-protection: locked hidden; }
  .result-value { font-weight: bold; color: #1D4ED8; background-color: #DBEAFE; text-align: right; border: 1px solid #BFDBFE; mso-protection: locked hidden; }
  
  .schedule-row-even { background-color: #F8FAFC; }
  .schedule-row-odd { background-color: #FFFFFF; }
  
  .currency-cell { text-align: right; mso-protection: locked hidden; }
  .center-cell { text-align: center; mso-protection: locked hidden; }
  .empty-cell { background-color: #FFFFFF; border: none; mso-protection: locked hidden; }
</style>
</head>
<body>
  <table>
    <tr>
      <td class="title-cell" colspan="8">PAT FINANCIALS - EMIR CALCULATOR &amp; AMORTIZATION REPORT</td>
    </tr>
    <tr><td colspan="8" style="border: none; height: 10px;"></td></tr>

    <tr><td class="section-header" colspan="8">LOAN INPUTS &amp; SPECIFICATIONS</td></tr>
    <tr>
      <td class="label-cell">Loan Amount</td>
      <td class="input-cell">${loanAmount}</td>
      <td class="empty-cell" style="border: none;"></td>
      <td class="label-cell">Interest Rate (% p.a.)</td>
      <td class="input-cell">${rate}</td>
      <td class="empty-cell" style="border: none;" colspan="3"></td>
    </tr>
    <tr>
      <td class="label-cell">Duration (Years)</td>
      <td class="input-cell">${durationYears}</td>
      <td class="empty-cell" style="border: none;"></td>
      <td class="label-cell">Monthly Rate</td>
      <td class="value-cell" style="color: #2563EB;">=E4/12/100</td>
      <td class="empty-cell" style="border: none;" colspan="3"></td>
    </tr>

    <tr><td colspan="8" style="border: none; height: 15px;"></td></tr>

    <tr><td class="section-header" colspan="8">LOAN SUMMARY &amp; OUTCOMES (LIVE FORMULAS)</td></tr>
    <tr>
      <td class="result-label" colspan="4">Monthly EMI (Excel Formula)</td>
      <td class="result-value" colspan="4">=PMT(E5, B5*12, -B4)</td>
    </tr>
    <tr>
      <td class="result-label" colspan="4">Total Principal Paid</td>
      <td class="result-value" colspan="4">=SUM(F15:F${14 + results.length})</td>
    </tr>
    <tr>
      <td class="result-label" colspan="4">Total Interest Paid</td>
      <td class="result-value" colspan="4">=SUM(G15:G${14 + results.length})</td>
    </tr>
    <tr>
      <td class="result-label" colspan="4">Total Payments Amount</td>
      <td class="result-value" colspan="4">=E9+E10</td>
    </tr>

    <tr><td colspan="8" style="border: none; height: 15px;"></td></tr>

    <tr><td class="section-header" colspan="8">DETAILED MONTHLY AMORTIZATION SCHEDULE</td></tr>
    <tr>
      <td class="grid-header">MONTH</td>
      <td class="grid-header">YEAR</td>
      <td class="grid-header">BEGINNING BALANCE</td>
      <td class="grid-header">EMI AMOUNT</td>
      <td class="grid-header">PREPAYMENT/DEPOSIT</td>
      <td class="grid-header">PRINCIPAL REPAYMENT</td>
      <td class="grid-header">INTEREST COMPONENT</td>
      <td class="grid-header">ENDING BALANCE</td>
    </tr>
    ${results.map((row, idx) => {
      const rowClass = idx % 2 === 0 ? 'schedule-row-even' : 'schedule-row-odd';
      const r = 15 + idx; // Excel row index
      const begBalFormula = idx === 0 ? '=B4' : `=H${r - 1}`;
      return `
      <tr class="${rowClass}">
        <td class="center-cell">${row.month}</td>
        <td class="center-cell" style="font-weight: bold;">=ROUNDUP(A${r}/12, 0)</td>
        <td class="currency-cell">${begBalFormula}</td>
        <td class="currency-cell">=IF(C${r}>0, MIN($E$8, C${r}+G${r}), 0)</td>
        <td class="currency-cell" style="color: #0284C7;">${row.additionalDeposit}</td>
        <td class="currency-cell" style="color: #2563EB;">=IF(C${r}>0, MIN(C${r}, D${r}-G${r}+E${r}), 0)</td>
        <td class="currency-cell" style="color: #0284C7;">=IF(C${r}>0, ROUND(C${r}*$E$5, 2), 0)</td>
        <td class="currency-cell" style="font-weight: bold;">=IF(C${r}>0, ROUND(C${r}-F${r}, 2), 0)</td>
      </tr>
      `;
    }).join('')}
  </table>
</body>
</html>
`;

    const blob = new Blob([htmlContent], { type: 'application/vnd.ms-excel;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `amortization_schedule_${new Date().toISOString().split('T')[0]}.xls`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 sm:p-6">
      <div className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm pointer-events-auto" onClick={onClose} />
      
      <div className="relative bg-[#FAFAFA] rounded-3xl shadow-2xl w-full max-w-6xl max-h-full sm:max-h-[90vh] flex flex-col overflow-hidden">
        {/* Header */}
        <div className="flex flex-wrap items-center justify-between p-6 bg-brand-primary text-white border-b border-white/20 gap-4 shrink-0">
          <div className="flex items-center gap-3">
            <div className="bg-white/20 p-2.5 rounded-xl">
              <Calculator className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-xl font-bold tracking-tight">EMI Calculator</h2>
              <p className="text-xs text-blue-100">Calculate your monthly loan EMI, interest, and track your amortization schedule</p>
            </div>
          </div>
          <div className="flex items-center gap-3 ml-auto">
            <button
              onClick={() => {
                if (!isFormOpened) {
                  setIsFormModalOpen(true);
                } else {
                  handleDownloadExcel();
                }
              }}
              className={`flex items-center gap-2 ${isFormOpened ? 'bg-sky-600 hover:bg-sky-700' : 'bg-[#3B82F6] hover:bg-[#1D4ED8]'} text-white px-4 py-2 rounded-xl transition-colors font-semibold text-sm shadow-sm`}
            >
              <Download className="w-4 h-4" />
              {isFormOpened ? 'Download Excel Sheet' : 'Fill Form & Download'}
            </button>
            <LeadFormModal
              isOpen={isFormModalOpen}
              onClose={() => setIsFormModalOpen(false)}
              onSubmitAndDownload={() => {
                setIsFormOpened(true);
                setIsFormModalOpen(false);
                handleDownloadExcel();
              }}
            />
            <button onClick={onClose} className="p-2.5 bg-white/10 hover:bg-white/20 rounded-xl transition-colors text-white">
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>
        {/* Content Section: Inputs Column and Results Column */}
        <div className="flex-1 p-6 grid grid-cols-1 lg:grid-cols-3 gap-6 min-h-0 overflow-y-auto lg:overflow-hidden bg-slate-50/30">
          
          {/* Inputs Column (Left on Desktop, Top on Mobile) */}
          <div className="lg:col-span-1 space-y-6 lg:overflow-y-auto lg:pr-2" data-lenis-prevent="true">
            <div className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm space-y-6">
              <h3 className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Input parameters</h3>
              
              {/* Loan Amount */}
              <div>
                <div className="flex justify-between mb-2">
                  <label className="text-sm font-medium text-slate-700">Loan Amount (₹)</label>
                  <span className="text-sm font-bold text-blue-600">{formatCurrency(loanAmount)}</span>
                </div>
                <input
                  type="range"
                  min="100000"
                  max="50000000"
                  step="100000"
                  value={loanAmount}
                  onChange={(e) => setLoanAmount(Number(e.target.value))}
                  className="w-full h-2 bg-slate-100 rounded-lg appearance-none cursor-pointer accent-blue-600"
                />
                <input
                  type="number"
                  value={loanAmount || ''}
                  onChange={(e) => setLoanAmount(Number(e.target.value))}
                  className="mt-3 w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-600 focus:border-transparent transition-all text-sm font-semibold text-slate-800"
                />
              </div>

              {/* Annual Interest Rate (%) */}
              <div>
                <div className="flex justify-between mb-2">
                  <label className="text-sm font-medium text-slate-700">Annual Interest Rate (%)</label>
                  <span className="text-sm font-bold text-blue-600">{rate}%</span>
                </div>
                <input
                  type="range"
                  min="1"
                  max="20"
                  step="0.1"
                  value={rate}
                  onChange={(e) => setRate(Number(e.target.value))}
                  className="w-full h-2 bg-slate-100 rounded-lg appearance-none cursor-pointer accent-blue-600"
                />
                <input
                  type="number"
                  value={rate || ''}
                  onChange={(e) => setRate(Number(e.target.value))}
                  className="mt-3 w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-600 focus:border-transparent transition-all text-sm font-semibold text-slate-800"
                />
              </div>

              {/* Loan Tenure (Years) */}
              <div>
                <div className="flex justify-between mb-2">
                  <label className="text-sm font-medium text-slate-700">Loan Tenure (Years)</label>
                  <span className="text-sm font-bold text-blue-600">{durationYears} Yrs</span>
                </div>
                <input
                  type="range"
                  min="1"
                  max="30"
                  step="1"
                  value={durationYears}
                  onChange={(e) => setDurationYears(Number(e.target.value))}
                  className="w-full h-2 bg-slate-100 rounded-lg appearance-none cursor-pointer accent-blue-600"
                />
                <input
                  type="number"
                  value={durationYears || ''}
                  onChange={(e) => setDurationYears(Number(e.target.value))}
                  className="mt-3 w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-600 focus:border-transparent transition-all text-sm font-semibold text-slate-800"
                />
              </div>
            </div>

            <div className="bg-slate-50 rounded-2xl p-6 border border-slate-200/60">
              <h4 className="font-semibold text-slate-800 mb-2 flex items-center gap-2">
                <RefreshCw className="w-4 h-4 text-slate-500 animate-spin-slow" />
                How it works
              </h4>
              <p className="text-xs text-slate-600 leading-relaxed">
                An amortization schedule shows you how your loan is paid off over time. 
                In the early years, most of your EMI goes towards interest. In the later 
                years, a larger portion goes towards blueucing the principal. Adding prepayments/additional deposits helps you save major interest and close the loan early!
              </p>
            </div>
          </div>

          {/* Results Column (Right on Desktop, Bottom on Mobile) */}
          <div className="lg:col-span-2 space-y-6 lg:overflow-y-auto lg:pr-2" data-lenis-prevent="true">
            
            {/* Summary Cards with Responsive Columns and Font Sizes to prevent overlapping */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="bg-white p-4 rounded-2xl border border-gray-100 shadow-sm relative overflow-hidden group flex flex-col justify-between">
                <p className="text-xs font-semibold text-slate-500 uppercase tracking-wide mb-1">Monthly EMI</p>
                <p className="text-base sm:text-lg md:text-xl lg:text-base xl:text-xl 2xl:text-2xl font-bold text-slate-800" title={formatCurrency(summary.emi)}>
                  {formatCurrency(summary.emi)}
                </p>
              </div>
              <div className="bg-white p-4 rounded-2xl border border-gray-100 shadow-sm relative overflow-hidden group flex flex-col justify-between">
                <p className="text-xs font-semibold text-slate-500 uppercase tracking-wide mb-1">Total Principal</p>
                <p className="text-base sm:text-lg md:text-xl lg:text-base xl:text-xl 2xl:text-2xl font-bold text-slate-800" title={formatCurrency(summary.totalPrincipal)}>
                  {formatCurrency(summary.totalPrincipal)}
                </p>
              </div>
              <div className="bg-white p-4 rounded-2xl border border-gray-100 shadow-sm relative overflow-hidden group flex flex-col justify-between">
                <p className="text-xs font-semibold text-slate-500 uppercase tracking-wide mb-1">Total Interest</p>
                <p className="text-base sm:text-lg md:text-xl lg:text-base xl:text-xl 2xl:text-2xl font-bold text-slate-800" title={formatCurrency(summary.totalInterest)}>
                  {formatCurrency(summary.totalInterest)}
                </p>
              </div>
              <div className="bg-white p-4 rounded-2xl border border-blue-100 shadow-sm relative overflow-hidden group flex flex-col justify-between">
                <p className="text-xs font-semibold text-blue-500 uppercase tracking-wide mb-1">Total Payment</p>
                <p className="text-base sm:text-lg md:text-xl lg:text-base xl:text-xl 2xl:text-2xl font-bold text-blue-600" title={formatCurrency(summary.totalPayment)}>
                  {formatCurrency(summary.totalPayment)}
                </p>
              </div>
            </div>

            {/* Table */}
            <div className="bg-white rounded-2xl border border-gray-100 shadow-sm flex flex-col overflow-hidden">
              <div className="px-6 py-4 border-b border-gray-100 flex justify-between items-center bg-slate-50/50 shrink-0">
                <h4 className="font-semibold text-slate-800 text-sm">Amortisation Schedule & Prepayment Support</h4>
                <p className="text-xs text-slate-500 hidden sm:block">Edit 'Addl. Deposit' directly to test prepayments</p>
              </div>
              
              <div data-lenis-prevent="true" className="overflow-auto max-h-[360px]">
                <table className="w-full text-sm text-left relative">
                  <thead className="text-xs text-slate-500 uppercase bg-slate-50/95 sticky top-0 z-10 backdrop-blur-sm border-b border-gray-100">
                    <tr>
                      <th className="px-4 py-3 font-semibold">Month</th>
                      <th className="px-4 py-3 font-semibold">Year</th>
                      <th className="px-4 py-3 font-semibold text-right">Beg. Balance</th>
                      <th className="px-4 py-3 font-semibold text-right">EMI</th>
                      <th className="px-4 py-3 font-semibold text-right text-sky-600">Addl. Deposit</th>
                      <th className="px-4 py-3 font-semibold text-right text-blue-600">Principal</th>
                      <th className="px-4 py-3 font-semibold text-right text-blue-600">Interest</th>
                      <th className="px-4 py-3 font-semibold text-right">End Balance</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-100">
                    {results.map((row, i) => (
                      <tr key={i} className="hover:bg-slate-50/50 transition-colors">
                        <td className="px-4 py-3 font-medium text-slate-700">{row.month}</td>
                        <td className="px-4 py-3 text-slate-600">Yr {row.year}</td>
                        <td className="px-4 py-3 text-right text-slate-600">{formatCurrency(row.beginningBalance)}</td>
                        <td className="px-4 py-3 text-right font-medium text-slate-700">{formatCurrency(row.emi)}</td>
                        <td className="px-2 py-1 bg-sky-50/50">
                          <input 
                            type="number" 
                            placeholder="0"
                            value={additionalDeposits[row.month] || ''}
                            onChange={(e) => handleDepositChange(row.month, e.target.value)}
                            className="w-24 p-1 text-right text-xs border border-slate-200 rounded focus:ring-1 focus:ring-sky-400 focus:border-sky-400 bg-white ml-auto block"
                          />
                        </td>
                        <td className="px-4 py-3 text-right text-blue-600">{formatCurrency(row.principalPaid)}</td>
                        <td className="px-4 py-3 text-right text-blue-600">{formatCurrency(row.interestPaid)}</td>
                        <td className="px-4 py-3 text-right font-medium text-slate-700">{formatCurrency(row.endingBalance)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
            
            {/* Table Action Buttons */}
            <div className="flex gap-4 flex-wrap">
              <button onClick={() => setAdditionalDeposits({})} className="flex items-center gap-2 px-4 py-2 text-sm font-medium text-slate-600 hover:text-brand-primary transition-colors bg-white border border-slate-200 rounded-xl shadow-sm">
                <RefreshCw className="w-4 h-4" /> Reset Prepayments
              </button>
              <button 
                onClick={() => {
                   if (!isFormOpened) {
                     setIsFormModalOpen(true);
                   } else {
                     handleDownloadExcel();
                   }
                }}
                className={`flex items-center gap-2 ${isFormOpened ? 'bg-blue-600 hover:bg-blue-700' : 'bg-[#3B82F6] hover:bg-[#1D4ED8]'} text-white px-4 py-2 rounded-xl transition-colors font-semibold text-sm shadow-sm`}
              >
                <Download className="w-4 h-4" />
                {isFormOpened ? 'Download Excel Sheet' : 'Fill Form & Download'}
              </button>
              <LeadFormModal 
                isOpen={isFormModalOpen}
                onClose={() => setIsFormModalOpen(false)}
                onSubmitAndDownload={() => {
                  setIsFormOpened(true);
                  setIsFormModalOpen(false);
                  handleDownloadExcel();
                }}
              />
            </div>

          </div>

        </div>
      </div>
    </div>
  );
};
