import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Calculator, BookOpen, Lightbulb, FileText, ArrowUpRight } from 'lucide-react';
import { Link } from 'react-router-dom';
import { StepUpSIPCalculator } from './StepUpSIPCalculator';
import { SIPSWPCalculator } from './SIPSWPCalculator';
import { SWPWithStepUpCalculator } from './SWPWithStepUpCalculator';
import { AmortizationScheduleCalculator } from './AmortizationScheduleCalculator';
import { LumpSumCalculator } from './LumpSumCalculator';
import { TenureIncreaseCalculator } from './TenureIncreaseCalculator';
import { EarlyLoanClosureLumpSumCalculator } from './EarlyLoanClosureLumpSumCalculator';
import { QuickCalculationsCalculator } from './QuickCalculationsCalculator';
import { PropertyCapitalGainsCalculator } from './PropertyCapitalGainsCalculator';

const toolkitItems = [
  {
    id: 'sip-swp',
    icon: Calculator,
    title: 'SIP & SWP Calculator',
    description: 'Plan your investment corpus and generate reliable passive income streams.',
    color: 'text-brand-primary',
    bgColor: 'bg-blue-50',
    actionText: 'Launch Tool',
    isAction: true
  },
  {
    id: 'step-up-sip',
    icon: Calculator,
    title: 'Step Up SIP Calculator',
    description: 'Plan for inflation with our advanced step-up calculator with annual increments.',
    color: 'text-blue-600',
    bgColor: 'bg-blue-50',
    actionText: 'Launch Tool',
    isAction: true
  },
  {
    id: 'swp-step-up',
    icon: Calculator,
    title: 'SWP with Step Up',
    description: 'Estimate your future retirement corpus and optimize systematic withdrawal growth.',
    color: 'text-brand-secondary',
    bgColor: 'bg-sky-50',
    actionText: 'Launch Tool',
    isAction: true
  },
  {
    id: 'amortization',
    icon: Calculator,
    title: 'EMI Calculator',
    description: 'Calculate your loan EMI, total interest, and test prepayment support to save big.',
    color: 'text-sky-600',
    bgColor: 'bg-sky-50',
    actionText: 'Launch Tool',
    isAction: true
  },
  {
    id: 'lump-sum',
    icon: Calculator,
    title: 'LumpSum Calculator',
    description: 'Calculate the potential long-term growth of your one-time investments.',
    color: 'text-blue-600',
    bgColor: 'bg-blue-50',
    actionText: 'Launch Tool',
    isAction: true
  },
  {
    id: 'tenure-increase',
    icon: Calculator,
    title: 'Early Loan Closure',
    description: 'Build immense passive wealth by increasing loan tenure and investing the EMI savings.',
    color: 'text-sky-600',
    bgColor: 'bg-sky-50',
    actionText: 'Launch Tool',
    isAction: true
  },
  {
    id: 'early-closure-lumpsum',
    icon: Calculator,
    title: 'Early Loan Closure - Lump Sum',
    description: 'Calculate interest savings and early payoff options with lump sum prepayments.',
    color: 'text-blue-600',
    bgColor: 'bg-blue-50',
    actionText: 'Launch Tool',
    isAction: true
  },
  {
    id: 'quick-calculations',
    icon: Calculator,
    title: 'Quick Calci',
    description: 'Instant answers for your SIP and Lump Sum future values, required years, rates, and amounts.',
    color: 'text-sky-600',
    bgColor: 'bg-sky-50',
    actionText: 'Launch Tool',
    isAction: true
  },
  {
    id: 'property-gains',
    icon: Calculator,
    title: 'Property Capital Gains',
    description: 'Compare 12.5% flat tax vs 20% indexed tax and optimize reinvestment under Section 54EC.',
    color: 'text-emerald-600',
    bgColor: 'bg-emerald-50',
    actionText: 'Launch Tool',
    isAction: true
  }
];

export const Resources: React.FC = () => {
  const [isSIPSWPOpen, setIsSIPSWPOpen] = useState(false);
  const [isStepUpSIPOpen, setIsStepUpSIPOpen] = useState(false);
  const [isSWPWithStepUpOpen, setIsSWPWithStepUpOpen] = useState(false);
  const [isAmortizationOpen, setIsAmortizationOpen] = useState(false);
  const [isLumpSumOpen, setIsLumpSumOpen] = useState(false);
  const [isTenureIncreaseOpen, setIsTenureIncreaseOpen] = useState(false);
  const [isEarlyClosureLumpSumOpen, setIsEarlyClosureLumpSumOpen] = useState(false);
  const [isQuickCalculationsOpen, setIsQuickCalculationsOpen] = useState(false);
  const [isPropertyGainsOpen, setIsPropertyGainsOpen] = useState(false);

  const handleAction = (id: string) => {
    if (id === 'sip-swp') setIsSIPSWPOpen(true);
    if (id === 'step-up-sip') setIsStepUpSIPOpen(true);
    if (id === 'swp-step-up') setIsSWPWithStepUpOpen(true);
    if (id === 'amortization') setIsAmortizationOpen(true);
    if (id === 'lump-sum') setIsLumpSumOpen(true);
    if (id === 'tenure-increase') setIsTenureIncreaseOpen(true);
    if (id === 'early-closure-lumpsum') setIsEarlyClosureLumpSumOpen(true);
    if (id === 'quick-calculations') setIsQuickCalculationsOpen(true);
    if (id === 'property-gains') setIsPropertyGainsOpen(true);
  };

  return (
    <section id="resources" className="py-20 bg-slate-50/40 relative overflow-hidden">
      {/* Decorative background glow blobs for visible glassmorphism backdrop-blur */}
      <div className="absolute top-1/4 left-1/10 w-96 h-96 bg-brand-primary/10 rounded-full blur-[100px] pointer-events-none -z-10" />
      <div className="absolute bottom-1/4 right-1/10 w-96 h-96 bg-sky-500/10 rounded-full blur-[100px] pointer-events-none -z-10" />

      <div className="container mx-auto px-4 md:px-6">
        <div className="flex flex-col md:flex-row justify-between items-end mb-12 gap-6">
           <div className="max-w-2xl">
              <h2 className="text-4xl font-display font-bold text-brand-dark mb-4">Financial Toolkit</h2>
              <p className="text-slate-600 text-lg leading-relaxed">Smart tools and insights to help you make better money decisions on the go.</p>
           </div>
           <Link to="/resources" className="group text-brand-primary font-semibold flex items-center gap-2 px-6 py-3 bg-brand-light rounded-full hover:bg-brand-primary hover:text-white transition-all duration-300">
             View All Resources <ArrowUpRight className="w-5 h-5 group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform" />
           </Link>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {toolkitItems.map((item, index) => (
            <motion.div 
              key={item.id}
              initial={{ opacity: 0, y: -60, rotateX: 30 }}
              whileInView={{ opacity: 1, y: 0, rotateX: 0 }}
              viewport={{ once: false, margin: "-50px" }}
              transition={{ 
                duration: 0.6, 
                delay: index * 0.1,
                type: "spring",
                bounce: 0.4
              }}
              onClick={() => handleAction(item.id)}
              className="group relative bg-white/60 backdrop-blur-md hover:bg-sky-50/70 p-8 rounded-3xl shadow-sm hover:shadow-2xl transition-all duration-500 hover:-translate-y-2 border border-white/80 overflow-hidden cursor-pointer hover:border-sky-200/80"
              style={{ backdropFilter: 'blur(16px)', WebkitBackdropFilter: 'blur(16px)' }}
            >
              {/* Decorative background elements */}
              <div className="absolute -top-12 -right-12 w-32 h-32 rounded-full bg-gradient-to-br from-sky-500/10 to-transparent transition-all duration-700 ease-in-out group-hover:scale-[2.5] opacity-0 group-hover:opacity-100"></div>
              <div className="absolute top-8 -right-4 w-16 h-16 rounded-full border-2 border-sky-500/20 transition-all duration-500 delay-100 ease-out group-hover:-translate-x-6 group-hover:translate-y-2 group-hover:scale-150 opacity-0 group-hover:opacity-100"></div>

              <div className="relative z-10 flex flex-col h-full">
                <div className={`w-14 h-14 ${item.bgColor} rounded-xl flex items-center justify-center mb-6 group-hover:bg-sky-500 group-hover:scale-110 group-hover:rotate-3 transition-all duration-300 shadow-sm group-hover:shadow-sky-500/30`}>
                  <item.icon className={`w-7 h-7 ${item.color} group-hover:text-white transition-colors duration-300`} />
                </div>
                
                <h3 className="text-xl font-bold mb-3 transition-colors duration-300 text-brand-dark group-hover:text-sky-600">
                  {item.title}
                </h3>
                <p className="text-sm mb-6 leading-relaxed transition-colors duration-300 text-slate-500 group-hover:text-slate-600 flex-grow">
                  {item.description}
                </p>

                <div className="mt-auto">
                  <span className="text-sm font-semibold inline-flex items-center gap-2 transition-all duration-300 text-sky-600 group-hover:translate-x-2">
                    {item.actionText}
                    <ArrowUpRight className="w-4 h-4 opacity-0 -translate-x-4 group-hover:translate-x-0 group-hover:opacity-100 transition-all duration-300" />
                  </span>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>

      <StepUpSIPCalculator isOpen={isStepUpSIPOpen} onClose={() => setIsStepUpSIPOpen(false)} />
      <SIPSWPCalculator isOpen={isSIPSWPOpen} onClose={() => setIsSIPSWPOpen(false)} />
      <SWPWithStepUpCalculator isOpen={isSWPWithStepUpOpen} onClose={() => setIsSWPWithStepUpOpen(false)} />
      <AmortizationScheduleCalculator isOpen={isAmortizationOpen} onClose={() => setIsAmortizationOpen(false)} />
      <LumpSumCalculator isOpen={isLumpSumOpen} onClose={() => setIsLumpSumOpen(false)} />
      <TenureIncreaseCalculator isOpen={isTenureIncreaseOpen} onClose={() => setIsTenureIncreaseOpen(false)} />
      <EarlyLoanClosureLumpSumCalculator isOpen={isEarlyClosureLumpSumOpen} onClose={() => setIsEarlyClosureLumpSumOpen(false)} />
      <QuickCalculationsCalculator isOpen={isQuickCalculationsOpen} onClose={() => setIsQuickCalculationsOpen(false)} />
      <PropertyCapitalGainsCalculator isOpen={isPropertyGainsOpen} onClose={() => setIsPropertyGainsOpen(false)} />
    </section>
  );
};
