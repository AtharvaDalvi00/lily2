import React from 'react';
import { Play } from 'lucide-react';
import { ScrollReveal } from './ui/ScrollReveal';
import { motion } from 'motion/react';

const videoTestimonials = [
  {
    id: 'vt1',
    name: 'Mr. Sudesh Bhelekar',
    role: 'Consultant MEP services at Provenance Land',
    title: 'How PAT Financials transformed our business planning',
    thumbnail: 'https://img.youtube.com/vi/_m7AurhxA8E/hqdefault.jpg',
    avatar: 'https://lh3.googleusercontent.com/pw/AP1GczPTXVy0HV7uxx-pC1vOPVz1mL-Sp5NU6cEMkkx7Q5y7m5NKFMifuN-KqZqPKUeqVcdy9oOpFS3hnX8fi8ipdCqKWanJTm_yhVOGJBsYAEZ-ZDNXty-Esc3NbdOkvjeoOIEjbL17mzon8TMy_waZ0bGQ=w294-h294-s-no-gm?authuser=0',
    link: 'https://www.youtube.com/watch?v=_m7AurhxA8E',
    duration: '2:07'
  },
  {
    id: 'vt2',
    name: 'Mr. Amol Jaywant',
    role: 'Senior Vice President and Head Credit Card Alliances and  EMI at Axis Bank s',
    title: 'Securing our dream retirement through expert guidance',
    thumbnail: 'https://img.youtube.com/vi/5JsHpBr_4nA/hqdefault.jpg',
    avatar: 'https://lh3.googleusercontent.com/pw/AP1GczOSPeE0ybrat-oFCP1C3yccxdrnePQi0IGHM7czUSlEeAAZJg71K46yJIfpwvNitkON9pzY07BTY9cPGKp7OY0GOUSutGXdo0PPVfxZH6kM9AU0YNorcxedMZBqyQab0E-qiTL3neka6Xj4WFwkO41_=w800-h800-s-no-gm?authuser=0',
    link: 'https://www.youtube.com/watch?v=5JsHpBr_4nA',
    duration: '2:36'
  },
  {
    id: 'vt3',
    name: 'Mr. Chetan Pangam',
    role: 'Group Manager at Atos-Syntel Internal Audit Function ',
    title: 'Strategic portfolio management that delivers results',
    thumbnail: 'https://img.youtube.com/vi/efwY6mOPA0I/hqdefault.jpg',
    avatar: 'https://lh3.googleusercontent.com/pw/AP1GczM2mOf2UjaFCkeKaXL0PstvzhpZ3SYTGzi-jsY398GYkC4m3QZ4W_lqqkVkTFl3Zw_sDSIpftV0LmkEGJr1sPEbMpM-pUpk-sVxncb0hANi-AxZ6UC3K45CZDYZ63tIgkkz8z9r9GlKzqZQz9fNPlFM=w800-h800-s-no-gm?authuser=0',
    link: 'https://www.youtube.com/watch?v=efwY6mOPA0I',
    duration: '0:53'
  },
  {
    id: 'vt4',
    name: 'Mr. Abhijaat Sinha',
    role: 'Company Secretary & Legal Counsel at Huhtamaki India',
    title: 'Gaining confidence in my financial future',
    thumbnail: 'https://i.ytimg.com/vi/lVX09j872IU/hqdefault.jpg?sqp=-oaymwEnCNACELwBSFryq4qpAxkIARUAAIhCGAHYAQHiAQoIGBACGAY4AUAB&rs=AOn4CLA1sNy1iA0i7Pi2eESz44w4a4QoIg',
    avatar: 'https://lh3.googleusercontent.com/pw/AP1GczNhxwqcnzkbK8f4uER9zNsQi5v9qK4MXBwAvMKoqmWesMXSAqGylDbC61PUKn8S3RIcE_6q-lRnjg6ySWqhWJLv_CSeYXgKFX3lxHZXTJXh3z7pcLkgyo44AWs3VgsKfFKFx2b4ZsJjuke1tetGKO7I=w800-h800-s-no-gm?authuser=0',
    link: 'https://youtu.be/lVX09j872IU?si=KiEzAlLY3Mq2Dz1m',
    duration: '2:46'
  },
  {
    id: 'vt5',
    name: 'Mr. Lalit Ishi',
    role: 'Vice President at Citi India',
    title: 'Peace of mind knowing my family is protected',
    thumbnail: 'https://i.ytimg.com/vi/XClePywZUng/hqdefault.jpg?sqp=-oaymwEmCKgBEF5IWvKriqkDGQgBFQAAiEIYAdgBAeIBCggYEAIYBjgBQAE=&rs=AOn4CLBJNgrsJW9dbyD1_xh6vWUjrfMarA',
    avatar: 'https://lh3.googleusercontent.com/pw/AP1GczPCIXIP87q6S_UhPrd7g_5gOM7dwj3JNMc1d-tDCm531xa6bIqcQg6Y5wm40xCAuKON3aAYj6CHQiVsgrAjD8LRqhKJ0sCmdatKNEAyQw_XeamqWStZwQvQpCfFfMGsc2gg1ThWAvUtmMdiEVuRMMPA=w400-h400-s-no-gm?authuser=0',
    link: 'https://youtu.be/XClePywZUng?si=whV1rzzxnliss8Am',
    duration: '2:46'
  }
];

export const VideoTestimonials: React.FC = () => {
  return (
    <section className="py-16 bg-white overflow-hidden">
      <div className="container mx-auto px-4 md:px-6">
        <ScrollReveal>
          <div className="text-center mb-12">
            <h2 className="text-4xl font-display font-bold text-brand-dark mb-4">Real stories, real results</h2>
            <p className="text-slate-600 max-w-2xl mx-auto">Hear directly from our clients about how tailored financial structuring has impacted their lives and secured their future.</p>
          </div>
        </ScrollReveal>

        <div className="flex flex-wrap justify-center gap-8">
          {videoTestimonials.map((video, index) => (
            <div key={video.id} className="w-full md:w-[calc(50%-1rem)] lg:w-[calc(33.333%-1.4rem)] max-w-lg">
              <motion.div 
                key={video.id}
                initial={{ opacity: 0, y: -60, rotateX: 30 }}
                whileInView={{ opacity: 1, y: 0, rotateX: 0 }}
                viewport={{ once: false, margin: "-50px" }}
                transition={{ 
                  duration: 0.6, 
                  delay: index * 0.1,
                  type: "spring",
                  bounce: 0.4
                }}
                className="h-full"
              >
                <a 
                  href={video.link}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="group flex flex-col h-full relative rounded-3xl overflow-hidden shadow-sm hover:shadow-2xl bg-white border border-slate-100 hover:border-sky-200 hover:bg-sky-50 transition-all duration-500 hover:-translate-y-2"
                >
                {/* Thumbnail */}
                <div className="relative aspect-video w-full overflow-hidden shrink-0">
                  <div className="absolute inset-0 bg-brand-primary/10 mix-blend-multiply z-10 group-hover:opacity-0 transition-opacity duration-500"></div>
                  <img 
                    src={video.thumbnail} 
                    alt={video.title} 
                    className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                  />
                  
                  {/* Play Button Overlay */}
                  <div className="absolute inset-0 z-20 flex items-center justify-center bg-black/10 group-hover:bg-brand-primary/20 transition-colors duration-300">
                    <div className="w-14 h-14 bg-white/30 backdrop-blur-sm rounded-full flex items-center justify-center group-hover:scale-110 transition-transform duration-300 shadow-xl">
                       <div className="w-10 h-10 bg-white rounded-full flex items-center justify-center shadow-lg group-hover:bg-sky-500 transition-colors duration-300">
                          <Play className="w-4 h-4 text-brand-primary fill-brand-primary group-hover:text-white group-hover:fill-white transition-colors duration-300 ml-1" />
                       </div>
                    </div>
                  </div>
                  
                  {/* Duration Badge */}
                  <div className="absolute bottom-3 right-3 z-30 px-2 py-1 bg-black/70 backdrop-blur-md rounded-md text-white text-xs font-bold">
                    {video.duration}
                  </div>
                </div>

                {/* Content */}
                <div className="p-6 flex flex-col flex-grow justify-between relative z-10 bg-transparent">
                  <h3 className="font-display font-bold text-lg text-brand-dark mb-4 group-hover:text-sky-700 transition-colors">
                    "{video.title}"
                  </h3>
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full overflow-hidden bg-slate-100 flex-shrink-0 group-hover:ring-2 ring-sky-500 transition-all">
                       <img src={video.avatar} alt={video.name} className="w-full h-full object-cover" />
                    </div>
                    <div>
                      <p className="text-sm font-bold text-slate-800 group-hover:text-sky-800 transition-colors">{video.name}</p>
                      <p className="text-xs text-slate-500 group-hover:text-sky-600 transition-colors">{video.role}</p>
                    </div>
                  </div>
                </div>
              </a>
            </motion.div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
