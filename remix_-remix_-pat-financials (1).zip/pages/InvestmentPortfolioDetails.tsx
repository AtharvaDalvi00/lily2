import React, { useEffect } from 'react';
import { ScrollReveal } from '../components/ui/ScrollReveal';
import { Link } from 'react-router-dom';
import { PieChart as PieChartIcon, LineChart, Briefcase, ArrowLeft } from 'lucide-react';
import { ContactCTA } from '../components/ContactCTA';

export const InvestmentPortfolioDetails: React.FC = () => {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  return (
    <>
      <ScrollReveal>
      <section className="py-20 bg-brand-light relative overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img src="https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?w=1600&q=80" alt="Background" className="w-full h-full object-cover opacity-[0.06] mix-blend-multiply" />
        </div>
        <div className="absolute top-0 right-0 w-64 h-64 bg-brand-primary/10 rounded-full blur-3xl"></div>
        <div className="absolute bottom-0 left-0 w-64 h-64 bg-brand-secondary/10 rounded-full blur-3xl"></div>
        
        <div className="container mx-auto px-4 md:px-6 relative z-10 text-center max-w-4xl pt-16">
          
          <Link to="/" className="inline-flex items-center gap-2 px-4 py-2 bg-white/50 hover:bg-white text-brand-primary font-medium rounded-full mb-8 backdrop-blur-sm border border-slate-200/50 hover:border-brand-primary/30 transition-all shadow-sm hover:shadow-md group">
            <ArrowLeft className="w-4 h-4 group-hover:-translate-x-1 transition-transform" /> Back to Home
          </Link>
          <h1 className="text-5xl md:text-6xl font-display font-bold text-brand-dark mb-6">Investment Portfolio</h1>
          <p className="text-xl text-slate-600 mb-8 leading-relaxed">
            Diversified baskets of equity, debt, and gold. We construct robust portfolios tailored to outpace inflation and build substantial wealth.
          </p>
        </div>
      </section>
      </ScrollReveal>

      <ScrollReveal>
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4 md:px-6 max-w-4xl">
          <div className="pred pred-lg pred-slate max-w-none text-slate-600 space-y-6">
            <h2 className="text-3xl font-display font-bold text-brand-dark">Why Do You Need an Investment Portfolio?</h2>
            <p>
              Saving alone is not enough to beat the erosive effects of inflation. A well-constructed investment portfolio allocates your capital across various asset classes to optimize returns while managing risk. It is the engine that drives your money to work for you, compounding over time to create long-lasting wealth.
            </p>
            
            <h3 className="text-2xl font-display font-bold text-brand-dark mt-12 mb-4">Our Approach</h3>
            
            <div className="grid md:grid-cols-3 gap-8 my-8">
              <div className="bg-slate-50 p-6 rounded-2xl border border-slate-100 shadow-sm">
                <Briefcase className="w-10 h-10 text-brand-primary mb-4" />
                <h4 className="text-lg font-bold text-brand-dark mb-2">Asset Allocation</h4>
                <p className="text-sm">We dynamically balance your funds across equity for growth, debt for stability, and commodities like gold for a hedge against inflation.</p>
              </div>
              
              <div className="bg-slate-50 p-6 rounded-2xl border border-slate-100 shadow-sm">
                <PieChartIcon className="w-10 h-10 text-brand-primary mb-4" />
                <h4 className="text-lg font-bold text-brand-dark mb-2">Diversification</h4>
                <p className="text-sm">We spread investments across sectors and geographies to mitigate risk and capture broader market opportunities.</p>
              </div>
              
              <div className="bg-slate-50 p-6 rounded-2xl border border-slate-100 shadow-sm">
                <LineChart className="w-10 h-10 text-brand-primary mb-4" />
                <h4 className="text-lg font-bold text-brand-dark mb-2">Continuous Review</h4>
                <p className="text-sm">Portfolios are actively tracked and rebalanced periodically to ensure they remain aligned with your evolving risk appetite and market realities.</p>
              </div>
            </div>

            <h3 className="text-2xl font-display font-bold text-brand-dark mt-12 mb-4">The Result</h3>
            <p>
              You possess a transparent, resilient, and high-performing asset base that compounds reliably. We remove the emotional biases from investing, providing disciplined execution that turns your dreams into tangible financial achievements.
            </p>
          </div>
        </div>
      </section>
      </ScrollReveal>
      
      <ContactCTA />
    </>
  );
};
