import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, RefreshCw, Calculator, TrendingUp, Landmark, Calendar, ChevronRight, HelpCircle, ArrowUpRight, Check, DollarSign, Download } from 'lucide-react';
import { LeadFormModal } from './LeadFormModal';

interface TenureIncreaseCalculatorProps {
  isOpen: boolean;
  onClose: () => void;
}

interface AmortizationRow {
  month: number;
  case1Emi: number;
  case1Interest: number;
  case1Principal: number;
  case1Outstanding: number;
  case1CumInterest: number;
  case2Emi: number;
  case2Interest: number;
  case2Principal: number;
  case2Outstanding: number;
  case2CumInterest: number;
  sipAmount: number;
  sipWealth: number;
  canRepay: boolean;
}

export const TenureIncreaseCalculator: React.FC<TenureIncreaseCalculatorProps> = ({ isOpen, onClose }) => {
  // Input parameters
  const [loanAmount, setLoanAmount] = useState<number>(10000000); // 1 Crore default
  const [interestRate, setInterestRate] = useState<number>(7.50); // 7.5% default
  const [origTenureYears, setOrigTenureYears] = useState<number>(15); // 15 years original
  const [monthsPaid, setMonthsPaid] = useState<number>(24); // 24 months paid so far
  const [newTenureYears, setNewTenureYears] = useState<number>(25); // 25 years new tenure
  const [sipReturnRate, setSipReturnRate] = useState<number>(12.00); // 12% expected SIP return

  // Computed summary metrics
  const [origEmi, setOrigEmi] = useState<number>(0);
  const [principalOS, setPrincipalOS] = useState<number>(0);
  const [balanceTenureMonths, setBalanceTenureMonths] = useState<number>(0);
  const [modifiedEmi, setModifiedEmi] = useState<number>(0);
  const [sipAmount, setSipAmount] = useState<number>(0);
  const [sipTenureMonths, setSipTenureMonths] = useState<number>(0);
  
  // Comparative Results
  const [schedule, setSchedule] = useState<AmortizationRow[]>([]);
  const [repayMonthIndex, setRepayMonthIndex] = useState<number>(-1);
  const [case2OSAtEnd, setCase2OSAtEnd] = useState<number>(0);
  const [sipWealthAtEnd, setSipWealthAtEnd] = useState<number>(0);
  const [netWealthAtEnd, setNetWealthAtEnd] = useState<number>(0);
  const [case1TotalInterest, setCase1TotalInterest] = useState<number>(0);
  const [case2TotalInterest, setCase2TotalInterest] = useState<number>(0);

  const formURL = "https://task-flow-pro-23-01.vercel.app/#/p/b8241986-9abe-4e33-974b-63f48dfcf893";
  const [isFormOpened, setIsFormOpened] = useState(false);
  const [isFormModalOpen, setIsFormModalOpen] = useState(false);

  // Format currency in Indian standard format (Lakhs/Crores)
  const formatCurrency = (val: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0,
    }).format(val);
  };

  const formatMonthsToYrs = (totalMonths: number) => {
    if (totalMonths <= 0) return 'N/A';
    const yrs = Math.floor(totalMonths / 12);
    const mths = totalMonths % 12;
    return `${yrs} Yrs${mths > 0 ? ` ${mths} mth` : ''}`;
  };

  const exportToExcel = () => {
    if (schedule.length === 0) return;

    const formatNumber = (val: number) => {
      return new Intl.NumberFormat('en-IN', {
        maximumFractionDigits: 2
      }).format(val);
    };

    const htmlContent = `
<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40">
<head>
<!--[if gte mso 9]>
<xml>
<x:ExcelWorkbook>
<x:ExcelWorksheets>
<x:ExcelWorksheet>
<x:Name>Early Loan Closure Plan</x:Name>
<x:WorksheetOptions>
<x:DisplayGridlines/>
<x:ProtectContents>True</x:ProtectContents>
</x:WorksheetOptions>
</x:ExcelWorksheet>
</x:ExcelWorksheets>
</x:ExcelWorkbook>
</xml>
<![endif]-->
<meta charset="utf-8">
<style>
  table { border-collapse: collapse; font-family: 'Segoe UI', Arial, sans-serif; }
  th, td { border: 1px solid #CBD5E1; padding: 8px; font-size: 10pt; mso-protection: locked hidden; }
  
  .title-cell { font-size: 16pt; font-weight: bold; color: #FFFFFF; background-color: #0F172A; padding: 15px; border: none; text-align: center; mso-protection: locked hidden; }
  
  .section-header { background-color: #2563EB; color: #FFFFFF; font-weight: bold; font-size: 11pt; text-align: left; padding: 8px; mso-protection: locked hidden; }
  .grid-header { background-color: #1E293B; color: #FFFFFF; font-weight: bold; font-size: 10pt; text-align: center; mso-protection: locked hidden; }
  
  .label-cell { color: #334155; font-weight: 500; background-color: #F8FAFC; mso-protection: locked hidden; }
  .value-cell { text-align: right; font-weight: bold; color: #020617; mso-protection: locked hidden; }
  .input-cell { text-align: right; font-weight: bold; color: #020617; background-color: #FFFFD0; mso-protection: unlocked; border: 1px solid #94A3B8; }
  
  .result-label { font-weight: bold; color: #1D4ED8; background-color: #EFF6FF; border: 1px solid #BFDBFE; mso-protection: locked hidden; }
  .result-value { font-weight: bold; color: #1D4ED8; background-color: #DBEAFE; text-align: right; border: 1px solid #BFDBFE; mso-protection: locked hidden; }
  
  .result-label-success { font-weight: bold; color: #075985; background-color: #F0F9FF; border: 1px solid #BAE6FD; mso-protection: locked hidden; }
  .result-value-success { font-weight: bold; color: #075985; background-color: #E0F2FE; text-align: right; border: 1px solid #BAE6FD; mso-protection: locked hidden; }

  .schedule-row-even { background-color: #F8FAFC; }
  .schedule-row-odd { background-color: #FFFFFF; }
  
  .currency-cell { text-align: right; mso-protection: locked hidden; }
  .center-cell { text-align: center; mso-protection: locked hidden; }
  .empty-cell { background-color: #FFFFFF; border: none; mso-protection: locked hidden; }
</style>
</head>
<body>
  <table>
    <tr>
      <td class="title-cell" colspan="10">PAT FINANCIALS - EARLY LOAN CLOSURE &amp; WEALTH REPORT</td>
    </tr>
    <tr><td colspan="10" style="border: none; height: 10px;"></td></tr>

    <tr><td class="section-header" colspan="10">LOAN &amp; INVESTMENT INPUTS</td></tr>
    <tr>
      <td class="label-cell" colspan="3">Original Loan Amount</td>
      <td class="input-cell" colspan="2">${loanAmount}</td>
      <td class="empty-cell" style="border: none;"></td>
      <td class="label-cell" colspan="2">Loan Interest Rate (p.a.)</td>
      <td class="input-cell" colspan="2">${interestRate}</td>
    </tr>
    <tr>
      <td class="label-cell" colspan="3">Original Loan Tenure</td>
      <td class="input-cell" colspan="2">${origTenureYears}</td>
      <td class="empty-cell" style="border: none;"></td>
      <td class="label-cell" colspan="2">EMI Paid So Far</td>
      <td class="input-cell" colspan="2">${monthsPaid}</td>
    </tr>
    <tr>
      <td class="label-cell" colspan="3">New Loan Tenure</td>
      <td class="input-cell" colspan="2">${newTenureYears}</td>
      <td class="empty-cell" style="border: none;"></td>
      <td class="label-cell" colspan="2">Expected SIP Return</td>
      <td class="input-cell" colspan="2">${sipReturnRate}</td>
    </tr>
    <tr>
      <td class="label-cell" colspan="3">Monthly Loan Rate</td>
      <td class="value-cell" colspan="2" style="color: #2563EB;">=I4/12/100</td>
      <td class="empty-cell" style="border: none;"></td>
      <td class="label-cell" colspan="2">Monthly SIP Return Rate</td>
      <td class="value-cell" colspan="2" style="color: #2563EB;">=(1+I6/100)^(1/12)-1</td>
    </tr>
    <tr>
      <td class="label-cell" colspan="3">Original EMI (Case 1)</td>
      <td class="value-cell" colspan="2" style="color: #2563EB;">=ROUND(PMT(D7, D5*12, -D4), 0)</td>
      <td class="empty-cell" style="border: none;"></td>
      <td class="label-cell" colspan="2">Lowered EMI (Case 2)</td>
      <td class="value-cell" colspan="2" style="color: #2563EB;">=ROUND(PMT(D7, (D6*12)-I5, -D9), 0)</td>
    </tr>
    <tr>
      <td class="label-cell" colspan="3">Principal OS after Months Paid</td>
      <td class="value-cell" colspan="2" style="color: #2563EB;">=ROUND(PV(D7, D5*12-I5, -D8), 0)</td>
      <td class="empty-cell" style="border: none;"></td>
      <td class="label-cell" colspan="2">Monthly SIP Investment Amount</td>
      <td class="value-cell" colspan="2" style="color: #2563EB;">=MAX(0, D8-I8)</td>
    </tr>

    <tr><td colspan="10" style="border: none; height: 15px;"></td></tr>

    <tr><td class="section-header" colspan="10">KEY METRICS &amp; COMPARISON SUMMARY (LIVE FORMULAS)</td></tr>
    <tr>
      <td class="result-label-success" colspan="5">REPAY LOAN IN FULL (VIA SIP WEALTH) IN (Months from Now)</td>
      <td class="result-value-success" colspan="5">=MATCH("YES", J19:J${18 + schedule.length}, 0)</td>
    </tr>
    <tr>
      <td class="result-label" colspan="5">SIP Wealth (At original loan end)</td>
      <td class="result-value" colspan="5">=INDEX(I19:I${18 + schedule.length}, D5*12-I5)</td>
    </tr>
    <tr>
      <td class="result-label" colspan="5">Net Surplus Legacy Wealth (After full repayment)</td>
      <td class="result-value" colspan="5">=MAX(0, F13 - INDEX(G19:G${18 + schedule.length}, D5*12-I5))</td>
    </tr>

    <tr><td colspan="10" style="border: none; height: 15px;"></td></tr>

    <tr><td class="section-header" colspan="10">MONTHLY COMPARATIVE SCHEDULE</td></tr>
    <tr>
      <td class="grid-header" rowspan="2">Month</td>
      <td class="grid-header" colspan="3">Case 1: Retaining original tenure</td>
      <td class="grid-header" colspan="3">Case 2: Extending Tenure + SIP</td>
      <td class="grid-header" colspan="3">Monthly Systematic Investment (SIP)</td>
    </tr>
    <tr>
      <td class="grid-header">EMI</td>
      <td class="grid-header">Interest</td>
      <td class="grid-header">Outstanding</td>
      <td class="grid-header">EMI</td>
      <td class="grid-header">Interest</td>
      <td class="grid-header">Outstanding</td>
      <td class="grid-header">SIP Saving</td>
      <td class="grid-header">SIP Wealth</td>
      <td class="grid-header">Repay Loan?</td>
    </tr>
    ${schedule.map((row, idx) => {
      const rowClass = idx % 2 === 0 ? 'schedule-row-even' : 'schedule-row-odd';
      const r = 19 + idx; // Excel row index
      const c1InterestFormula = idx === 0 ? '=IF($D$9>0, ROUND($D$9*$D$7, 2), 0)' : `=IF(D${r - 1}>0, ROUND(D${r - 1}*$D$7, 2), 0)`;
      const c1OutstandingFormula = idx === 0 ? '=IF($D$9>0, MAX(0, ROUND($D$9-(B19-C19), 2)), 0)' : `=IF(D${r - 1}>0, MAX(0, ROUND(D${r - 1}-(B${r}-C${r}), 2)), 0)`;
      
      const c2InterestFormula = idx === 0 ? '=IF($D$9>0, ROUND($D$9*$D$7, 2), 0)' : `=IF(G${r - 1}>0, ROUND(G${r - 1}*$D$7, 2), 0)`;
      const c2OutstandingFormula = idx === 0 ? '=IF($D$9>0, MAX(0, ROUND($D$9-(E19-F19), 2)), 0)' : `=IF(G${r - 1}>0, MAX(0, ROUND(G${r - 1}-(E${r}-F${r}), 2)), 0)`;
      
      const sipWealthFormula = idx === 0 ? '=ROUND(H19*(1+$I$7), 2)' : `=ROUND((I${r - 1}+H${r})*(1+$I$7), 2)`;
      return `
      <tr class="${rowClass}">
        <td class="center-cell">${row.month}</td>
        <td class="currency-cell">=IF(A${r}<=($D$5*12-$I$5), $D$8, 0)</td>
        <td class="currency-cell">${c1InterestFormula}</td>
        <td class="currency-cell">${c1OutstandingFormula}</td>
        <td class="currency-cell">=IF(A${r}<=($D$6*12-$I$5), $I$8, 0)</td>
        <td class="currency-cell">${c2InterestFormula}</td>
        <td class="currency-cell" style="font-weight: bold;">${c2OutstandingFormula}</td>
        <td class="currency-cell" style="color: #2563EB;">=IF(A${r}<=($D$5*12-$I$5), $I$9, 0)</td>
        <td class="currency-cell" style="font-weight: bold; color: #0284C7;">${sipWealthFormula}</td>
        <td class="center-cell" style="font-weight: bold; color: #0284C7;">=IF(I${r}>=G${r}, "YES", "NO")</td>
      </tr>
      `;
    }).join('')}
  </table>
</body>
</html>
`;

    const blob = new Blob([htmlContent], { type: 'application/vnd.ms-excel;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `early_loan_closure_report_${new Date().toISOString().split('T')[0]}.xls`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const calculate = () => {
    const r_loan = (interestRate / 100) / 12;
    const n_orig = origTenureYears * 12;

    // 1. Original EMI
    const computedOrigEmi = loanAmount * (r_loan * Math.pow(1 + r_loan, n_orig)) / (Math.pow(1 + r_loan, n_orig) - 1);
    setOrigEmi(computedOrigEmi);

    // 2. Principal Outstanding after monthsPaid
    let currentBalance = loanAmount;
    let originalCumInterest = 0;
    for (let m = 1; m <= monthsPaid; m++) {
      const interest = currentBalance * r_loan;
      const principal = computedOrigEmi - interest;
      originalCumInterest += interest;
      currentBalance = Math.max(0, currentBalance - principal);
    }
    const computedPrincipalOS = currentBalance;
    setPrincipalOS(computedPrincipalOS);

    // 3. Balance Tenure Months
    const computedBalanceTenureMonths = (newTenureYears * 12) - monthsPaid;
    setBalanceTenureMonths(computedBalanceTenureMonths);

    // 4. Modified EMI (Based on Principal Outstanding, remaining balance tenure, and same loan rate)
    const computedModifiedEmi = computedPrincipalOS * (r_loan * Math.pow(1 + r_loan, computedBalanceTenureMonths)) / (Math.pow(1 + r_loan, computedBalanceTenureMonths) - 1);
    setModifiedEmi(computedModifiedEmi);

    // 5. Saving in EMI / Monthly SIP Amount
    const computedSipAmount = Math.max(0, computedOrigEmi - computedModifiedEmi);
    setSipAmount(computedSipAmount);

    // 6. SIP Tenure Months (A * 12 - B)
    const computedSipTenureMonths = (origTenureYears * 12) - monthsPaid;
    setSipTenureMonths(computedSipTenureMonths);

    // 7. Expected Monthly SIP return
    const r_sip = Math.pow(1 + sipReturnRate / 100, 1 / 12) - 1;

    // 8. Generate comparative schedules
    const newSchedule: AmortizationRow[] = [];
    let case1OS = computedPrincipalOS;
    let case2OS = computedPrincipalOS;
    let case1RunningInterest = 0;
    let case2RunningInterest = 0;
    let currentSipWealth = 0;
    let firstRepayMonth = -1;

    // Max duration is the longer of the two remaining tenures
    const maxMonths = Math.max(computedSipTenureMonths, computedBalanceTenureMonths);

    for (let m = 1; m <= maxMonths; m++) {
      // Case 1
      let c1Emi = 0;
      let c1Interest = 0;
      let c1Principal = 0;
      if (m <= computedSipTenureMonths && case1OS > 0) {
        c1Emi = computedOrigEmi;
        c1Interest = case1OS * r_loan;
        c1Principal = Math.min(case1OS, c1Emi - c1Interest);
        case1OS = Math.max(0, case1OS - c1Principal);
        case1RunningInterest += c1Interest;
      }

      // Case 2
      let c2Emi = 0;
      let c2Interest = 0;
      let c2Principal = 0;
      if (m <= computedBalanceTenureMonths && case2OS > 0) {
        c2Emi = computedModifiedEmi;
        c2Interest = case2OS * r_loan;
        c2Principal = Math.min(case2OS, c2Emi - c2Interest);
        case2OS = Math.max(0, case2OS - c2Principal);
        case2RunningInterest += c2Interest;
      }

      // SIP Accumulation
      let currentSip = 0;
      if (m <= computedSipTenureMonths) {
        currentSip = computedSipAmount;
      }
      currentSipWealth = (currentSipWealth + currentSip) * (1 + r_sip);

      // Check if user can repay remaining loan with SIP wealth
      const canRepay = currentSipWealth >= case2OS;
      if (canRepay && firstRepayMonth === -1) {
        firstRepayMonth = m;
      }

      newSchedule.push({
        month: m,
        case1Emi: c1Emi,
        case1Interest: c1Interest,
        case1Principal: c1Principal,
        case1Outstanding: case1OS,
        case1CumInterest: case1RunningInterest,
        case2Emi: c2Emi,
        case2Interest: c2Interest,
        case2Principal: c2Principal,
        case2Outstanding: case2OS,
        case2CumInterest: case2RunningInterest,
        sipAmount: currentSip,
        sipWealth: currentSipWealth,
        canRepay: canRepay,
      });
    }

    setSchedule(newSchedule);
    setRepayMonthIndex(firstRepayMonth);

    // Read the values at the end of original tenure (which is computedSipTenureMonths index)
    const endRow = newSchedule[computedSipTenureMonths - 1];
    if (endRow) {
      setCase2OSAtEnd(endRow.case2Outstanding);
      setSipWealthAtEnd(endRow.sipWealth);
      setNetWealthAtEnd(endRow.sipWealth - endRow.case2Outstanding);
    }

    setCase1TotalInterest(case1RunningInterest);
    setCase2TotalInterest(case2RunningInterest);
  };

  useEffect(() => {
    if (isOpen) {
      calculate();
    }
  }, [loanAmount, interestRate, origTenureYears, monthsPaid, newTenureYears, sipReturnRate, isOpen]);

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-[9999] flex items-center justify-center bg-slate-900/40 p-4 sm:p-6"
        >
          {/* Backdrop Blur */}
          <div 
            className="absolute inset-0 bg-slate-900/40 pointer-events-auto" 
            onClick={onClose} 
            style={{ backdropFilter: 'blur(16px)', WebkitBackdropFilter: 'blur(16px)' }}
          />

          <motion.div
            initial={{ scale: 0.95, y: 20 }}
            animate={{ scale: 1, y: 0 }}
            exit={{ scale: 0.95, y: 20 }}
            className="relative bg-white/80 backdrop-blur-xl w-full max-w-7xl h-[92vh] flex flex-col overflow-hidden rounded-3xl shadow-2xl border border-white/50"
            style={{ backdropFilter: 'blur(30px)', WebkitBackdropFilter: 'blur(30px)' }}
          >
            {/* Header */}
        <div className="flex flex-wrap items-center justify-between p-6 bg-brand-primary text-white border-b border-white/20 gap-4 shrink-0">
          <div className="flex items-center gap-3">
            <div className="bg-white/20 p-2.5 rounded-xl">
              <Landmark className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-xl font-bold tracking-tight">Early Loan Closure & Wealth Builder</h2>
              <p className="text-xs text-blue-100">Create substantial passive wealth by extending loan tenure and investing the EMI savings</p>
            </div>
          </div>
          <div className="flex items-center gap-3 ml-auto">
            <button
              onClick={() => {
                if (!isFormOpened) {
                  setIsFormModalOpen(true);
                } else {
                  exportToExcel();
                }
              }}
              className={`flex items-center gap-2 ${isFormOpened ? 'bg-sky-600 hover:bg-sky-700' : 'bg-[#3B82F6] hover:bg-[#1D4ED8]'} text-white px-4 py-2 rounded-xl transition-colors font-semibold text-sm shadow-sm`}
            >
              <Download className="w-4 h-4" />
              {isFormOpened ? 'Download Excel Sheet' : 'Fill Form & Download'}
            </button>
            <LeadFormModal
              isOpen={isFormModalOpen}
              onClose={() => setIsFormModalOpen(false)}
              onSubmitAndDownload={() => {
                setIsFormOpened(true);
                setIsFormModalOpen(false);
                exportToExcel();
              }}
            />
            <button onClick={onClose} className="p-2.5 bg-white/10 hover:bg-white/20 rounded-xl transition-colors text-white">
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>
        {/* Split Panels */}
            <div className="flex-1 flex flex-col lg:flex-row overflow-hidden">
              {/* Inputs Panel (Left) */}
              <div 
                data-lenis-prevent="true" 
                className="w-full lg:w-1/3 p-6 bg-slate-50/50 border-r border-slate-200/50 overflow-y-auto"
                style={{ backdropFilter: 'blur(10px)', WebkitBackdropFilter: 'blur(10px)' }}
              >
                <div className="space-y-6">
                  <div>
                    <h3 className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-4">Investment & Loan Parameters</h3>
                  </div>

                  {/* 1. Original Loan Amount */}
                  <div className="bg-white/70 p-4 rounded-2xl border border-slate-200/40 shadow-sm space-y-2">
                    <div className="flex justify-between items-center text-sm">
                      <span className="font-semibold text-slate-700">Original Loan Amount</span>
                      <span className="text-brand-primary font-bold">{formatCurrency(loanAmount)}</span>
                    </div>
                    <input
                      type="range"
                      min={1000000}
                      max={50000000}
                      step={50000}
                      value={loanAmount}
                      onChange={(e) => setLoanAmount(Number(e.target.value))}
                      className="w-full h-1.5 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-brand-primary"
                    />
                    <div className="flex items-center bg-slate-100/60 rounded-xl px-3 py-1.5">
                      <span className="text-xs font-semibold text-slate-500 mr-2">₹</span>
                      <input
                        type="number"
                        value={loanAmount}
                        onChange={(e) => setLoanAmount(Math.max(0, Number(e.target.value)))}
                        className="w-full bg-transparent text-sm font-semibold text-slate-800 outline-none"
                      />
                    </div>
                  </div>

                  {/* 2. Loan Interest Rate */}
                  <div className="bg-white/70 p-4 rounded-2xl border border-slate-200/40 shadow-sm space-y-2">
                    <div className="flex justify-between items-center text-sm">
                      <span className="font-semibold text-slate-700">Loan Interest Rate (p.a.)</span>
                      <span className="text-brand-primary font-bold">{interestRate}%</span>
                    </div>
                    <input
                      type="range"
                      min={5.0}
                      max={18.0}
                      step={0.05}
                      value={interestRate}
                      onChange={(e) => setInterestRate(Number(e.target.value))}
                      className="w-full h-1.5 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-brand-primary"
                    />
                    <div className="flex items-center bg-slate-100/60 rounded-xl px-3 py-1.5">
                      <input
                        type="number"
                        step={0.05}
                        value={interestRate}
                        onChange={(e) => setInterestRate(Math.max(1, Number(e.target.value)))}
                        className="w-full bg-transparent text-sm font-semibold text-slate-800 outline-none"
                      />
                      <span className="text-xs font-semibold text-slate-500">%</span>
                    </div>
                  </div>

                  {/* 3. Original Loan Tenure */}
                  <div className="bg-white/70 p-4 rounded-2xl border border-slate-200/40 shadow-sm space-y-2">
                    <div className="flex justify-between items-center text-sm">
                      <span className="font-semibold text-slate-700">Original Tenure (Years)</span>
                      <span className="text-brand-primary font-bold">{origTenureYears} Years</span>
                    </div>
                    <input
                      type="range"
                      min={5}
                      max={30}
                      value={origTenureYears}
                      onChange={(e) => setOrigTenureYears(Number(e.target.value))}
                      className="w-full h-1.5 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-brand-primary"
                    />
                    <div className="flex items-center bg-slate-100/60 rounded-xl px-3 py-1.5">
                      <input
                        type="number"
                        value={origTenureYears}
                        onChange={(e) => setOrigTenureYears(Math.max(1, Number(e.target.value)))}
                        className="w-full bg-transparent text-sm font-semibold text-slate-800 outline-none"
                      />
                      <span className="text-xs font-semibold text-slate-500">Yrs</span>
                    </div>
                  </div>

                  {/* 4. Months Paid So Far */}
                  <div className="bg-white/70 p-4 rounded-2xl border border-slate-200/40 shadow-sm space-y-2">
                    <div className="flex justify-between items-center text-sm">
                      <span className="font-semibold text-slate-700">EMI Paid So Far</span>
                      <span className="text-brand-primary font-bold">{monthsPaid} Months</span>
                    </div>
                    <input
                      type="range"
                      min={0}
                      max={origTenureYears * 12 - 1}
                      value={monthsPaid}
                      onChange={(e) => setMonthsPaid(Number(e.target.value))}
                      className="w-full h-1.5 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-brand-primary"
                    />
                    <div className="flex items-center bg-slate-100/60 rounded-xl px-3 py-1.5">
                      <input
                        type="number"
                        value={monthsPaid}
                        onChange={(e) => setMonthsPaid(Math.max(0, Math.min(origTenureYears * 12 - 1, Number(e.target.value))))}
                        className="w-full bg-transparent text-sm font-semibold text-slate-800 outline-none"
                      />
                      <span className="text-xs font-semibold text-slate-500">Months</span>
                    </div>
                  </div>

                  {/* 5. New Loan Tenure */}
                  <div className="bg-white/70 p-4 rounded-2xl border border-slate-200/40 shadow-sm space-y-2">
                    <div className="flex justify-between items-center text-sm">
                      <span className="font-semibold text-slate-700">New Tenure (Years)</span>
                      <span className="text-brand-primary font-bold">{newTenureYears} Years</span>
                    </div>
                    <input
                      type="range"
                      min={Math.ceil(monthsPaid / 12) + 1}
                      max={40}
                      value={newTenureYears}
                      onChange={(e) => setNewTenureYears(Number(e.target.value))}
                      className="w-full h-1.5 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-brand-primary"
                    />
                    <div className="flex items-center bg-slate-100/60 rounded-xl px-3 py-1.5">
                      <input
                        type="number"
                        value={newTenureYears}
                        onChange={(e) => setNewTenureYears(Math.max(Math.ceil(monthsPaid / 12) + 1, Number(e.target.value)))}
                        className="w-full bg-transparent text-sm font-semibold text-slate-800 outline-none"
                      />
                      <span className="text-xs font-semibold text-slate-500">Yrs</span>
                    </div>
                  </div>

                  {/* 6. Expected SIP Return Rate */}
                  <div className="bg-white/70 p-4 rounded-2xl border border-slate-200/40 shadow-sm space-y-2">
                    <div className="flex justify-between items-center text-sm">
                      <span className="font-semibold text-slate-700">Expected SIP Return</span>
                      <span className="text-brand-primary font-bold">{sipReturnRate}%</span>
                    </div>
                    <input
                      type="range"
                      min={5.0}
                      max={22.0}
                      step={0.1}
                      value={sipReturnRate}
                      onChange={(e) => setSipReturnRate(Number(e.target.value))}
                      className="w-full h-1.5 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-brand-primary"
                    />
                    <div className="flex items-center bg-slate-100/60 rounded-xl px-3 py-1.5">
                      <input
                        type="number"
                        step={0.1}
                        value={sipReturnRate}
                        onChange={(e) => setSipReturnRate(Math.max(1, Number(e.target.value)))}
                        className="w-full bg-transparent text-sm font-semibold text-slate-800 outline-none"
                      />
                      <span className="text-xs font-semibold text-slate-500">%</span>
                    </div>
                  </div>

                  <button 
                    onClick={() => {
                      setLoanAmount(10000000);
                      setInterestRate(7.50);
                      setOrigTenureYears(15);
                      setMonthsPaid(24);
                      setNewTenureYears(25);
                      setSipReturnRate(12.00);
                    }}
                    className="w-full flex items-center justify-center gap-2 px-4 py-3 text-xs font-semibold text-slate-600 hover:text-brand-primary hover:border-brand-primary transition-colors bg-white border border-slate-200 rounded-xl shadow-sm"
                  >
                    <RefreshCw className="w-3.5 h-3.5" /> Reset Default Values
                  </button>
                </div>
              </div>

              {/* Outputs Panel (Right) */}
              <div className="w-full lg:w-2/3 flex flex-col bg-white">
                {/* Header info */}
                <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between gap-4">
                  <div>
                    <h4 className="text-sm font-bold text-slate-700">Home Loan - Early Closure Strategy</h4>
                  </div>

                  <div className="text-right hidden sm:block">
                    <span className="text-xs text-slate-400 font-semibold block">PRINCIPAL OUTSTANDING</span>
                    <span className="text-sm font-extrabold text-slate-700">{formatCurrency(principalOS)}</span>
                  </div>
                </div>

                <div className="flex-1 overflow-y-auto p-6" data-lenis-prevent="true">
                  <div className="space-y-6">
                      {/* Top Highlights Banner */}
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200/50">
                          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-1">ORIGINAL EMI</span>
                          <span className="text-lg font-extrabold text-slate-800">{formatCurrency(origEmi)}</span>
                        </div>
                        <div className="bg-blue-50/50 p-4 rounded-2xl border border-blue-100/50">
                          <span className="text-[10px] font-bold text-blue-500 uppercase tracking-widest block mb-1">MODIFIED LOWER EMI</span>
                          <span className="text-lg font-extrabold text-blue-700">{formatCurrency(modifiedEmi)}</span>
                        </div>
                        <div className="bg-sky-50 p-4 rounded-2xl border border-sky-200/50">
                          <span className="text-[10px] font-bold text-sky-500 uppercase tracking-widest block mb-1">MONTHLY SIP SAVING</span>
                          <span className="text-lg font-extrabold text-sky-700">{formatCurrency(sipAmount)}</span>
                        </div>
                      </div>

                      {/* Strategic Repayment Outcome Box */}
                      <div className="bg-gradient-to-r from-sky-500/10 to-sky-50 border border-sky-200 p-6 rounded-3xl space-y-4">
                        <div className="flex items-start justify-between">
                          <div>
                            <span className="bg-sky-500 text-white text-[10px] font-extrabold uppercase px-2 py-0.5 rounded-full tracking-widest">TENURE REDUCTION INSIGHT</span>
                            <h4 className="text-xl font-extrabold text-sky-950 mt-2">Repay Loan Early & Build Legacy Wealth</h4>
                            <p className="text-xs text-sky-800/80 mt-1">Instead of paying for {newTenureYears} years, your accumulated SIP wealth allows you to liquidate the entire loan much sooner!</p>
                          </div>
                          <div className="p-3 bg-sky-500 text-white rounded-2xl shadow-lg hidden sm:block">
                            <TrendingUp className="w-6 h-6" />
                          </div>
                        </div>

                        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4 pt-2">
                          <div className="bg-white/75 p-4 rounded-2xl border border-sky-200/50 shadow-sm">
                            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">REPAY FULL LOAN IN</span>
                            <span className="text-2xl font-black text-brand-primary block mt-1">{formatMonthsToYrs(repayMonthIndex + monthsPaid)}</span>
                            <span className="text-[10px] text-slate-500 font-medium block mt-1">Saving {formatMonthsToYrs((newTenureYears * 12) - (repayMonthIndex + monthsPaid))} of payments</span>
                          </div>

                          <div className="bg-white/75 p-4 rounded-2xl border border-sky-200/50 shadow-sm">
                            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">SIP WEALTH AT YEAR 15</span>
                            <span className="text-2xl font-black text-sky-600 block mt-1">{formatCurrency(sipWealthAtEnd)}</span>
                            <span className="text-[10px] text-slate-500 font-medium block mt-1">Invested: {formatCurrency(sipAmount * sipTenureMonths)}</span>
                          </div>

                          <div className="bg-white/75 p-4 rounded-2xl border border-sky-200/50 shadow-sm sm:col-span-2 md:col-span-1">
                            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">NET SURPLUS WEALTH</span>
                            <span className="text-2xl font-black text-blue-700 block mt-1">{netWealthAtEnd < 0 ? '₹0' : formatCurrency(netWealthAtEnd)}</span>
                            <span className="text-[10px] text-slate-500 font-medium block mt-1">After paying off loan at Year {origTenureYears}</span>
                          </div>
                        </div>
                      </div>

                      {/* Cash-Flow Comparison Grid */}
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-2">
                        {/* Case 1: Keeping 15-Year original tenure */}
                        <div className="bg-white p-5 rounded-2xl border border-slate-200/70 shadow-sm space-y-4">
                          <div className="flex items-center justify-between pb-2 border-b border-slate-100">
                            <h5 className="font-bold text-slate-700 text-sm">Case 1: Retaining {origTenureYears} Year Tenure</h5>
                            <span className="text-xs bg-slate-100 px-2.5 py-1 rounded-full text-slate-600 font-semibold">Standard Plan</span>
                          </div>
                          
                          <div className="space-y-3 text-xs">
                            <div className="flex justify-between">
                              <span className="text-slate-500">Remaining Loan Period:</span>
                              <span className="font-semibold text-slate-800">{formatMonthsToYrs(sipTenureMonths)}</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-slate-500">EMI Outgo:</span>
                              <span className="font-semibold text-slate-800">{formatCurrency(origEmi)} / month</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-slate-500">Principal Outstanding (at Year {origTenureYears}):</span>
                              <span className="font-semibold text-slate-800">₹0</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-slate-500">SIP Investment Value at end:</span>
                              <span className="font-bold text-slate-800">₹0</span>
                            </div>
                            <div className="flex justify-between pt-2 border-t border-slate-100">
                              <span className="font-bold text-slate-600">Net Wealth Generated:</span>
                              <span className="font-extrabold text-slate-700">₹0</span>
                            </div>
                          </div>
                        </div>

                        {/* Case 2: Extending Tenure to 25 Years & SIP Savings */}
                        <div className="bg-white p-5 rounded-2xl border border-blue-100 shadow-sm shadow-blue-50 space-y-4">
                          <div className="flex items-center justify-between pb-2 border-b border-blue-50">
                            <h5 className="font-bold text-slate-700 text-sm">Case 2: Ext. Tenure to {newTenureYears} Years + SIP</h5>
                            <span className="text-xs bg-blue-50 text-blue-700 px-2.5 py-1 rounded-full font-bold">Optimized Plan</span>
                          </div>

                          <div className="space-y-3 text-xs">
                            <div className="flex justify-between">
                              <span className="text-slate-500">Extended Loan Period:</span>
                              <span className="font-semibold text-slate-800">{formatMonthsToYrs(balanceTenureMonths)}</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-slate-500">Lowered EMI:</span>
                              <span className="font-semibold text-slate-800">{formatCurrency(modifiedEmi)} / month</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-slate-500">Principal Outstanding (at Year {origTenureYears}):</span>
                              <span className="font-semibold text-slate-800">{formatCurrency(case2OSAtEnd)}</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-slate-500">SIP Wealth (At original loan end):</span>
                              <span className="font-bold text-sky-600">{formatCurrency(sipWealthAtEnd)}</span>
                            </div>
                            <div className="flex justify-between pt-2 border-t border-blue-50">
                              <span className="font-bold text-slate-600">Net Wealth Generated:</span>
                              <span className="font-extrabold text-sky-600">
                                {sipWealthAtEnd - case2OSAtEnd < 0 ? '₹0' : formatCurrency(sipWealthAtEnd - case2OSAtEnd)}
                              </span>
                            </div>
                          </div>
                        </div>
                      </div>

                      {/* Educational Explanation Footer */}
                      <div className="bg-slate-50 p-4 rounded-xl text-xs text-slate-500 leading-relaxed border border-slate-200/40">
                        <p className="flex items-start gap-1.5">
                          <HelpCircle className="w-4 h-4 text-slate-400 shrink-0 mt-0.5" />
                          <span>
                            <strong>How this works:</strong> By increasing your loan tenure, your EMI burden decreases immediately. By systematically investing this exact monthly saving (₹{Math.round(sipAmount).toLocaleString('en-IN')}) into an equity SIP yielding {sipReturnRate}%, the compounding growth rate of your investment easily outpaces your loan rate of {interestRate}%. Within {formatMonthsToYrs(repayMonthIndex + monthsPaid)}, your accumulated SIP portfolio exceeds your total outstanding principal balance, enabling you to close your debt way ahead of schedule with significant surplus left over.
                          </span>
                        </p>
                      </div>
                    </div>
                </div>

                {/* Footer Controls */}
                <div className="p-4 border-t border-slate-100 flex justify-end gap-3 bg-slate-50/50 mt-auto">
                  <button 
                    onClick={onClose} 
                    className="px-6 py-2.5 text-xs font-bold text-slate-700 bg-white border border-slate-200 hover:bg-slate-50 transition-all rounded-xl shadow-sm"
                  >
                    Close Tools
                  </button>
                </div>
              </div>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};
