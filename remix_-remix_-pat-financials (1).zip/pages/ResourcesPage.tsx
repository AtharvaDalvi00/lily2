import React, { useEffect, useState } from 'react';
import { motion } from 'motion/react';
import { ScrollReveal } from '../components/ui/ScrollReveal';
import { Calculator, BookOpen, Lightbulb, FileText, Play, Youtube, ArrowLeft } from 'lucide-react';
import { Link } from 'react-router-dom';
import { StepUpSIPCalculator } from '../components/StepUpSIPCalculator';
import { SIPSWPCalculator } from '../components/SIPSWPCalculator';
import { SWPWithStepUpCalculator } from '../components/SWPWithStepUpCalculator';
import { AmortizationScheduleCalculator } from '../components/AmortizationScheduleCalculator';
import { LumpSumCalculator } from '../components/LumpSumCalculator';
import { Videos } from '../components/Videos';

export const ResourcesPage: React.FC = () => {
  const [isCalculatorOpen, setIsCalculatorOpen] = useState(false);
  const [isGoalPlannerOpen, setIsGoalPlannerOpen] = useState(false);
  const [isSWPWithStepUpOpen, setIsSWPWithStepUpOpen] = useState(false);
  const [isAmortizationOpen, setIsAmortizationOpen] = useState(false);
  const [isLumpSumOpen, setIsLumpSumOpen] = useState(false);

  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  return (
    <div className="pt-24 min-h-screen bg-slate-50">
      {/* Header section */}
      <div className="bg-brand-dark py-16 text-white relative">
        <div className="container mx-auto px-4 md:px-6">
          <Link to="/" className="inline-flex items-center gap-2 text-slate-300 hover:text-white mb-8 transition-colors group">
            <ArrowLeft className="w-5 h-5 group-hover:-translate-x-1 transition-transform" />
            Back to Home
          </Link>
          <h1 className="text-4xl md:text-5xl font-display font-bold mb-4">Financial Resources</h1>
          <p className="text-lg text-slate-300 max-w-2xl">
            Empower yourself with our comprehensive suite of tools, educational videos, and in-depth articles designed to help you make smarter money decisions.
          </p>
        </div>
      </div>

      {/* Tools & Calculators */}
      <section className="py-16">
        <div className="container mx-auto px-4 md:px-6">
          <div className="mb-12">
            <h2 className="text-3xl font-display font-bold text-brand-dark mb-4">Calculators & Tools</h2>
            <p className="text-slate-600">Free, easy-to-use financial tools to help you plan your investments and evaluate goals.</p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: false, margin: "-50px" }}
              transition={{ duration: 0.5, delay: 0.1 }}
              onClick={() => setIsCalculatorOpen(true)}
              className="group relative bg-white border border-slate-200 p-8 rounded-3xl shadow-sm hover:shadow-2xl transition-all duration-500 hover:-translate-y-2 cursor-pointer overflow-hidden"
            >
              <div className="absolute top-0 right-0 w-32 h-32 bg-brand-primary/5 rounded-bl-[100px] -mr-8 -mt-8 transition-transform group-hover:scale-110"></div>
              <div className="w-14 h-14 bg-brand-light rounded-xl flex items-center justify-center mb-6 group-hover:bg-brand-primary group-hover:scale-110 group-hover:rotate-3 transition-all duration-300 shadow-sm group-hover:shadow-brand-primary/30">
                <Calculator className="w-7 h-7 text-brand-primary group-hover:text-white transition-colors duration-300" />
              </div>
              <h3 className="text-xl font-bold text-brand-dark mb-2 group-hover:text-brand-primary transition-colors duration-300">SIP Step-Up Tool</h3>
              <p className="text-sm text-slate-500 mb-4 group-hover:text-slate-600 transition-colors duration-300">Plan for inflation with our advanced step-up calculator showing realistic trajectories.</p>
              <span className="text-brand-primary text-sm font-semibold inline-flex items-center gap-2 group-hover:translate-x-2 transition-all">Launch Tool</span>
            </motion.div>

            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: false, margin: "-50px" }}
              transition={{ duration: 0.5, delay: 0.2 }}
              onClick={() => setIsGoalPlannerOpen(true)}
              className="group relative bg-white border border-slate-200 p-8 rounded-3xl shadow-sm hover:shadow-2xl transition-all duration-500 hover:-translate-y-2 cursor-pointer overflow-hidden"
            >
              <div className="absolute top-0 right-0 w-32 h-32 bg-brand-accent/5 rounded-bl-[100px] -mr-8 -mt-8 transition-transform group-hover:scale-110"></div>
              <div className="w-14 h-14 bg-blue-50 rounded-xl flex items-center justify-center mb-6 group-hover:bg-brand-accent group-hover:scale-110 group-hover:rotate-3 transition-all duration-300 shadow-sm group-hover:shadow-brand-accent/30">
                <Lightbulb className="w-7 h-7 text-blue-600 group-hover:text-white transition-colors duration-300" />
              </div>
              <h3 className="text-xl font-bold text-brand-dark mb-2 group-hover:text-brand-accent transition-colors duration-300">Goal Planner</h3>
              <p className="text-sm text-slate-500 mb-4 group-hover:text-slate-600 transition-colors duration-300">Plan your SIP corpus and generate passive monthly income via SWP.</p>
              <span className="text-brand-primary text-sm font-semibold inline-flex items-center gap-2 group-hover:translate-x-2 transition-all">Launch Tool</span>
            </motion.div>

            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: false, margin: "-50px" }}
              transition={{ duration: 0.5, delay: 0.3 }}
              onClick={() => setIsSWPWithStepUpOpen(true)}
              className="group relative bg-white border border-slate-200 p-8 rounded-3xl shadow-sm hover:shadow-2xl transition-all duration-500 hover:-translate-y-2 cursor-pointer overflow-hidden"
            >
              <div className="absolute top-0 right-0 w-32 h-32 bg-sky-50 rounded-bl-[100px] -mr-8 -mt-8 transition-transform group-hover:scale-110"></div>
              <div className="w-14 h-14 bg-sky-50 rounded-xl flex items-center justify-center mb-6 group-hover:bg-brand-secondary group-hover:scale-110 group-hover:rotate-3 transition-all duration-300 shadow-sm group-hover:shadow-brand-secondary/30">
                <Calculator className="w-7 h-7 text-sky-600 group-hover:text-white transition-colors duration-300" />
              </div>
              <h3 className="text-xl font-bold text-brand-dark mb-2 group-hover:text-brand-secondary transition-colors duration-300">SWP with Step Up</h3>
              <p className="text-sm text-slate-500 mb-4 group-hover:text-slate-600 transition-colors duration-300">Estimate your retirement corpus and secure your financial future.</p>
              <span className="text-brand-secondary text-sm font-semibold inline-flex items-center gap-2 group-hover:translate-x-2 transition-all">Launch Tool</span>
            </motion.div>

            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: false, margin: "-50px" }}
              transition={{ duration: 0.5, delay: 0.4 }}
              onClick={() => setIsAmortizationOpen(true)}
              className="group relative bg-white border border-slate-200 p-8 rounded-3xl shadow-sm hover:shadow-2xl transition-all duration-500 hover:-translate-y-2 cursor-pointer overflow-hidden"
            >
              <div className="w-14 h-14 bg-sky-50 rounded-xl flex items-center justify-center mb-6 group-hover:bg-sky-600 group-hover:scale-110 group-hover:rotate-3 transition-all duration-300 shadow-sm group-hover:shadow-sky-600/30">
                <Calculator className="w-7 h-7 text-sky-600 group-hover:text-white transition-colors duration-300" />
              </div>
               <h3 className="text-xl font-bold text-brand-dark mb-2 group-hover:text-sky-600 transition-colors duration-300">EMI Calculator</h3>
               <p className="text-sm text-slate-500 mb-4 group-hover:text-slate-600 transition-colors duration-300">Calculate your monthly loan EMI, track interest payments, and simulate prepayments.</p>
               <span className="text-brand-primary text-sm font-semibold inline-flex items-center gap-2 group-hover:translate-x-2 transition-all">Launch Tool</span>
            </motion.div>

            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: false, margin: "-50px" }}
              transition={{ duration: 0.5, delay: 0.5 }}
              onClick={() => setIsLumpSumOpen(true)}
              className="group relative bg-white border border-slate-200 p-8 rounded-3xl shadow-sm hover:shadow-2xl transition-all duration-500 hover:-translate-y-2 cursor-pointer overflow-hidden"
            >
              <div className="w-14 h-14 bg-blue-50 rounded-xl flex items-center justify-center mb-6 group-hover:bg-blue-600 group-hover:scale-110 group-hover:rotate-3 transition-all duration-300 shadow-sm group-hover:shadow-blue-600/30">
                <Calculator className="w-7 h-7 text-blue-600 group-hover:text-white transition-colors duration-300" />
              </div>
               <h3 className="text-xl font-bold text-brand-dark mb-2 group-hover:text-blue-600 transition-colors duration-300">LumpSum Calculator</h3>
               <p className="text-sm text-slate-500 mb-4 group-hover:text-slate-600 transition-colors duration-300">Calculate the potential growth of your one-time investments.</p>
               <span className="text-brand-primary text-sm font-semibold inline-flex items-center gap-2 group-hover:translate-x-2 transition-all">Launch Tool</span>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Videos Section */}
      <div className="bg-white">
         {/* Re-use the existing Videos component directly */}
         <Videos />
      </div>

      {/* Blogs Section */}
      <section className="py-16 bg-slate-50">
        <div className="container mx-auto px-4 md:px-6">
          <div className="mb-12">
            <h2 className="text-3xl font-display font-bold text-brand-dark mb-4">Latest Insights & Blogs</h2>
            <p className="text-slate-600">Expert analysis, market outlooks, and financial structuring strategies.</p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              {
                id: 1,
                title: "How to Protect Your Portfolio Against Inflation",
                date: "March 15, 2026",
                category: "Wealth Distributor",
                image: "https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
                description: "Understanding the silent wealth killer and taking actionable steps to ensure your returns outpace rising costs."
              },
              {
                id: 2,
                title: "Tax Harvesting: The Ultimate Strategy Before March 31",
                date: "February 28, 2026",
                category: "Tax Optimization",
                image: "https://images.unsplash.com/photo-1554224155-8d04cb21cd6c?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
                description: "Maximize your post-tax returns by strategically booking ₹1 Lakh of long-term capital gains every financial year."
              },
              {
                id: 3,
                title: "Why NRIs Should Invest in Indian Markets Now",
                date: "January 12, 2026",
                category: "NRI Solutions",
                image: "https://images.unsplash.com/photo-1526304640581-d334cdbbf45e?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
                description: "India's growth story remains intact. A guide for NRIs on seamlessly investing in mutual funds and direct equity."
              }
            ].map((blog, index) => (
              <motion.div 
                key={blog.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: false, margin: "-50px" }}
                transition={{ duration: 0.5, delay: index * 0.15 }}
              >
                <a href="#" className="group bg-white rounded-2xl shadow-sm hover:shadow-xl transition-all border border-slate-100 overflow-hidden flex flex-col h-full">
                  <div className="h-48 overflow-hidden">
                    <img src={blog.image} alt={blog.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                  </div>
                  <div className="p-6 flex-1 flex flex-col">
                    <div className="flex justify-between items-center mb-3">
                      <span className="text-xs font-bold text-brand-primary uppercase tracking-wider">{blog.category}</span>
                      <span className="text-xs text-slate-400">{blog.date}</span>
                    </div>
                    <h3 className="text-xl font-bold text-slate-800 mb-3 group-hover:text-brand-primary transition-colors">{blog.title}</h3>
                    <p className="text-slate-600 text-sm mb-4 flex-1">{blog.description}</p>
                    <span className="text-brand-primary text-sm font-semibold hover:underline underline-offset-4 mt-auto">Read Full Article</span>
                  </div>
                </a>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <StepUpSIPCalculator isOpen={isCalculatorOpen} onClose={() => setIsCalculatorOpen(false)} />
      <SIPSWPCalculator isOpen={isGoalPlannerOpen} onClose={() => setIsGoalPlannerOpen(false)} />
      <SWPWithStepUpCalculator isOpen={isSWPWithStepUpOpen} onClose={() => setIsSWPWithStepUpOpen(false)} />
      <AmortizationScheduleCalculator isOpen={isAmortizationOpen} onClose={() => setIsAmortizationOpen(false)} />
      <LumpSumCalculator isOpen={isLumpSumOpen} onClose={() => setIsLumpSumOpen(false)} />
    </div>
  );
};
