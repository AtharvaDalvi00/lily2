This directory is for public assets like images. You can upload the co-founder photo here!
