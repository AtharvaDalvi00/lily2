import React, { useEffect } from 'react';
import { ScrollReveal } from '../components/ui/ScrollReveal';
import { Link } from 'react-router-dom';
import { Target, ChartBar, Coins, ArrowLeft } from 'lucide-react';
import { ContactCTA } from '../components/ContactCTA';

export const WealthManagementDetails: React.FC = () => {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  return (
    <>
      <ScrollReveal>
      <section className="py-20 bg-brand-light relative overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img src="https://images.unsplash.com/photo-1526304640581-d334cdbbf45e?w=1600&q=80" alt="Background" className="w-full h-full object-cover opacity-[0.06] mix-blend-multiply" />
        </div>
        <div className="absolute top-0 right-0 w-64 h-64 bg-brand-primary/10 rounded-full blur-3xl"></div>
        <div className="absolute bottom-0 left-0 w-64 h-64 bg-brand-secondary/10 rounded-full blur-3xl"></div>
        
        <div className="container mx-auto px-4 md:px-6 relative z-10 text-center max-w-4xl pt-16">
          
          <Link to="/" className="inline-flex items-center gap-2 px-4 py-2 bg-white/50 hover:bg-white text-brand-primary font-medium rounded-full mb-8 backdrop-blur-sm border border-slate-200/50 hover:border-brand-primary/30 transition-all shadow-sm hover:shadow-md group">
            <ArrowLeft className="w-4 h-4 group-hover:-translate-x-1 transition-transform" /> Back to Home
          </Link>
          <h1 className="text-5xl md:text-6xl font-display font-bold text-brand-dark mb-6">Wealth Distributor</h1>
          <p className="text-xl text-slate-600 mb-8 leading-relaxed">
            Holistic management of your assets for long-term growth. We take a 360-degree view of your net worth to strategically maximize, protect, and distribute it.
          </p>
        </div>
      </section>
      </ScrollReveal>

      <ScrollReveal>
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4 md:px-6 max-w-4xl">
          <div className="pred pred-lg pred-slate max-w-none text-slate-600 space-y-6">
             <h2 className="text-3xl font-display font-bold text-brand-dark">Why Do You Need a Wealth Distributor?</h2>
            <p>
              Growing wealth is only part of the equation; preserving and managing it across generations requires sophisticated strategies. Wealth Distributor services go beyond standard investment advice. It incorporates tax planning, estate planning, risk management, and legal advisory to ensure your hard-earned money works seamlessly for your life's aspirations.
            </p>
            
            <h3 className="text-2xl font-display font-bold text-brand-dark mt-12 mb-4">Our Approach</h3>
            
            <div className="grid md:grid-cols-3 gap-8 my-8">
              <div className="bg-slate-50 p-6 rounded-2xl border border-slate-100 shadow-sm">
                <Target className="w-10 h-10 text-brand-primary mb-4" />
                <h4 className="text-lg font-bold text-brand-dark mb-2">Holistic Assessment</h4>
                <p className="text-sm">We analyze your entire financial footprint, including business interests, real estate, and financial assets.</p>
              </div>
              
              <div className="bg-slate-50 p-6 rounded-2xl border border-slate-100 shadow-sm">
                <ChartBar className="w-10 h-10 text-brand-primary mb-4" />
                <h4 className="text-lg font-bold text-brand-dark mb-2">Active Management</h4>
                <p className="text-sm">Continuous monitoring and proactive rebalancing of your portfolio against volatile markets and changing economic scenarios.</p>
              </div>
              
              <div className="bg-slate-50 p-6 rounded-2xl border border-slate-100 shadow-sm">
                <Coins className="w-10 h-10 text-brand-primary mb-4" />
                <h4 className="text-lg font-bold text-brand-dark mb-2">Wealth Preservation</h4>
                <p className="text-sm">Implementing robust strategies to protect your assets from inflation, taxation, and unforeseen liabilities.</p>
              </div>
            </div>

            <h3 className="text-2xl font-display font-bold text-brand-dark mt-12 mb-4">The Result</h3>
            <p>
              You gain the ultimate luxury: peace of mind. Knowing that a dedicated team is optimizing every facet of your wealth allows you to focus on your family, your business, and your passions, while your legacy is secured for the future.
            </p>
          </div>
        </div>
      </section>
      </ScrollReveal>
      
      <ContactCTA />
    </>
  );
};
