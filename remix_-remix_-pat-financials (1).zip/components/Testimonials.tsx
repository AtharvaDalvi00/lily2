import React, { useState, useEffect } from 'react';
import { Star, ChevronLeft, ChevronRight, Quote } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Testimonial } from '../types';

const testimonials: Testimonial[] = [
  {
    id: 1,
    name: 'Aashutosh Murhekar',
    role: 'Deputy General Manager',
    company: ' Mileage Logistics Pvt. Ltd.',
    content: "I am absolutely delighted with PAT FINANCIAL services. It is really refreshing to work with a financial adviser who is truly interested in their client’s needs, circumstances and preferences. What really impressed me was the way PAT FINANCIAL took the time to get a feeling for where I was at, your depth of knowledge, lateral thinking and your common sense approach. Your professional, ethical and caring demeanor elicits my trust and respect and I gladly recommend your services whenever possible.",
    rating: 5,
    image: 'https://lh3.googleusercontent.com/pw/AP1GczMA_Mom5CKB9f03L_x38Xlr1emxkoWgChgVdrSsZdoDqtoLFPKT3UMtATuPFUUb9o8MwNwQ1bYz9_yBzePmMXucmtll1L_DSkzmf704IiR9uCAda6cvbbR5-qcO4tNF-qjFzKtCPoVLRphIYAJ7hhEv=w800-h800-s-no-gm?authuser=0'
  },
  {
    id: 2,
    name: 'Sachin Sawant',
    role: 'Associate Vice President - Sales',
    company: 'Mphasis',
    content: "Service of PAT Financials is truly inline with their Tagline (Portfolio Analysis with Trust). Myself &amp; my wife met Pradnya in an exhibition and just to give it a try we started with a very small investment with PAT Financials. However the kind of Ethical Advisory &amp; Excellent Customer Service provided by PAT Financials, built a Trust where within a short time we directed all our investments to PAT Financials, building a healthy portfolio. We consider ourself lucky that we met Pradnya in that Exhibition. Now financial structuring is no more a point of worry for us. The Goal Based financial structuring done by PAT Financials is taking care of all our future goals. I highly recommend their services to all my friends. My best wishes for PAT Financials team.",
    rating: 5,
    image: 'https://lh3.googleusercontent.com/pw/AP1GczPfrS7qc3bmpG_0JeFcGg06W-vqFnsC8fH1REU5bJKPGr-Z3mtENPjz7bEB80sYq7RRRiAzHkuALmJ8vTJL_cVHx5p3m2Vf7GFr3xNauowsObP27V3FiG8_CSPqqoCcb26s3nYZTOIzDD6MeR_tEXhO=w800-h800-s-no-gm?authuser=0'
  },
  {
    id: 3,
    name: 'Sudesh Bhelekar',
    role: 'Consultant MEP Services',
    company: 'Provenance Land',
    content: "My wife and I met Pradnya Tamhane in 2013, when it comes to financial structuring we were novices.  With her recommendations we could create a healthy financial profile and extremely pleased with the decision we made to be with Pat Financials. We find Pradnya’ s team pleasant at all times &amp; easy to work. They are always contactable, courteous and helpful with their valuable advice on investments.",
    rating: 5,
    image: 'https://lh3.googleusercontent.com/pw/AP1GczPTXVy0HV7uxx-pC1vOPVz1mL-Sp5NU6cEMkkx7Q5y7m5NKFMifuN-KqZqPKUeqVcdy9oOpFS3hnX8fi8ipdCqKWanJTm_yhVOGJBsYAEZ-ZDNXty-Esc3NbdOkvjeoOIEjbL17mzon8TMy_waZ0bGQ=w294-h294-s-no-gm?authuser=0'
  },
  {
    id: 4,
    name: 'Bharat Ishi',
    role: 'Head Real Estate',
    company: 'KOHINOOR GROUP',
    content: "Pradnya has been meticulously investing my money and monitoring the investments. I am extremely happy as I get the personalized service that I was expecting. It is a great feeling to know that your money is in safe hands. I strongly recommend her services. I wish her all the best for the new endeavor.",
    rating: 5,
    image: 'https://lh3.googleusercontent.com/pw/AP1GczMxi5I37X_eeM28Gldg3aZ-u2EnghUsr03jAJ2roghKXCagN4OtoXRhL5aDJObVoVojNIP8abB8K3h6GuzGVQDyyGPtdAD_DPxWashAR4jy7E6Y7T60T3MkkFNx3mwkT2-4tdsBfn7S6JPKTFUBDaFn=w450-h450-s-no-gm?authuser=0'
  },
  {
    id: 5,
    name: 'Amol Jaywant',
    role: 'Senior Vice President',
    company: 'Axis Bank',
    content: "Well! When I think of Investing I think of PAT financials, purely due to service levels and customized portfolio offerings as required to fulfill my investment requirements. I can trust the PAT due to proactive measures for any good investment offerings that PAT provides us. Thanks to Pradnya for all the good work she has done in multiplying my wealth. God bless her! P – Proactive. A – Accurate. T= Timely Services that’s was PAT stands for.",
    rating: 5,
    image: 'https://lh3.googleusercontent.com/pw/AP1GczOSPeE0ybrat-oFCP1C3yccxdrnePQi0IGHM7czUSlEeAAZJg71K46yJIfpwvNitkON9pzY07BTY9cPGKp7OY0GOUSutGXdo0PPVfxZH6kM9AU0YNorcxedMZBqyQab0E-qiTL3neka6Xj4WFwkO41_=w800-h800-s-no-gm?authuser=0'
  },
  {
    id: 6,
    name: 'Tushar Raje',
    role: 'Assistant Vice President',
    company: 'Tata Consultancy Services',
    content: "I trust PAT Financial Structuring. I appreciate the personalized portfolio management services provided by Pradnya. I feel more secure since the investments are made based on my requirements for Retirement, Child’s education balancing with liquid investments to meet contingencies. I am associated with Pradnya since 2012 and it has been a wonderful journey in achieving the desired returns on investments along with capital appreciation.",
    rating: 5,
    image: 'https://lh3.googleusercontent.com/pw/AP1GczO1pIf8aJbhxGkSaMOPpPNeSjoxEHF6Kys6bVK6T4pYwrfEAu5vbTGAiUKcz9UxiOXlUIm3XQYu7WJfsxihfo_6C-CvrIm-vkJbONh1VyrvdIFiBnV2rV_NEHSgI6_5DpEYSh4HiowOR2xRrzBQlpcN=w800-h800-s-no-gm?authuser=0'
  },
  {
    id: 7,
    name: 'Ameya Kulkarni',
    role: 'Financial Controller',
    company: 'DNK Foods Pvt. Ltd.',
    content: "I have known Mrs Pradnya Tamhane for last 2 years. She has been handling my personal investments and also given advice on the investments for DNK Foods Pvt Ltd. The services offered are prompt and according to the financial goals of each individual and situation, taking into consideration the risk appetite and other factors. I recommend her services if one is looking for professional and systematic achievement of long and short term Financial objectives.",
    rating: 5,
    image: 'https://lh3.googleusercontent.com/pw/AP1GczOsCE1CW_cmuBOzcpUdWQQCkVcr60t2x8Ns4JfynU21FhN0S8qx592_wsM2s-z5sSi9UdBw08z6TXVnCBFAESct5UZpt1n73eW991JyntkbirdVkI83_RZ87e3ezrT9Gbgv0J9SnfNP8D9Ui28OtkWt=w500-h500-s-no-gm?authuser=0'
  },
  {
    id: 8,
    name: 'Harikishan Shah',
    role: 'Civil Engineer',
    company: 'Hiranandani Group of Companies',
    content: "I would like to congratulate you for your work and express my heartiest regards towards your selfless investment advice and guidance. It is really grateful to having you as my Financial Manager.  Thanks for all your kind support and hoping our Financial relation will go far ahead. ",
    rating: 5,
    image: 'https://lh3.googleusercontent.com/pw/AP1GczOdu88iCDVG6myz4MqBxUxMv-t_d3M0WHxF7QbX64DQ0CELHsDdUl1lVS3deSvnAaNtCO9O4FMjf7JOdfIzpFA2EoUq8sy2Rvf-nGIIc5APoS9aRewvd-XIdZbE6KWEmKDuMSBeuklFc_VuQsdmjCux=w800-h800-s-no-gm?authuser=0'
  },
  {
    id: 9,
    name: 'Shirish Patel',
    role: 'CEO',
    company: 'Prudent Corporate Advisory Services Ltd.',
    content: "I have visited your website www.patfinancials.com and have found your site very informative and useful. The facilities that you are providing on your site will make life easier and save time for your investors. Your goal based advisory along  with technology support and services will differentiate you Vs others in the similar field.. Your Blogs are interesting too and easy to understand.  I am confident that you will scale new heights in your business.. I wish you all the best.	",
    rating: 5,
    image: 'https://pradnyatamhane.com/media/images/home/shirish-patel-ceo-prudent.jpg'
  }
];

export const Testimonials: React.FC = () => {
  const [currentIndex, setCurrentIndex] = useState(0);

  const next = () => setCurrentIndex((prev) => (prev + 1) % testimonials.length);
  const prev = () => setCurrentIndex((prev) => (prev - 1 + testimonials.length) % testimonials.length);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % testimonials.length);
    }, 10000);
    return () => clearInterval(timer);
  }, []);

  return (
    <section id="testimonials" className="py-16 bg-brand-light relative overflow-hidden">
      <div className="absolute top-0 right-0 w-64 h-64 bg-brand-secondary/5 rounded-full blur-3xl"></div>
      
      <div className="container mx-auto px-4 md:px-6 relative z-10">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-display font-bold text-brand-dark mb-4">What our clients say</h2>
          <p className="text-slate-600">Join 2,100+ families who trust us with their future.</p>
        </div>

        <div className="max-w-4xl mx-auto">
          <div className="bg-white rounded-[40px] shadow-xl p-8 md:p-12 relative border border-white/50">
             <Quote className="absolute top-8 left-8 text-brand-primary/10 w-24 h-24 -z-1" />
             
             <div className="overflow-hidden relative">
               <AnimatePresence mode="wait">
                 <motion.div 
                   key={currentIndex}
                   initial={{ opacity: 0, x: 20 }}
                   animate={{ opacity: 1, x: 0 }}
                   exit={{ opacity: 0, x: -20 }}
                   transition={{ duration: 0.5, ease: "easeInOut" }}
                   className="flex flex-col items-center gap-8 w-full"
                 >
                    <div className="shrink-0 flex flex-col items-center justify-center gap-4">
                      <img 
                        src={testimonials[currentIndex].image} 
                        alt={testimonials[currentIndex].name} 
                        className="w-24 h-24 md:w-32 md:h-32 rounded-full object-cover shadow-lg border-4 border-white/50" 
                      />
                       <div className="text-center">
                          <h4 className="text-lg font-bold text-brand-primary">{testimonials[currentIndex].name}</h4>
                          <p className="text-sm text-slate-500">{testimonials[currentIndex].role}, {testimonials[currentIndex].company}</p>
                       </div>
                    </div>
                    <div className="flex-1 text-center">
                       <div className="flex justify-center gap-1 mb-4 text-brand-accent">
                          {[...Array(testimonials[currentIndex].rating)].map((_, i) => (
                            <Star key={i} className="w-5 h-5 fill-current" />
                          ))}
                       </div>
                       <p className="text-xl md:text-2xl text-brand-dark font-medium leading-relaxed mb-6 not-italic">
                         "{testimonials[currentIndex].content}"
                       </p>
                    </div>
                 </motion.div>
               </AnimatePresence>
             </div>

             {/* Controls */}
             <div className="flex gap-4 justify-center mt-8 md:mt-0 md:absolute md:bottom-12 md:right-12">
                <button onClick={prev} className="p-2 rounded-full border border-slate-200 hover:bg-brand-light hover:border-brand-primary transition-colors text-slate-600">
                   <ChevronLeft className="w-6 h-6" />
                </button>
                <button onClick={next} className="p-2 rounded-full border border-slate-200 hover:bg-brand-light hover:border-brand-primary transition-colors text-slate-600">
                   <ChevronRight className="w-6 h-6" />
                </button>
             </div>
          </div>
        </div>
      </div>
    </section>
  );
};