import React, { useState, useEffect } from 'react';
import { Menu, X, Smartphone, LogIn, Hexagon, LogOut } from 'lucide-react';
import { NavItem } from '../types';
import { auth, signInWithGoogle, logOut } from '../firebase';
import { onAuthStateChanged, User } from 'firebase/auth';
import { useNavigate, useLocation } from 'react-router-dom';

const navItems: NavItem[] = [
  { label: 'Home', href: 'home' },
  { label: 'About Us', href: 'about' },
  { label: 'Services', href: 'services' },
  { label: 'Process', href: 'process' },
  { label: 'Resources', href: 'resources' },
  { label: 'Calculators', href: 'calculators' },
  { label: 'Testimonials', href: 'testimonials' },
  { label: 'Contact', href: 'contact' },
];

export const Header: React.FC = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [user, setUser] = useState<User | null>(null);
  const navigate = useNavigate();
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
      setUser(currentUser);
    });
    return () => unsubscribe();
  }, []);

  const handleLogin = async () => {
    try {
      await signInWithGoogle();
    } catch (error) {
      console.error(error);
    }
  };

  const handleNavClick = (href: string) => {
    setIsMobileMenuOpen(false);
    if (href === 'calculators') {
      navigate('/calculators');
      return;
    }
    if (location.pathname !== '/') {
      navigate('/');
      setTimeout(() => {
        const element = document.getElementById(href);
        if (element) element.scrollIntoView({ behavior: 'smooth' });
      }, 100);
    } else {
      const element = document.getElementById(href);
      if (element) {
        element.scrollIntoView({ behavior: 'smooth' });
      } else if (href === 'home') {
        window.scrollTo({ top: 0, behavior: 'smooth' });
      }
    }
  };

  const handleLogoClick = () => {
    if (location.pathname !== '/') {
      navigate('/');
    } else {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled
          ? 'py-3 bg-white/90 backdrop-blur-md shadow-sm'
          : 'py-6 bg-transparent'
      }`}
    >
      <div className="container mx-auto px-4 md:px-6 flex items-center justify-between">
        {/* Logo */}
        <div className="flex items-center gap-2 group cursor-pointer" onClick={handleLogoClick}>
          <img src="https://pradnyatamhane.com/media/images/logo-pat.jpg" alt="PAT Financials" className="h-12 md:h-14 object-contain" />
        </div>

        {/* Desktop Nav */}
        <nav className="hidden lg:flex items-center gap-8">
          {navItems.map((item) => (
            <button
              key={item.label}
              onClick={() => handleNavClick(item.href)}
              className="text-sm font-medium text-slate-600 hover:text-brand-primary transition-colors cursor-pointer"
            >
              {item.label}
            </button>
          ))}
        </nav>

        {/* Right Actions */}
        <div className="hidden lg:flex items-center gap-4">
          <button className="p-2 text-slate-500 hover:text-brand-primary transition-colors rounded-full hover:bg-brand-light">
            <Smartphone className="w-5 h-5" />
          </button>
          
          {user ? (
            <div className="flex items-center gap-3">
              <img src={user.photoURL || ''} alt={user.displayName || 'User'} className="w-8 h-8 rounded-full" />
              <button onClick={logOut} className="flex items-center gap-1 text-sm font-semibold text-slate-700 hover:text-brand-primary transition-colors">
                <LogOut className="w-4 h-4" />
                Log Out
              </button>
            </div>
          ) : (
            <>
              <button onClick={() => navigate('/auth')} className="flex items-center gap-1 text-sm font-semibold text-slate-700 hover:text-brand-primary transition-colors">
                <LogIn className="w-4 h-4" />
                Login
              </button>
              <button onClick={() => navigate('/auth')} className="px-5 py-2.5 bg-brand-dark text-white text-sm font-semibold rounded-full hover:bg-slate-800 transition-all shadow-lg hover:shadow-xl active:scale-95">
                Sign Up
              </button>
            </>
          )}
        </div>

        {/* Mobile Toggle */}
        <button
          className="lg:hidden p-2 text-brand-dark"
          onClick={() => setIsMobileMenuOpen(true)}
        >
          <Menu className="w-6 h-6" />
        </button>
      </div>

      {/* Mobile Menu Overlay */}
      <div
        className={`fixed inset-0 z-50 bg-brand-dark/95 backdrop-blur-xl transition-all duration-300 lg:hidden flex flex-col items-center justify-center ${
          isMobileMenuOpen ? 'opacity-100 visible' : 'opacity-0 invisible pointer-events-none'
        }`}
      >
        <button
          className="absolute top-6 right-6 text-white p-2"
          onClick={() => setIsMobileMenuOpen(false)}
        >
          <X className="w-8 h-8" />
        </button>
        
        <nav className="flex flex-col items-center gap-8">
          {navItems.map((item) => (
            <button
              key={item.label}
              onClick={() => handleNavClick(item.href)}
              className="text-2xl font-display font-medium text-white hover:text-brand-primary transition-colors cursor-pointer"
            >
              {item.label}
            </button>
          ))}
          <div className="h-px w-20 bg-white/20 my-4"></div>
          
          {user ? (
            <>
              <img src={user.photoURL || ''} alt={user.displayName || 'User'} className="w-12 h-12 rounded-full" />
              <button 
                onClick={() => {
                  logOut();
                  setIsMobileMenuOpen(false);
                }} 
                className="text-xl font-medium text-white hover:text-brand-primary flex items-center gap-2"
              >
                <LogOut className="w-5 h-5"/> Log Out
              </button>
            </>
          ) : (
            <>
              <button onClick={() => { navigate('/auth'); setIsMobileMenuOpen(false); }} className="text-xl font-medium text-white hover:text-brand-primary">Login</button>
              <button onClick={() => { navigate('/auth'); setIsMobileMenuOpen(false); }} className="px-8 py-3 bg-brand-primary text-white text-lg font-semibold rounded-full hover:bg-brand-primary/90">
                Sign Up
              </button>
            </>
          )}
        </nav>
      </div>
    </header>
  );
};